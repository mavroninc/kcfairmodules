# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo import models, _


class QuickbooksExportMixin(models.AbstractModel):
    _name = 'quickbooks.export.mixin'
    _description = 'QuickBooks Export Mixin'

    _qbo_job_alias_out = None  # Human readable name of the record in the queue-job description

    @property
    def _qbo_company(self):
        self.ensure_one()
        company = self.company_id if 'company_id' in self else self.env.company

        return company or self.env.company

    @property
    def quickbooks_integration(self):
        """The connection this record syncs through.

        Everything that exports a record needs one, so its absence is raised
        rather than returned. Where the absence is an answer of its own, ask
        `has_quickbooks_integration` first.
        """
        qi = self._qbo_company.quickbooks_integration
        qi.ensure_one()

        return qi

    @property
    def has_quickbooks_integration(self):
        """Whether an active connection exists for this record.

        A company with no connection, or one that has been set back to draft,
        is a normal state: the records simply cannot be exported.
        """
        return bool(self._qbo_company.quickbooks_integration)

    def action_export_to_quickbooks(self, *args, **kwargs):
        raise NotImplementedError

    def _action_update_to_quickbooks(self, qi_id: int, map_type: str):
        """Queue update jobs for the already mapped records.

        Unlike 'action_export_to_quickbooks()' it never falls back to the
        full export: a record without a mapping in the given integration
        has nothing to update and is skipped.
        """
        count = 0
        identity_keys = []
        qi = self.env['quickbooks.integration'].browse(qi_id)

        for record in self.with_company(qi.company_id):
            # Every card of that type, not the one the export would pick: a contact
            # holds a card per currency, and an update carries no document to choose
            # by, so leaving it to `_get_qbo_mapping` would keep updating the card in
            # the company currency and never touch the others.
            for mapping in record._qbo_mappings_of_type(qi_id, map_type):
                # Under the card's own context the lookup answers with the cards it
                # cannot tell apart from this one. More than one means the record is
                # mapped ambiguously, and updating either would write the same name
                # to both, so leave it alone rather than send QuickBooks a duplicate.
                peers = record \
                    .with_context(**mapping._qbo_update_context()) \
                    ._get_qbo_mapping(qi_id, map_type)

                if len(peers) != 1:
                    continue

                count += 1
                job_kwargs = record._job_kwargs_qbo_transaction(
                    map_type=map_type,
                    update=True,
                    job_alias_out=record._qbo_job_alias_out,
                    mapping=mapping,
                )
                identity_keys.append(job_kwargs['identity_key'])

                mapping.with_delay(**job_kwargs).update_qbo_one()

        self._mark_qbo_failed_jobs_as_cancel(identity_key=identity_keys)

        return count

    def export_qbo_one(self, *args, **kwargs):
        raise NotImplementedError

    def to_qbo_json(self):
        raise NotImplementedError

    def _get_condition_for_check_qbo_duplicate(self, *args, **kwargs):
        raise NotImplementedError

    def _export_qbo_one(self, qi_id: int, qbo_lib_model, odoo_bind: bool = True):
        qi = self.env['quickbooks.integration'].browse(qi_id)
        qb = qi.get_quickbooks_api_client()

        MapModel = self.map_model
        response = MapModel._save_qbo_one(qbo_lib_model, client=qb)

        mapping = MapModel.get_or_create_qbo_mapping_from_response(
            response,
            qi_id,
            odoo_id=(self.id if odoo_bind else None),
        )

        return mapping

    def _export_qbo_one_after_duplicate_check(self, qi_id: int, qbo_lib_model, odoo_bind: bool = True):
        qi = self.env['quickbooks.integration'].browse(qi_id)
        qb = qi.get_quickbooks_api_client()

        MapModel = self.map_model
        map_type = qbo_lib_model.map_type

        # 1. Check for the previously added record
        condition = self._get_condition_for_check_qbo_duplicate(qbo_lib_model)
        response_list = MapModel._fetch_qbo_by_query(map_type, condition, client=qb)

        # 2. If nothing found - call the original method
        if not response_list:
            return self._export_qbo_one(qi_id, qbo_lib_model)

        response = response_list[0]

        # 3. Create mapping
        mapping = MapModel.get_or_create_qbo_mapping_from_response(
            response,
            qi_id,
            odoo_id=(self.id if odoo_bind else None),
        )

        return mapping

    def _raise_jobs_notification(self, count: int):
        if count:
            if count == 1:
                message = _('Job was created')
            else:
                message = _('Jobs were created')
        else:
            message = _(
                'No jobs were created. The records were filtered out or not allowed to export. '
                'Enable this type to be exported in the connection settings.'
            )

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'message': message,
                'type': 'success' if count else 'warning',
                'sticky': False,
            }
        }
