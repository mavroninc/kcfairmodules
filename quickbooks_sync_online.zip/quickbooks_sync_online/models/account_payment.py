# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo import models, fields, _
from odoo.exceptions import ValidationError

from ..quickbooks_api import QboDuplicateDocumentNumberError
from ..tools import quote_qbo_query_value


class AccountPayment(models.Model):
    _name = 'account.payment'
    _inherit = [
        'account.payment',
        'quickbooks.mapping.mixin',
        'quickbooks.export.mixin',
    ]

    qbo_mapping_ids = fields.One2many(
        comodel_name='qbo.map.payment',
        inverse_name='payment_id',
        readonly=True,
    )

    @property
    def map_type(self):
        self.ensure_one()
        return self._partner_to_pay_type()

    @property
    def is_customer_invoice_payment(self):
        self.ensure_one()
        return self.partner_type == 'customer' and self.payment_type == 'inbound'

    @property
    def is_vendor_bill_payment(self):
        self.ensure_one()
        return self.partner_type == 'supplier' and self.payment_type == 'outbound'

    @property
    def payment_qbo_invoice_type(self):
        self.ensure_one()

        if self.is_customer_invoice_payment:
            return 'invoice'

        if self.is_vendor_bill_payment:
            return 'bill'

        raise ValidationError(_('Invalid payment type: %s' % self.payment_type))

    @property
    def qbo_reconcilled_field(self):
        self.ensure_one()
        return 'reconciled_invoice_ids' if self.partner_type == 'customer' else 'reconciled_bill_ids'

    @property
    def qbo_reconciled_ids(self):
        return self[self.qbo_reconcilled_field]

    @property
    def qbo_applied_documents(self):
        """The documents this payment goes to, and for how much.

        Read off the reconciliation while there is one, because that is Odoo's
        own answer. Up to Odoo 17 there always was one: `account.payment`
        carried its journal entry through `_inherits = {'account.move':
        'move_id'}`, so registering a payment posted the entry and reconciled it
        there and then, and the payments widget of the document was filled from
        the start.

        Odoo 18 detached the two. The entry is now written only if the payment
        method carries an outstanding account, or if the Accounting app is
        absent -- `account.payment.create` forces an account in that case and
        not otherwise. An ordinary payment can therefore sit registered against
        its document with nothing reconciled, and stay so until a bank statement
        is matched. Leaving the export to wait for that would be a change of
        behaviour rather than a fix, so the amounts are worked out from the
        documents instead.
        """
        self.ensure_one()

        reconciled = self.qbo_reconciled_ids \
            ._get_amount_chunks_for_qbo_payments(self.id, self.amount)

        return reconciled or self._qbo_documents_by_residual()

    def _qbo_documents_by_residual(self):
        """Spend the payment over its documents the way reconciling it would.

        Oldest document first, each taking no more than it still owes, until the
        payment runs out. Whatever is left after that goes to the last document
        that took something, so the lines total the payment -- the rule
        `_get_amount_chunks_for_qbo_payments` already follows.

        One payment against one document, which is nearly all of them, needs no
        rule: the document takes the payment. It is only a payment split over
        several unreconciled documents where this is an estimate, and Odoo may
        reconcile it differently later. A document that owes nothing takes
        nothing, which can leave a payment applying nowhere -- the export says
        so rather than sending an empty payment.

        Amounts are read in the currency of the document, as the reconciled path
        does: the widget answers in that currency too, and a QuickBooks payment
        carries a single CurrencyRef for all of its lines.
        """
        self.ensure_one()

        documents = self.qbo_reconciled_ids.sorted(
            lambda move: (move.invoice_date or move.date, move.id)
        )

        remaining, result = self.amount, []

        for document in documents:
            if remaining <= 0:
                break

            share = min(remaining, abs(document.amount_residual))

            if not share:
                continue

            remaining -= share
            result.append((document.id, share))

        if result and remaining > 0:
            document_id, share = result[-1]
            result[-1] = (document_id, share + remaining)

        return result

    def _partner_to_pay_type(self, partner_type=None):
        if not partner_type:
            self.ensure_one()
            partner_type = self.partner_type

        return 'payment' if partner_type == 'customer' else 'billpayment'

    def _pay_type_to_partner(self, pay_type):
        return 'customer' if pay_type == 'payment' else 'supplier'

    @property
    def is_qbo_export_allowed(self):
        self.ensure_one()

        if not self.has_quickbooks_integration:
            return False

        qi = self.quickbooks_integration
        domain = qi.get_qbo_payment_domain()

        if not self.filtered_domain(domain):
            return False

        value = qi.qb_access_granted \
            and (self.state in ('paid', 'reconciled')) \
            and not self.is_excluded_from_qbo_sync \
            and bool(self.qbo_reconciled_ids)

        if value and not self.env.context.get('qbo_invoice_export_allowed'):
            # We need to check if all related invoices are allowed to export to QBO if the context variable wasn't set
            return all(self.qbo_reconciled_ids.mapped(lambda x: x.is_qbo_sync_done or x.is_qbo_export_allowed))

        return value

    def action_export_to_quickbooks(self):
        count = 0
        identity_keys = []

        for record in self:
            if not record.is_qbo_export_allowed:
                continue

            mapping = record._get_qbo_mapping()

            if mapping:
                record.mark_excluded_from_qbo_sync()
            else:
                count += 1
                job_kwargs = record._job_kwargs_qbo_transaction()
                identity_keys.append(job_kwargs['identity_key'])

                record \
                    .with_context(company_id=record.company_id.id) \
                    .with_delay(**job_kwargs).export_qbo_one()

        self._mark_qbo_failed_jobs_as_cancel(identity_key=identity_keys)

        return self._raise_jobs_notification(count)

    def export_qbo_one(self):
        self.ensure_one()

        if self.is_excluded_from_qbo_sync:
            return self._get_qbo_mapping()

        self = self.with_company(self.company_id)

        self._check_qbo_requirements()

        invoices = self.qbo_reconciled_ids

        if not all(x.is_qbo_sync_done for x in invoices):
            invoices.with_context(
                queue_job__no_delay=True,
                from_qbo_export_payment=True,
            ).action_export_to_quickbooks()

        return self._export_qbo_one_to_many()

    def _export_qbo_one_to_many(self):
        self.ensure_one()

        chunks = self.qbo_applied_documents

        qi = self.quickbooks_integration
        qbo_lib_model = self._prepare_qbo_api_lib_instance(qi.id, chunks)

        try:
            mappings = self._export_qbo_one(qi.id, qbo_lib_model)
        except QboDuplicateDocumentNumberError:
            mappings = self._export_qbo_one_after_duplicate_check(qi.id, qbo_lib_model)

        self._check_qbo_payment_was_applied(chunks, mappings)

        mappings.mark_as_exported()

        # Mark payment as excluded from QuickBooks sync
        self.mark_excluded_from_qbo_sync()

        return mappings

    def _check_qbo_payment_was_applied(self, chunks: list, mappings):
        """Refuse a payment QuickBooks did not apply the way it was sent.

        The mappings are built from the lines QuickBooks answers with, and it
        does not have to answer with the lines it was given: a document that is
        already settled there is dropped from the payment and its amount is kept
        as an unapplied credit instead. The payment would then be marked as
        exported while Odoo holds no link to it at all, and a partial
        application would lose the documents that were dropped without a trace.
        """
        self.ensure_one()

        if len(mappings) == len(chunks):
            return True

        settled = mappings.mapped('txn_id.invoice_id')
        dropped = self.env['account.move'].browse([x for x, __ in chunks]) - settled

        raise ValidationError(_(
            'QuickBooks applied the payment "%(payment)s" to %(applied)s of the %(sent)s '
            'documents it was sent for. Not applied: %(dropped)s. The amount is held as an '
            'unapplied credit in QuickBooks instead, which usually means those documents are '
            'already settled there. Check them before exporting the payment again.'
        ) % {
            'payment': self.display_name,
            'applied': len(mappings),
            'sent': len(chunks),
            'dropped': ', '.join(dropped.mapped('display_name')) or '-',
        })

    def _prepare_qbo_api_lib_instance(self, qi_id: int, chunks: list):
        qi = self.env['quickbooks.integration'].browse(qi_id)
        invoice = self.env['account.move'].browse(chunks[0][0])

        qbo_lib_model = self._init_qbo_lib_instance(self.map_type)

        if qi.derive_partner_from_invoice_to_payment:
            partner = invoice.get_partner_for_qbo_export()
        else:
            partner = self.partner_id

        partner_mapping = partner._get_qbo_mapping(qi.id, invoice.qbo_partner_type)

        if invoice.is_customer_move_type:
            qbo_lib_model.CustomerRef = {
                'value': partner_mapping.qbo_id,
            }
            qbo_lib_model.PaymentRefNum = self._prepare_pay_ref_number()

            pay_method_rel = self._get_qbo_payment_method_mapping()
            qbo_lib_model.PaymentMethodRef = {
                'value': pay_method_rel.qbo_id,
            }
        else:
            qbo_lib_model.VendorRef = {
                'value': partner_mapping.qbo_id,
            }
            qbo_lib_model.PayType = 'Check'  # We are not supporting `CreditCard` for now
            qbo_lib_model.DocNumber = self._prepare_pay_ref_number()

            pay_account = self.journal_id.default_account_id
            account_rel = pay_account.get_qbo_related_account(qi.id)

            qbo_lib_model.CheckPayment = {
                'BankAccountRef': {
                    'name': account_rel.qbo_name,
                    'value': account_rel.qbo_id,
                }
            }

        currency = self.currency_id
        if currency != qi.currency_id:
            qbo_lib_model.ExchangeRate = currency.inverse_rate

        qbo_lib_model.TotalAmt = self.amount
        qbo_lib_model.CurrencyRef = {'value': currency.name}
        qbo_lib_model.TxnDate = self.date.strftime('%Y-%m-%d')

        lines = []
        for invoice_id, amount in chunks:
            line = self.env['account.move'].browse(invoice_id) \
                ._create_qbo_payment_line(amount)
            lines.append(line)

        qbo_lib_model.Line = lines

        return qbo_lib_model

    def _get_qbo_payment_method_mapping(self):
        self.ensure_one()

        qi = self.company_id.quickbooks_integration
        mapping = self.env['qbo.map.payment.method']

        if self.payment_method_line_id:
            mapping = self.env['qbo.map.payment.method'].search([
                ('payment_method_line_id', '=', self.payment_method_line_id.id),
                ('quickbooks_integration_id', '=', qi.id),
            ], limit=1)

        if not mapping:
            mapping = self.journal_id.get_qbo_related_payment_method(qi.id)

        return mapping

    def _check_qbo_requirements(self, *args, **kw):
        self.ensure_one()

        if not self.qbo_reconciled_ids:
            raise ValidationError(_(
                'There is no any related invoice for the payment "%s".' % self.name
            ))

        if not self.qbo_applied_documents:
            raise ValidationError(self._qbo_nothing_applied_message())

        journal = self.journal_id
        if not journal:
            raise ValidationError(_(
                'Journal is not defined for the payment "%s".' % self.display_name
            ))

        qi = self.company_id.quickbooks_integration

        if self.partner_type == 'customer':
            self._get_qbo_payment_method_mapping()
        else:
            account = journal.default_account_id

            if not account:
                raise ValidationError(_(
                    'Account for the journal "%s" is not defined.' % (journal.name)
                ))

            account.get_qbo_related_account(qi.id)

    def _qbo_nothing_applied_message(self):
        """Why a payment holding documents still applies to none of them.

        Only one thing reaches here now that an unreconciled payment is spread
        over its documents: every one of them already owes nothing, so there is
        no amount to put on any line and a QuickBooks payment of no lines would
        say nothing at all.
        """
        self.ensure_one()

        return _(
            'The payment "%(payment)s" applies to nothing: %(documents)s already owe '
            'nothing, and the payment is not reconciled with them. Check those documents '
            'before exporting the payment again.'
        ) % {
            'payment': self.display_name,
            'documents': ', '.join(self.qbo_reconciled_ids.mapped('display_name')) or '-',
        }

    def _prepare_pay_ref_number(self):
        name = self.name
        txn_id = self.env.context.get('default_txn_id')
        if txn_id:
            record = self.env['qbo.map.account.move'].browse(txn_id)
            name = f'{name}-{record.qbo_id}'
        return name[:21]

    def _get_condition_for_check_qbo_duplicate(self, qbo_lib_model):
        if qbo_lib_model.is_billpayment:
            return 'DocNumber = %s' % quote_qbo_query_value(qbo_lib_model.DocNumber)
        return 'PaymentRefNum = %s' % quote_qbo_query_value(qbo_lib_model.PaymentRefNum)

    def _get_qbo_mapping(self, qi_id: int = None, map_type: str = None):
        """Mapping of this document, defaulting to its own connection and type.

        Both arguments are part of the signature of the base method, so they are
        honoured when given: silently answering about a different connection than
        the one asked for is how a document ends up exported twice.
        """
        self.ensure_one()

        qi = self.env['quickbooks.integration'].browse(qi_id) if qi_id else self.quickbooks_integration
        map_type = (map_type or self.map_type).lower()

        return self.qbo_mapping_ids \
            .filtered(
                lambda r: r.qbo_lib_type == map_type and r.quickbooks_integration_id == qi
            )

    def to_qbo_json(self):
        self._check_qbo_requirements()

        invoices = self.qbo_reconciled_ids

        if not all(x.is_qbo_sync_done for x in invoices):
            names = invoices.filtered(lambda x: not x.is_qbo_sync_done).mapped('display_name')
            raise ValidationError(_('Please export the related invoice first: %s!' % ', '.join(names)))

        qi = self.quickbooks_integration

        chunks = self.qbo_applied_documents
        qbo_lib_model = self._prepare_qbo_api_lib_instance(qi.id, chunks)
        payload = qbo_lib_model.to_dict()

        return self.env['quickbooks.help.wizard'].create_and_run_as_json(
            f'DEBUG: {self.name} [{self.map_type}]',
            payload,
        )
