# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo import _, api, models
from odoo.exceptions import UserError

from odoo.addons.integration_queue_job.job import Job


class QueueJob(models.Model):
    _inherit = 'queue.job'

    @api.model
    def cancel_failed_jobs_by_identity_key(self, identity_keys):
        """Housekeeping of the connector's own failed jobs.

        Takes one key or many: a failed job never keeps a new one from being
        queued, since jobs are deduplicated while they are pending, enqueued or
        waiting. So this is tidying up, and it is done once per export instead of
        once per record.

        It runs on behalf of whoever triggers an export, who is not necessarily a
        job queue manager, so it must not depend on the access rights to the queue.
        """
        if isinstance(identity_keys, str):
            identity_keys = [identity_keys]

        identity_keys = [x for x in identity_keys if x]

        if not identity_keys:
            return

        self.sudo().search([
            ('state', '=', 'failed'),
            ('identity_key', 'in', identity_keys),
        ]).button_cancelled()

    def action_run_now(self):
        """Run the job synchronously in real time (debug tool)."""
        self.ensure_one()
        job = Job.load(self.env, self.uuid)
        job.set_started()
        job.store()
        try:
            result = job.perform()
            job.set_done(result=result)
            job.enqueue_waiting()
            job.store()
        except Exception as e:
            raise UserError(_('Job failed:\n\n%s') % str(e))
