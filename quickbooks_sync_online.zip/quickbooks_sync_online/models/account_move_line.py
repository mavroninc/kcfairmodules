# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo import models, fields

from ..tools import (
    TAXABLE,
    NON_TAXABLE,
    ITEM_BASED_EXPENSE_LINE_DETAIL,
    ACCOUNT_BASED_EXPENSE_LINE_DETAIL,
)


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    is_qbo_sync_done = fields.Boolean(
        related='product_id.is_qbo_sync_done',
    )

    @property
    def qbo_partner_type(self):
        return self.move_id.qbo_partner_type

    @property
    def display_type_product(self):
        return self.display_type == 'product'

    @property
    def qbo_detail_type(self):
        """The kind of line QuickBooks is being handed for this one.

        A bill line without a product is an expense booked against an account,
        which is how bills are ordinarily entered in QuickBooks -- the API takes
        such a line on its own and alongside item lines in the same bill, and it
        refuses an item line whose `ItemRef` is missing. The move-level
        `qbo_detail_type` cannot answer this, because one bill can hold both
        kinds; it stays as it is for the import, which reads Qty and UnitPrice
        out of the body by that name.
        """
        self.ensure_one()

        if self.move_id.is_customer_move_type:
            return self.move_id.qbo_detail_type

        return ITEM_BASED_EXPENSE_LINE_DETAIL if self.product_id \
            else ACCOUNT_BASED_EXPENSE_LINE_DETAIL

    def remove_move_reconcile(self):
        # ToDo: Synchronous work of confirmations and cancellations for payments in Odoo / QuickBooks.
        super(AccountMoveLine, self).remove_move_reconcile()

    def _create_qbo_invoice_line(self):
        self.ensure_one()

        if self.tax_ids:
            product_tax = self.tax_ids[:1]
        else:
            tax_field_name = self.move_id._get_tax_field_name()
            product_tax = getattr(self.product_id, tax_field_name)[:1]

        if product_tax and product_tax.price_include:
            price_unit = self.price_subtotal / (self.quantity or 1)
        else:
            price_unit = self.price_unit * (1 - self.discount / 100)

        qi = self.move_id.quickbooks_integration

        if qi.qb_is_us_company:
            taxcode_value = TAXABLE if product_tax else NON_TAXABLE
        else:
            taxcodes = self.tax_ids.find_qbo_taxcodes(qi.id, self.qbo_partner_type)
            taxcode_value = taxcodes[0] if taxcodes else ''

        taxcode_line_detail = self.qbo_detail_type

        detail = {
            'TaxCodeRef': {
                'value': taxcode_value,
            },
        }

        if taxcode_line_detail == ACCOUNT_BASED_EXPENSE_LINE_DETAIL:
            # The expense is the account, and the detail carries no quantity.
            detail['AccountRef'] = {
                'value': self.account_id.get_qbo_related_account(qi.id).qbo_id,
            }
        else:
            detail['Qty'] = self.quantity
            detail['UnitPrice'] = price_unit

        export_line = {
            'Description': self.name,
            'Amount': self.price_subtotal,
            'DetailType': taxcode_line_detail,
            taxcode_line_detail: detail,
        }

        customer_move_type = self.move_id.is_customer_move_type

        if not customer_move_type:
            customer = self.purchase_line_id.sale_line_id.order_id.partner_id

            if customer:
                customer = customer._ensure_qbo_currency(self.move_id)
                qbo_partner = customer._get_qbo_mapping(qi.id, 'customer')

                export_line[taxcode_line_detail]['CustomerRef'] = {
                    'value': qbo_partner.qbo_id,
                }

        if not self.product_id:
            return export_line

        if not qi.include_product_to_invoice and customer_move_type:
            return export_line

        if qi.sync_product_as_category:
            record = self.product_id.categ_id
        else:
            record = self.product_id

        mapping = record._get_qbo_mapping(qi.id, 'item')

        export_line[taxcode_line_detail]['ItemRef'] = {
            'name': mapping.qbo_name,
            'value': mapping.qbo_id,
        }

        return export_line
