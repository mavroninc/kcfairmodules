# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo import models

from ..tools import expected_one


def qbo_id_sort_key(qbo_id: str):
    """QuickBooks ids are numeric strings: order them as numbers, not as text."""
    return (0, int(qbo_id)) if qbo_id.isdigit() else (1, qbo_id)


class AccountTax(models.Model):
    _inherit = 'account.tax'

    def find_qbo_taxcodes(self, qi_id: int, partner_type: str) -> list:
        """The QuickBooks tax codes that carry every one of these taxes.

        Ordered, and the order is the point. A QuickBooks tax rate belongs to as
        many tax codes as the company has combinations built on it -- a Canadian
        GST rate sits in "GST only" and in every "GST + PST" code alike -- so an
        intersection holding more than one code is ordinary rather than exotic.
        The callers take the first one.

        It used to be `list(set.intersection(...))`, and the iteration order of a
        set of strings is not stable between processes: the same line exported by
        two queue workers went to QuickBooks under two different tax codes.
        """
        if not self:
            return []

        codes = []
        for tax in self:
            tax_mapping = tax.get_qbo_tax(qi_id)
            taxcodes = tax_mapping.find_taxcodes(partner_type, raise_error=True)

            codes.append(set(taxcodes))

        return sorted(set.intersection(*codes), key=qbo_id_sort_key)

    @expected_one
    def get_qbo_tax(self, qi_id: int):
        """Get related map instance."""
        return self._get_qbo_mapping(qi_id)

    def _get_qbo_mapping(self, qi_id: int, *args, **kwargs):
        """Uses in the 'try_to_map()' method."""
        return self.env['qbo.map.tax'].search([
            ('tax_id', '=', self.id),
            ('quickbooks_integration_id', '=', qi_id),
        ])
