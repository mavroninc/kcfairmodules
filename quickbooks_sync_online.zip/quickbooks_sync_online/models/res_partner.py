# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import logging

import pycountry

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

from ..tools import two_dicts_are_equal, quote_qbo_query_value
from ..quickbooks_api import QboDuplicateNameError


_logger = logging.getLogger(__name__)

TRACK_FIELDS_CONTACT = [
    'name', 'parent_id', 'phone', 'email',
    'country_id', 'city', 'state_id', 'street', 'street2', 'zip',
]

# QuickBooks caps DisplayName at 500 characters and refuses these three in it. The
# colon is how it separates a customer from its sub-customers.
#
# `_prepare_qbo_name` spends part of those 500 on a type suffix and, when the
# currency is not the company's, a currency one. The budget below reserves room for
# both, so a name this check passes cannot be refused over there -- at the cost of
# turning away a handful of lengths that a base-currency contact would have squeezed
# through, which beats a limit that moves with the document being exported.
QBO_DISPLAY_NAME_MAX_LENGTH = 500
QBO_NAME_MAX_LENGTH = QBO_DISPLAY_NAME_MAX_LENGTH - len(' (customer)') - len(' [XXX]')
QBO_NAME_REFUSED_CHARACTERS = {
    ':': 'a colon',
    '\t': 'a tab',
    '\n': 'a line break',
}


class ResPartner(models.Model):
    _name = 'res.partner'
    _inherit = [
        'res.partner',
        'quickbooks.mapping.mixin',
        'quickbooks.export.mixin',
    ]

    qbo_mapping_ids = fields.One2many(
        comodel_name='qbo.map.partner',
        inverse_name='partner_id',
        readonly=False,
    )
    qbo_sync_label = fields.Char(
        string='QuickBooks Synced As',
        compute='_compute_qbo_sync_label',
    )

    @api.depends('qbo_mapping_ids')
    def _compute_qbo_sync_label(self):
        """What the contact is synced as, for the badge to say so.

        A contact is the one record that can hold a card of each type at once --
        the same company is often both a customer and a supplier -- so
        `is_qbo_sync_done` alone leaves it open which of the two was exported.
        """
        qi = self.env.company.quickbooks_integration
        labels = dict(
            self.env['qbo.map.partner']._fields['qbo_lib_type'].get_description(self.env)['selection']
        )

        for rec in self:
            types = rec.qbo_mapping_ids \
                .filtered(lambda r: r.quickbooks_integration_id == qi) \
                .mapped('qbo_lib_type')

            rec.qbo_sync_label = ', '.join(
                labels.get(name, name) for name in sorted(set(types))
            )

    @property
    def is_a_contact_type(self):
        return self.type == 'contact'

    def get_billing_for_qb(self):
        self.ensure_one()
        record_id = self.address_get(['invoice'])['invoice']
        return self.browse(record_id)

    def get_shipping_for_qb(self):
        self.ensure_one()
        record_id = self.address_get(['delivery'])['delivery']
        return self.browse(record_id)

    @property
    def is_shipping_eq_billing(self):
        billing = self.get_billing_for_qb()
        shipping = self.get_shipping_for_qb()

        return two_dicts_are_equal(
            billing._format_to_qbo_address(),
            shipping._format_to_qbo_address(),
        )

    def write(self, vals):
        result = super(ResPartner, self).write(vals)

        if self.env.context.get('no_mark_quickbooks_update'):
            return result

        if set(TRACK_FIELDS_CONTACT).intersection(set(vals.keys())):
            self.filtered('qbo_mapping_ids').mark_for_qbo_update()

        return result

    def action_export_to_quickbooks(self):
        company = self.env.company
        qi = company.quickbooks_integration

        if not qi:
            # No active connection for this company: there is nothing to export to,
            # and a job built without one only fails in the worker.
            return self._raise_jobs_notification(0)

        requested_types = self.env.context.get('with_qbo_partner_type')

        if not requested_types:
            return self.env['quickbooks.partner.type.wizard'] \
                .with_context(active_partner_ids=self.ids) \
                .open_form()

        count = 0
        for qbo_partner_type in requested_types.split(','):  # "customer,vendor"
            count += self._action_export_to_quickbooks(qi.id, qbo_partner_type)

        return self._raise_jobs_notification(count)

    def _action_export_to_quickbooks(self, qi_id: int, qbo_partner_type: str):
        count = 0
        qi = self.env['quickbooks.integration'].browse(qi_id)

        identity_keys = []

        for record in self.with_context(company_id=qi.company_id.id).filtered(lambda x: x.is_a_contact_type):
            mapping = record._get_qbo_mapping(qi_id, qbo_partner_type)

            if mapping:
                count += 1
                job_kwargs = record._job_kwargs_qbo_transaction(map_type=qbo_partner_type, update=True)
                mapping.with_delay(**job_kwargs).update_qbo_one()
            else:
                count += 1
                job_kwargs = record._job_kwargs_qbo_transaction(map_type=qbo_partner_type)
                record.with_delay(**job_kwargs).export_qbo_one(qi_id, qbo_partner_type)

            identity_keys.append(job_kwargs['identity_key'])

        self._mark_qbo_failed_jobs_as_cancel(identity_key=identity_keys)

        return count

    def export_qbo_one(self, qi_id: int, qbo_partner_type: str):
        self.ensure_one()

        if self.is_excluded_from_qbo_sync:
            return self._get_qbo_mapping(qi_id, qbo_partner_type)

        # 1. Export parent if needed
        if self._need_to_export_qbo_parent(qbo_partner_type):
            parent = self.parent_id
            if not parent._get_qbo_mapping(qi_id, qbo_partner_type):
                parent.export_qbo_one(qi_id, qbo_partner_type)

        # 2. Export self
        qi = self.env['quickbooks.integration'].browse(qi_id)
        self = self.with_company(qi.company_id)

        self._check_qbo_requirements(qi_id)

        qbo_lib_model = self \
            .with_context(with_qbo_lib_type=qbo_partner_type) \
            ._prepare_qbo_api_lib_instance(qi_id)

        try:
            mapping = self._export_qbo_one(qi_id, qbo_lib_model)
        except QboDuplicateNameError:
            mapping = self._export_qbo_one_after_duplicate_check(qi_id, qbo_lib_model)

        self.unmark_for_qbo_update()

        return mapping

    def _prepare_qbo_api_lib_instance(self, qi_id: int, qbo_lib_model=None):
        qbo_lib_type = self.env.context['with_qbo_lib_type']

        if not qbo_lib_model:
            qbo_lib_model = self._init_qbo_lib_instance(qbo_lib_type)

        # 1. Set basic fields
        qbo_lib_model.Active = self.active
        qbo_lib_model.DisplayName = self._prepare_qbo_name(qi_id, qbo_lib_type)
        qbo_lib_model.CompanyName = self._qbo_company_name(qi_id, qbo_lib_type)

        # GivenName and FamilyName are the contact person behind the card -- "Grace
        # Pariente" for the customer "Cool Cars" -- and Odoo keeps no such split:
        # `name` is the whole thing. Writing it into GivenName used to overwrite
        # that person's first name on every update while leaving their surname, so
        # "Cool Cars" would end up staffed by "Cool Cars Pariente". They are left
        # out, and the update, which reads the card before writing it, keeps
        # whatever the QuickBooks side holds.
        qbo_lib_model.PrimaryPhone = {'FreeFormNumber': self.phone or ''}
        qbo_lib_model.WebAddr = {'URI': self.website or ''}
        qbo_lib_model.CurrencyRef = {
            'value': self.env.context.get('with_currency_name') or self.currency_id.name or '',
        }
        qbo_lib_model.PrimaryEmailAddr = {'Address': self.email or ''}

        billing = self.get_billing_for_qb()
        shipping = self.get_shipping_for_qb()

        if qbo_lib_model.is_customer:  # 2. Set customer fields
            bill_with_parent_ = False

            if self._need_to_export_qbo_parent(qbo_lib_type):
                parent_mapping = self.parent_id._get_map_instance_or_raise(qi_id, qbo_lib_type)

                qbo_lib_model.Job = True  # Requires for sub-customers
                qbo_lib_model.ParentRef = {'value': parent_mapping.qbo_id}

                # Whether a sub-customer is billed to its parent is a choice the
                # QuickBooks user makes, and Odoo has no field that says it. Nor can
                # it be read off the addresses: a child of type `contact` shares the
                # address of its parent by force -- res.partner._fields_sync pushes
                # any address written on a contact child back up to the parent, which
                # hands it down to the others -- and a child of any other type never
                # gets here, because the export keeps to contacts. The two are always
                # equal, so the comparison that used to stand here decided nothing.
                # A first export leaves the flag off and sends the address; later ones
                # carry over whatever QuickBooks holds.
                mapping = self._get_qbo_mapping(qi_id, qbo_lib_type)
                if mapping:
                    bill_with_parent_ = mapping.bill_with_parent

            if bill_with_parent_:
                qbo_lib_model.BillWithParent = True  # No billing address for sub-customers
            else:
                qbo_lib_model.BillWithParent = False
                qbo_lib_model.BillAddr = billing._format_to_qbo_address()

                # 3. Assign shipping address for both customers and vendors
                if not self.is_shipping_eq_billing:
                    qbo_lib_model.ShipAddr = shipping._format_to_qbo_address()

        else:  # 4. Set vendor fields. There is no shipping address for vendors.
            qbo_lib_model.BillAddr = billing._format_to_qbo_address()

        return qbo_lib_model

    def _get_condition_for_check_qbo_duplicate(self, qbo_lib_model):
        return 'DisplayName = %s' % quote_qbo_query_value(qbo_lib_model.DisplayName)

    def _prepare_qbo_name(self, qi_id: int, qbo_lib_type: str):
        name = f'{self.name} ({qbo_lib_type})'
        qi = self.env['quickbooks.integration'].browse(qi_id)

        currency_name = self.env.context.get('with_currency_name') or self.currency_id.name
        if currency_name and not qi.currency_name_belong_odoo_company(currency_name):
            postfix = f' [{currency_name}]'

            if not name.endswith(postfix):
                name += postfix

        return name

    def _qbo_company_name(self, qi_id: int, map_type: str) -> str:
        """The company QuickBooks should show for this contact, or ''.

        A sub-customer carries the company it belongs to, not its own name, and
        `commercial_company_name` is Odoo's own answer to which that is -- reading
        `is_company` off the contact itself left the field empty on every child
        card.

        A contact of nobody is its own commercial partner, so the same field
        answers with its own name, and that has to be told apart from a company
        naming itself. Odoo 19 could ask `is_company`, a plain boolean somebody
        set, and could read a typed-in company off `company_name`. Odoo 20
        computes the first from the Tax ID -- which a QuickBooks customer
        generally does not carry, so it answers False for contacts that have been
        companies here for years -- and removed the second outright. Sending
        `commercial_company_name` regardless put every individual into QuickBooks
        as a company of the same name.

        So `is_company` is taken when it is set, and otherwise the card already
        mapped for this connection answers: `qbo_company_name` is the CompanyName
        QuickBooks itself holds, which is what keeps "John Smith of Acme Inc" from
        losing Acme Inc on the way back. A contact with neither a Tax ID nor a
        card has nothing to go on and is sent as an individual.
        """
        self.ensure_one()

        if self.parent_id:
            return self.commercial_company_name or ''

        if self.is_company:
            return self.name or ''

        mapping = self._get_qbo_mapping(qi_id, map_type)[:1]

        return mapping.qbo_company_name or ''

    def _get_qbo_mapping(self, qi_id: int, map_type: str):
        mappings = super(ResPartner, self)._get_qbo_mapping(qi_id, map_type)

        if not mappings:
            return mappings

        currency_name = self.env.context.get('with_currency_name') or str(self.currency_id.name or '')

        if not currency_name:
            return mappings

        mappings_ = mappings.filtered(
            lambda x: x._extract_currency_name(lower=True) == currency_name.lower()
        )
        return mappings_

    def _format_to_qbo_country_code(self):
        """Convert Odoo ISO 3166-1 alpha-2 country code to QBO alpha-3."""
        self.ensure_one()
        country_code = self.country_id.code or ''
        if not country_code:
            return ''

        py_country = pycountry.countries.get(alpha_2=country_code)
        if py_country:
            return py_country.alpha_3

        _logger.warning(
            'Unable to convert country code "%s" to ISO alpha-3 for partner "%s".',
            country_code,
            self.display_name,
        )
        return country_code

    def _format_to_qbo_address(self):
        return {
            'City': self.city or '',
            'Country': self._format_to_qbo_country_code(),
            'CountrySubDivisionCode': self.state_id.name or '',
            'Line1': self.street or '',
            'Line2': self.street2 or '',
            'PostalCode': self.zip or '',
        }

    def _format_to_export_qbo_address(self):
        """Address of a document, carrying the recipient's name in its first lines.

        A QuickBooks document prints the lines of its own BillAddr / ShipAddr and
        nothing else -- the customer it refers to is not part of that printout. So
        the name has to travel inside the address, which is what separates this
        from `_format_to_qbo_address` used for the contact card itself.

        The company comes from `commercial_company_name` rather than `company_name`:
        the latter only holds a company that is not a partner of its own, so for an
        ordinary company-and-contact pair it is empty and the company name would be
        dropped. It is skipped when the partner is that company, to avoid printing
        the same name twice.
        """
        result = self._format_to_qbo_address()

        street = result.pop('Line1')
        street2 = result.pop('Line2')

        company_name = self.commercial_company_name
        partner_name = self.name

        lines = [] if company_name == partner_name else [company_name]
        lines += [partner_name, street, street2]

        for number, line in enumerate(filter(None, lines), start=1):
            result['Line%s' % number] = line

        return result

    def _ensure_qbo_currency(self, rocord: models.Model):
        currency_name = rocord.currency_id.name
        if not rocord.quickbooks_integration.currency_name_belong_odoo_company(currency_name):
            return self.with_context(with_currency_name=currency_name)
        return self

    def to_qbo_json(self):
        self.ensure_one()
        ctx = {
            'with_qbo_lib_type': 'customer',
        }
        qi = self.env.company.quickbooks_integration

        # 1. Serialize Customer
        mapping_c = self._get_qbo_mapping(qi.id, 'customer')

        if mapping_c:
            qbo_lib_model_c_ = mapping_c.fetch_qbo_one()
            qbo_lib_model_c = self.with_context(**ctx) \
                ._prepare_qbo_api_lib_instance(qi.id, qbo_lib_model=qbo_lib_model_c_)
        else:
            qbo_lib_model_c = self.with_context(**ctx)._prepare_qbo_api_lib_instance(qi.id)

        # 2. Serialize Vendor
        mapping_v = self._get_qbo_mapping(qi.id, 'vendor')
        ctx = {
            'with_qbo_lib_type': 'vendor',
        }
        if mapping_v:
            qbo_lib_model_v_ = mapping_v.fetch_qbo_one()
            qbo_lib_model_v = self.with_context(**ctx) \
                ._prepare_qbo_api_lib_instance(qi.id, qbo_lib_model=qbo_lib_model_v_)
        else:
            qbo_lib_model_v = self.with_context(**ctx)._prepare_qbo_api_lib_instance(qi.id)

        return self.env['quickbooks.help.wizard'].create_and_run_as_json(
            f'DEBUG: {self.name}',
            {
                'CUSTOMER JSON': qbo_lib_model_c.to_dict(),
                'VENDOR JSON': qbo_lib_model_v.to_dict(),
            },
        )

    def _update_addresses_from_mapping(self, mapping_id: int):
        self.ensure_one()

        mapping = self.env['qbo.map.partner'].browse(mapping_id)
        values = mapping._prepare_odoo_values()

        billing_input = values['billing']
        shipping_input = values['shipping']

        # 1. Update billing address
        billing = self
        if billing_input:
            if not mapping.bill_with_parent:
                if self._has_empty_address():
                    # If the partner has an empty address, write the billing address to the partner
                    self.with_context(no_mark_quickbooks_update=True).write(billing_input)
                elif self._current_address_match_dict(billing_input):
                    # If the billing address is the same as the current address, do nothing
                    pass
                else:
                    # If the billing address is different from the current address, get or create a child address-card
                    billing = self._get_or_create_child_address('invoice', billing_input)

        # 2. Update shipping address
        shipping = self.browse()
        if shipping_input:
            # If the shipping address is different from the billing address, get or create a child address-card
            if not two_dicts_are_equal(shipping_input, billing_input):
                shipping = self.get_shipping_for_qb()
                # If the shipping address is different from the current address, get or create a child address-card
                if not shipping._current_address_match_dict(shipping_input):
                    shipping = self._get_or_create_child_address('delivery', shipping_input)

        return billing, shipping

    def _update_addresses_from_data(
        self,
        billing_input: dict,
        shipping_input: dict,
        no_other_type_create: bool = False,
    ):
        self.ensure_one()

        # 1. Get or create billing address
        billing = self
        if billing_input:

            if self._has_empty_address():
                self.with_context(no_mark_quickbooks_update=True).write(billing_input)
            elif self._current_address_match_dict(billing_input):
                pass
            else:
                type_ = 'invoice' if no_other_type_create else 'other'
                billing = self._get_or_create_child_address(type_, billing_input)

        # 2. Get or create shipping address
        shipping = self.browse()
        if shipping_input:
            if not two_dicts_are_equal(shipping_input, billing_input):
                shipping = self.get_shipping_for_qb()
                if not shipping._current_address_match_dict(shipping_input):
                    type_ = 'delivery' if no_other_type_create else 'other'
                    shipping = self._get_or_create_child_address(type_, shipping_input)

        return billing, shipping

    def _check_qbo_requirements(self, *args, **kw):
        super()._check_qbo_requirements(*args, **kw)
        self._check_name_qbo()

        return True

    def _check_name_qbo(self):
        """Refuse a name QuickBooks will refuse, before the export spends a call on it.

        Both limits belong to QuickBooks and neither is visible from Odoo: it caps
        DisplayName, which carries the name with its suffixes, and rejects a colon,
        a tab or a line break in it. Left to the API they come back as error 2050 or
        2040, which reach the user as a failed job carrying a QuickBooks code and no
        hint of which contact caused it or why.
        """
        self.ensure_one()

        name = self.name or ''

        refused = [label for char, label in QBO_NAME_REFUSED_CHARACTERS.items() if char in name]
        if refused:
            # The colon is the one users hit, and it is worth saying why.
            reason = _(' -- it separates a customer from its sub-customers with a colon') \
                if ':' in name else ''

            raise ValidationError(_(
                'The name of the contact "%(name)s" contains %(characters)s, which '
                'QuickBooks does not accept in a contact name%(reason)s. Rename the '
                'contact before exporting it.'
            ) % {
                'name': self.display_name,
                'characters': ', '.join(refused),
                'reason': reason,
            })

        if len(name) > QBO_NAME_MAX_LENGTH:
            raise ValidationError(_(
                'The name of the contact "%(name)s" is %(length)s characters long, and '
                'QuickBooks accepts at most %(limit)s. Shorten it before exporting it.'
            ) % {
                'name': self.display_name,
                'length': len(name),
                'limit': QBO_NAME_MAX_LENGTH,
            })

        return True

    def _need_to_export_qbo_parent(self, qbo_partner_type: str):
        parent = self.parent_id
        return bool(parent and not parent.is_excluded_from_qbo_sync and qbo_partner_type.lower() == 'customer')

    def _has_empty_address(self):
        return all(not self[field] for field in self._get_address_match_fields())

    def _get_address_match_fields(self):
        return ['country_id', 'state_id', 'zip', 'city', 'street', 'street2']

    def _prepare_address_match_dict(self):
        """ Prepare a dictionary of address match fields for the partner """
        result = {}
        for field in self._get_address_match_fields():
            value = self[field]
            if isinstance(value, models.Model):
                value = value.id

            result[field] = value

        return result

    def _current_address_match_dict(self, values: dict):
        self_values = self._prepare_address_match_dict()
        return two_dicts_are_equal(self_values, values)

    def _get_or_create_child_address(self, address_type: str, values: dict):
        if not values:
            return self.env['res.partner']

        # Reuse existing address if an identical one exists.
        address = self.with_context(active_test=False).child_ids.filtered(
            lambda x: x.type == address_type
            and self.country_id == x.country_id
        )

        domain = []

        state_id = values['state_id'] or False
        domain.append(('state_id', '=', state_id))

        street1 = values['street']
        if street1:
            domain.append(('street', '=ilike', street1))
        else:
            domain.append(('street', 'in', ['', False]))

        street2 = values['street2']
        if street2:
            domain.append(('street2', '=ilike', street2))
        else:
            domain.append(('street2', 'in', ['', False]))

        city = values['city']
        if city:
            domain.append(('city', '=ilike', city))
        else:
            domain.append(('city', 'in', ['', False]))

        zip_code = values['zip']
        if zip_code:
            domain.append(('zip', '=ilike', zip_code))
        else:
            domain.append(('zip', 'in', ['', False]))

        address = address.filtered_domain(domain)[:1]

        if address:
            if not address.active:
                address.with_context(no_mark_quickbooks_update=True).write({'active': True})
            return address

        return self.with_context(no_mark_quickbooks_update=True) \
            .create({
                'name': self.name,
                'type': address_type,
                'parent_id': self.id,
                **values,
            })
