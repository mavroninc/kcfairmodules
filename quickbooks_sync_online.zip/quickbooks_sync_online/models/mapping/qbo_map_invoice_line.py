# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo import fields, models
from odoo.tools.float_utils import float_round

from ...tools import ExtractNode, TaxSuiter


class QboMapInvoiceLine(models.Model):
    _name = 'qbo.map.invoice.line'
    _inherit = 'qbo.tax.line.abstract'
    _description = 'Qbo Map Invoice Line'

    is_delivery_line = fields.Boolean(
        string='Is Delivery Line',
    )

    is_discount_line = fields.Boolean(
        string='Is Discount Line',
    )

    invoice_map_id = fields.Many2one(
        comodel_name='qbo.map.account.move',
        string='Map Invoice',
        ondelete='cascade',
    )

    def _prepare_odoo_values(self):
        invoice = self.invoice_map_id.invoice_id
        invoice.ensure_one()

        body = self.body_dict

        tracking_num = ''
        if self.is_delivery_line:
            product = invoice.quickbooks_integration.get_shipping_product()
            tracking_num_ = self.invoice_map_id.extract_node('TrackingNum', '')
            if tracking_num_:
                tracking_num = f'\n- Tracking Number: {tracking_num_}'
        elif self.is_discount_line:
            product = invoice.quickbooks_integration.get_discount_product()
        elif self.item_map_id:
            product = self.item_map_id.ensure_odoo_record()
        else:
            product = self.env['product.product']

        line_detail = invoice.qbo_detail_type

        if self.is_delivery_line or self.is_discount_line:
            quantity = 1
            amount = ExtractNode.extract_raw(body, 'Amount', 0)
            if self.is_discount_line:
                amount = -amount
        else:
            quantity = ExtractNode.extract_raw(body, f'{line_detail}.Qty', False)
            amount = ExtractNode.extract_raw(body, f'{line_detail}.UnitPrice', False)

        values = {
            'product_id': product.id,
            'quantity': quantity,
            'price_unit': amount,
            'tax_ids': [(6, 0, self.tax_map_ids.mapped('tax_id').ids)],
        }

        name = ExtractNode.extract_raw(body, 'Description', False) or product.name
        if tracking_num:
            name += f'{tracking_num}'

        values['name'] = name

        return values

    def _get_amount(self):
        """Absolute line ``Amount`` from stored QuickBooks JSON (weight for discount spread)."""
        self.ensure_one()
        return abs(float(ExtractNode.extract_raw(self.body_dict, 'Amount', 0) or 0))

    def _apply_post_discount_to_prepared_line_dicts(self, total_discount: float):
        """
        Build ``_prepare_odoo_values()`` dicts for each line in ``self`` (non-discount lines only),
        spread ``total_discount`` across allocation recipients, and return the list in record order.
        """
        precision_digits = self[:1].invoice_map_id.invoice_id.currency_id.decimal_places
        shares = self._calculate_quickbooks_discount_shares(total_discount, precision_digits)

        values_list = []
        for line in self:
            prepared = line._prepare_odoo_values()
            share = shares.get(line.id)

            if share:
                self._apply_discount_share_to_prepared_values(prepared, share)

            values_list.append(prepared)

        return values_list

    def _filter_lines_for_discount_allocation(self):
        """QBO-taxable lines only (``TaxCodeRef`` not in NON/NON-taxable); fallback to all if none."""
        taxable = self.filtered(lambda line: TaxSuiter.is_taxable(line.body_dict))
        return taxable if taxable else self

    def _calculate_quickbooks_discount_shares(self, total_discount: float, precision_digits: int) -> dict:
        """
        Split ``total_discount`` across QBO-taxable lines in ``self``, by each line's ``Amount`` weight.

        Non-taxable lines in ``self`` receive no share (aligned with ``TaxSuiter`` post-discount base).
        If no taxable line exists, allocation falls back to all lines in ``self``.

        :return: dict ``{map_line.id: share}``; last recipient absorbs rounding remainder.
        """
        if not self or total_discount <= 0:
            return {}

        recipient_lines = self._filter_lines_for_discount_allocation()
        weights = [(line, line._get_amount()) for line in recipient_lines]
        total_w = sum(w for __, w in weights)
        shares = {}
        n = len(weights)

        if not n:
            return shares

        if total_w <= 0:
            allocated = 0.0
            for i, (line, _) in enumerate(weights):
                if i == n - 1:
                    shares[line.id] = float_round(total_discount - allocated, precision_digits=precision_digits)
                else:
                    part = float_round(total_discount / n, precision_digits=precision_digits)
                    shares[line.id] = part
                    allocated += part
            return shares

        allocated = 0.0
        for i, (line, w) in enumerate(weights):
            if i == n - 1:
                shares[line.id] = float_round(total_discount - allocated, precision_digits=precision_digits)
            else:
                part = float_round(total_discount * (w / total_w), precision_digits=precision_digits)
                shares[line.id] = part
                allocated += part

        return shares

    @staticmethod
    def _apply_discount_share_to_prepared_values(prepared_values, share):
        """
        Shrink line subtotal by ``share`` so Odoo taxes match QBO post-discount base (mutates ``prepared_values``).

        :param prepared_values: dict of line values to be prepared for Odoo
        :param share: float amount to be subtracted from the line subtotal
        """
        if not share:
            return

        qty = prepared_values.get('quantity')
        if qty in (False, None):
            qty = 1.0
        else:
            qty = float(qty)
        if not qty:
            return

        price_unit = float(prepared_values.get('price_unit') or 0.0)
        current_subtotal = qty * price_unit
        if current_subtotal >= 0:
            new_subtotal = current_subtotal - share
        else:
            new_subtotal = current_subtotal + share

        prepared_values['price_unit'] = new_subtotal / qty
