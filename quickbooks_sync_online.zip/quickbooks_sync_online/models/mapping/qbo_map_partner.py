# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import logging

import pycountry

from odoo import api, fields, models, tools

from ...tools import parse_routes


_logger = logging.getLogger(__name__)


class QboMapPartner(models.Model):
    _name = 'qbo.map.partner'
    _inherit = [
        'qbo.map.abstract',
        'qbo.map.update.mixin',
    ]
    _description = 'QuickBooks mapping: Customer, Vendor'

    _related_odoo_field = 'partner_id'
    _qbo_class_names = ('Customer', 'Vendor')

    _odoo_routes = {
        'active': ('Active', True),
        'name': ('DisplayName', False),
        'company_name': ('CompanyName', False),
        'email': ('PrimaryEmailAddr.Address', False),
        'phone': ('PrimaryPhone.FreeFormNumber', False),
        'website': ('WebAddr.URI', False),
        'currency_name': ('CurrencyRef.value', False),
        'comment': ('Notes', False),
    }
    _map_routes = {
        'qbo_name': ('DisplayName', False),
    }

    qbo_company_name = fields.Char(
        string='QuickBooks Company Name',
        compute='_compute_qbo_company_name',
        store=True,
        readonly=True,
        help="The card's CompanyName as QuickBooks holds it. Odoo 19 kept this on "
             'the contact as res.partner.company_name; Odoo 20 removed that field, '
             'so a company that is not a partner of its own has nowhere else to live.',
    )

    is_qbo_company = fields.Boolean(
        string='QuickBooks Company Card',
        compute='_compute_qbo_company_name',
        store=True,
        readonly=True,
        help='Whether this QuickBooks card names a company rather than a person at '
             'a company. Kept here because Odoo 20 computes res.partner.is_company '
             'from the Tax ID and no longer lets the import set it.',
    )

    @api.depends('qbo_object')
    def _compute_qbo_company_name(self):
        """Keep what the QuickBooks card says about the company it names.

        Odoo 19 kept both of these on the contact -- `company_name` held a company
        that was not a partner of its own, and `is_company` was a plain boolean the
        import wrote. Odoo 20 removed the first and computes the second from the
        Tax ID, which a QuickBooks customer generally does not carry: passing
        `is_company` to `create()` is discarded in silence, and there is no field
        left for the company of a person at one.

        Both answers are QuickBooks' own, so the card is where they now live.
        `_find_odoo_partner` reads the flag, and `res.partner._qbo_company_name`
        reads the name back on the way out, which is what closes the round trip.
        """
        for mapping in self:
            # The same name `_adjust_odoo_values` compares: DisplayName carries the
            # type and currency suffixes this connection adds, and CompanyName
            # never does, so the raw value would tell every card apart from itself.
            name = mapping._parse_qbo_name(
                mapping.extract_node('DisplayName', str) or '',
                mapping._extract_currency_name(),
            )
            company_name = mapping.extract_node('CompanyName', str) or ''

            mapping.qbo_company_name = company_name
            mapping.is_qbo_company = mapping._is_qbo_company(name, company_name)

    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Odoo Partner',
    )

    @property
    def is_customer(self):
        return self.qbo_lib_type == 'customer'

    @property
    def parent_str_id(self):
        return self.extract_node('ParentRef.value', '')  # Only for customers

    @property
    def bill_with_parent(self):
        # BillWithParent is a boolean flag that determines
        # whether a sub-customer inherits billing from its parent customer.
        return bool(self.parent_str_id and self.extract_node('BillWithParent', False))

    def fetch_resource_data_from_qbo(self, qi_id: int, *args, **kw):
        """Redefined method to fetch all map-types."""
        for map_type in self.map_types:
            super().fetch_resource_data_from_qbo(qi_id, map_type=map_type)

    def action_create_in_odoo(self):
        for record in self:
            record = record.with_context(company_id=record.company_id.id)

            odoo_record = record.partner_id
            if odoo_record:
                record.refresh_qbo_mapping_body()  # Refresh the mapping body to get the latest data before update
                odoo_record._update_addresses_from_mapping(record.id)
            else:
                record.create_instance_in_odoo()

    def create_instance_in_odoo(self):
        self.ensure_one()

        # 1. Find parent partner
        parent_id = self.parent_str_id
        if parent_id:
            odoo_parent = self.browse() \
                .search_and_create_instance_in_odoo(self.quickbooks_integration_id.id, parent_id, self.map_type)
        else:
            odoo_parent = self.env['res.partner']

        # 2. Find or create partner
        odoo_record = self._find_odoo_partner()
        if not odoo_record:
            odoo_record = self._create_odoo_partner(parent_id=odoo_parent.id)

        # 3. Bind partner to mapping
        self.bind_odoo(odoo_record.id)

        # 4. Update Odoo partner addresses
        odoo_record._update_addresses_from_mapping(self.id)

        return odoo_record

    def search_and_create_instance_in_odoo(self, qi_id: int, qbo_id: str, map_type: str):
        record = self._get_mapping_from_external(qi_id, qbo_id, map_type)

        if not record:
            qbo_lib_class = self.fetch_qbo_one_by_pk(qi_id, qbo_id, map_type)
            record = self.get_or_create_qbo_mapping_from_response(qbo_lib_class, qi_id)

        odoo_record = record.partner_id
        if not odoo_record:
            return record.create_instance_in_odoo()

        return odoo_record

    def is_intuit_taxable_customer(self):
        self.refresh_qbo_mapping_body()

        return self.qbo_dict_body.get('Taxable', False)

    def _qbo_update_context(self):
        """The currency that names this card.

        A contact holds one card per currency in QuickBooks, told apart by the
        `[EUR]` suffix `_prepare_qbo_name` adds. Rebuilding that name from the
        partner alone would use the company currency and drop the suffix, which
        either renames a foreign-currency card onto the name of the base-currency
        one -- QuickBooks answers 6240 -- or, when it is the only card, quietly
        strips the suffix that told them apart in the first place.
        """
        self.ensure_one()

        return {'with_currency_name': self._extract_currency_name()}

    def _format_to_odoo_address(self, raw_values: dict) -> dict:
        if not raw_values:
            return {}

        _routes = {
            'city': ('City', False),
            'street': ('Line1', False),
            'street2': ('Line2', False),
            'zip': ('PostalCode', False),
            'country_id.country_code': ('Country', ''),
            'country_id.state_name': ('CountrySubDivisionCode', ''),
        }

        values = parse_routes(raw_values, _routes)

        kwargs = {}
        country_id = state_id = False

        country_code = values['country_id']['country_code']
        state_name = values['country_id']['state_name']

        if country_code:
            if len(country_code) == 3:
                kwargs['alpha_3'] = country_code
            elif len(country_code) == 2:
                kwargs['alpha_2'] = country_code
            elif country_code:
                kwargs['name'] = country_code

            py_country = pycountry.countries.get(**kwargs) if kwargs else None

            if py_country:
                country_id = self.env['res.country'].search([
                    ('code', '=', py_country.alpha_2),
                ], limit=1).id

                if country_id:
                    state_id = self._find_odoo_state(country_id, py_country.alpha_2, state_name)

        values = {
            'zip': values['zip'],
            'city': values['city'],
            'street': values['street'],
            'street2': values['street2'],
            'state_id': state_id,
            'country_id': country_id,
        }

        if all(not x for x in values.values()):
            return {}

        return values

    def _find_odoo_state(self, country_id: int, alpha_2: str, value: str):
        """The Odoo state a QuickBooks CountrySubDivisionCode means.

        QuickBooks stores that field verbatim -- it neither normalises nor checks
        it -- so it comes back as whatever was typed or exported: "TX", "Texas",
        "texas", "NSW". Odoo's own state code is the ISO subdivision for most
        countries (56 of 62 US states, all of Canada and Australia), which is why
        it is tried first; the United Kingdom is the exception, where Odoo numbers
        its counties "A1" and only the name can match.

        Matching used to go by name alone, and only exactly: a three-letter code
        such as "NSW" reached the name search and found nothing, and a difference
        in case was enough to drop the state without a word.
        """
        State = self.env['res.country.state']
        domain = [('country_id', '=', country_id)]

        if not value:
            return False

        state = State.search(domain + [('code', '=ilike', value)], limit=1) \
            or State.search(domain + [('name', '=ilike', value)], limit=1)

        if not state:
            # A code QuickBooks holds and Odoo does not: read the name off the ISO
            # subdivision and try that.
            subdivision = pycountry.subdivisions.get(code=f'{alpha_2}-{value}')

            if subdivision:
                state = State.search(domain + [('name', '=ilike', subdivision.name)], limit=1)

        return state.id

    def _extract_currency_name(self, lower=False):
        value = self.extract_node('CurrencyRef.value', '')
        return value.lower() if lower else value

    def _adjust_odoo_values(self, values: dict) -> dict:
        result = super(QboMapPartner, self)._adjust_odoo_values(values)

        # 1. Parse name. Remove suffix and currency name.
        name = self._parse_qbo_name(result['name'], result['currency_name'])

        # 2. Parse addreses
        billing = self._format_to_odoo_address(self.extract_node('BillAddr', dict))
        shipping = self._format_to_odoo_address(self.extract_node('ShipAddr', dict))

        # 3. The card's currency is read for the name above and then dropped.
        #
        # It is not carried onto the contact: Odoo has no field for a contact's
        # currency -- `res.partner.currency_id` is computed from the company, is
        # not stored and has no inverse, so writing it does nothing at all. This
        # used to look up a `res.currency` and hand it to `create()`, which the ORM
        # discarded in silence, and half the time the lookup found nothing anyway,
        # since Odoo ships most currencies inactive and the search honoured that.
        #
        # Nothing is lost by leaving it out. The currency belongs to the QuickBooks
        # card rather than to the contact -- a contact holds one card per currency
        # -- and it is kept on the mapping, where `_extract_currency_name` reads it
        # for the name suffix, the currency filter in `_get_qbo_mapping` and the
        # context an update runs under.
        result.pop('currency_name')

        # 4. The company/person distinction is dropped here, along with the
        # `company_name` it was read from.
        #
        # Odoo 20 removed `res.partner.company_name` -- a contact no longer carries
        # a free-text company of its own -- and turned `is_company` into a field
        # computed from the Tax ID, which `create()` discards when it is passed in
        # values. Neither can be written, so neither is offered. What the card says
        # is kept on the mapping instead, as `is_qbo_company`.
        result.pop('company_name')

        values_upd = {
            'name': name,
            'billing': billing,
            'shipping': shipping,
            'email': tools.email_normalize(result['email']),
        }

        # 5. Format phone numbers
        country_id = billing.get('country_id')
        if country_id:
            values_upd['phone'] = self._proxy_phone_format(result['phone'], country_id)

        # 6. Set customer/supplier rank
        if self.is_customer:
            values_upd['customer_rank'] = 1
        else:
            values_upd['supplier_rank'] = 1

        result.update(values_upd)

        return result

    def _is_qbo_company(self, name: str, company_name: str) -> bool:
        """Whether this QuickBooks card is a company rather than a person.

        A card is a company when the company is the thing it names -- QuickBooks
        copies the same string into DisplayName and CompanyName for those, as its
        own "Cool Cars" and "Dukes Basketball Camp" show. When the two differ the
        card is somebody at a company: "John Smith" of "Acme Inc", or the job
        "55 Twin Lane" of "Freeman Sporting Goods".

        Reading `bool(CompanyName)` alone called all of them companies, and that
        cost the company on the way back: a partner that is its own commercial
        partner answers `commercial_company_name` -- what the export sends as
        CompanyName -- with its own name, and "Acme Inc" is lost. Telling the two
        apart is what `is_qbo_company` records, and what the contact matching in
        `_find_odoo_partner` reads.
        """
        return bool(company_name) and company_name.strip() == (name or '').strip()

    def _find_odoo_partner(self):
        """The Odoo contact this card already stands for, if there is one.

        Matched without regard to case. QuickBooks keeps what was typed, and both
        sides of this comparison have been through hands: an exact match dropped
        "acme llc" against "ACME LLC" and made a second contact for it. The email
        is worse than merely case-sensitive -- the import normalises the address it
        reads while Odoo keeps whatever was entered, so the same address failed to
        match itself whenever Odoo's copy was not already lowercase.

        The company condition follows the card's own `is_qbo_company` rather than
        the presence of a CompanyName. They used to mean the same thing; they no
        longer do, since a card naming a person at a company is read as a person
        (see `_is_qbo_company`), and asking for a company here would never match
        one. It cannot follow `res.partner.is_company` either: Odoo 20 computes
        that from the Tax ID, which QuickBooks customers generally do not carry,
        so every company card would miss its contact and import a duplicate.
        """
        values = self._prepare_odoo_values()

        # Contacts of another company are not candidates. Most contacts belong to
        # no company in particular and are shared, and those still match; one tied
        # to a different company does not, and used to -- the document import then
        # failed on Odoo's own company check, reporting an inconsistency between
        # the invoice and the contact without a word about QuickBooks.
        domain = [
            ('name', '=ilike', values['name']),
            ('company_id', 'in', [False, self.company_id.id]),
        ]

        if values['email']:
            domain.append(('email', '=ilike', values['email']))

        if self.is_qbo_company:
            # A contact of some other company is not this company card. Odoo 19
            # asked for `company_name`, the free text an imported contact carried;
            # Odoo 20 has only `commercial_company_name`, the name of the partner
            # the contact belongs to, and a partner that belongs to nobody is its
            # own -- so the card's own name is what answers here either way.
            domain.append(('commercial_company_name', '=ilike', values['name']))

        return self.env['res.partner'].search(domain, limit=1)

    def _create_odoo_partner(self, **kwargs) -> models.Model:
        values = self._prepare_odoo_values()

        values.pop('billing', None)
        values.pop('shipping', None)

        values.update(kwargs)

        partner = self.env['res.partner'] \
            .with_context(no_mark_quickbooks_update=True) \
            .create(values)

        _logger.info(
            'Partner "%s" created from QuickBooks object [qbo_id=%s, type=%s]',
            partner.display_name, self.qbo_id, self.qbo_lib_type,
        )
        return partner

    def _proxy_phone_format(self, phone_number: str, country_id: int) -> str:
        """Format phone number using Odoo's built-in formatter."""
        if not phone_number or not country_id:
            return phone_number

        country = self.env['res.country'].browse(country_id)

        # Use Odoo's phone formatting utility - E.164 format. ThePYPI package "phonenumbers" required.
        formatted = self._phone_format(
            number=phone_number,
            country=country,
        )

        return formatted or phone_number

    def _parse_qbo_name(self, name: str, currency_name: str):
        self.ensure_one()

        name_ = name.replace(f'({self.qbo_lib_type})', '').strip()

        if currency_name:
            name_ = name_.replace(f'[{currency_name}]', '').strip()

        return name_
