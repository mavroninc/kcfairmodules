# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import json

from odoo import fields, models


class QboTaxLineAbstract(models.AbstractModel):
    _name = 'qbo.tax.line.abstract'
    _description = 'Qbo Tax Line Abstract'

    line_num = fields.Integer(
        string='Line Number',
    )

    parent_line_num = fields.Integer(
        string='Parent Line Number',
    )

    item_map_id = fields.Many2one(
        comodel_name='qbo.map.product',
        string='Map Product',
    )

    tax_map_ids = fields.Many2many(
        comodel_name='qbo.map.tax',
        string='Map Taxes',
    )

    body = fields.Char(
        string='Body',
    )

    @property
    def body_dict(self):
        return json.loads(self.body or '{}')
