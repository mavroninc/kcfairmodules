# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import json
import logging

from odoo import models, _
from odoo.exceptions import ValidationError

from ....tools import TaxSuiter, ExtractNode


GROUP_LINE_DETAIL = 'GroupLineDetail'
SALES_ITEM_LINE_DETAIL = 'SalesItemLineDetail'

SHIPPING_ITEM_ID = 'SHIPPING_ITEM_ID'
DISCOUNT_LINE_DETAIL = 'DiscountLineDetail'

_logger = logging.getLogger(__name__)


class QboMapTaxMixin(models.AbstractModel):
    _name = 'qbo.map.tax.mixin'
    _description = 'QuickBooks Map Tax Mixin'

    def apply_taxes_from_intuit(self):
        raise NotImplementedError

    def parse_mapping_taxes(self, qbo_lib_model):
        self.ensure_one()

        if qbo_lib_model.TxnTaxDetail:
            return self._parse_mapping_taxes([l.to_dict() for l in qbo_lib_model.TxnTaxDetail.TaxLine])

        return self.env['qbo.map.tax']

    def _parse_mapping_taxes(self, tax_lines: list):
        """Parse QuickBooks taxes from `qbo_lib_model`. Mainly for `sale.order` and `account.move`.'"""
        self.ensure_one()

        tax_qbo_ids = []
        for data in tax_lines:
            rate = TaxSuiter.tax_rate_from_tax_line(data)
            if rate:
                tax_qbo_ids.append(rate)

        MapTax = self.env['qbo.map.tax']
        mappings = MapTax.browse()

        qi_id = self.quickbooks_integration_id.id
        for tax_qbo_id in tax_qbo_ids:
            mapping = MapTax._get_mapping_from_external(qi_id, tax_qbo_id, 'taxrate')

            if not mapping:
                MapTax.get_taxes_from_qbo(qi_id)
                mapping = MapTax._get_mapping_from_external(qi_id, tax_qbo_id, 'taxrate', raise_if_not_found=True)

            mappings |= mapping

        return mappings

    def prepare_mapping_lines(self, qbo_lib_model) -> list:
        raise ValidationError(
            _('QuickBooks "%s" has no tax details. No way to create Odoo record') % qbo_lib_model.qbo_object_name
        )

    def _qbo_taxcode_rate_field(self):
        """Side of the tax code the document takes its rates from."""
        return 'sales_tax_rate_ids'

    def _qbo_taxcode_rates(self) -> dict:
        """``{tax code id: [tax rate id, ...]}`` of the current connection.

        Outside the US the tax code of a line is what defines its rates, so this
        answers the whole question directly instead of guessing it from amounts.
        """
        self.ensure_one()
        field = self._qbo_taxcode_rate_field()

        taxcodes = self.env['qbo.map.taxcode'].search([
            ('quickbooks_integration_id', '=', self.quickbooks_integration_id.id),
        ])

        return {x.qbo_id: x[field].mapped('qbo_id') for x in taxcodes}

    def _prepare_mapping_lines(self, product_lines: list, tax_lines: list, apply_taxes_after_discount: bool) -> list:
        qi = self.quickbooks_integration_id
        tax_suiter = TaxSuiter(
            product_lines,
            tax_lines,
            qi.qb_is_us_company,
            apply_taxes_after_discount,
            taxcode_rates=self._qbo_taxcode_rates(),
        )

        result = []
        for data in product_lines:
            adds = {
                'parent_line_num': data.pop('_parent_line_num', False),
            }

            # 1. Find product
            product_mapping = self.env['qbo.map.product']

            detail_type = data['DetailType']

            if detail_type == DISCOUNT_LINE_DETAIL:
                adds['is_discount_line'] = True
            else:
                external_product_id = ExtractNode.extract_raw(data, f'{detail_type}.ItemRef.value', False)

                if external_product_id == SHIPPING_ITEM_ID:
                    adds['is_delivery_line'] = True
                elif external_product_id:
                    product_mapping = self.env['qbo.map.product'] \
                        .ensure_mapping_from_intuit(qi.id, external_product_id)

            # 2. Find taxes
            MapTax = self.env['qbo.map.tax']
            tax_mappings = MapTax.browse()

            qbo_tax_ids = tax_suiter.taxes_for_line(data['LineNum'])

            for qbo_tax_id in qbo_tax_ids:
                mapping = MapTax._get_mapping_from_external(qi.id, qbo_tax_id, 'taxrate')

                if not mapping:
                    MapTax.get_taxes_from_qbo(qi.id)
                    mapping = MapTax._get_mapping_from_external(qi.id, qbo_tax_id, 'taxrate', raise_if_not_found=True)

                tax_mappings |= mapping

            result.append({
                'line_num': data['LineNum'],
                'item_map_id': product_mapping.id,
                'tax_map_ids': [(6, 0, tax_mappings.ids)],
                'body': json.dumps(data),
                **adds,
            })

        return result

    def _prepare_mapping_grouped_line(self, data: dict, **adds):
        qi = self.quickbooks_integration_id

        external_product_id = ExtractNode.extract_raw(data, f'GroupLineDetail.GroupItemRef.value', False)
        if external_product_id:
            map_product = self.env['qbo.map.product'] \
                .ensure_mapping_from_intuit(qi.id, external_product_id)
        else:
            map_product = self.env['qbo.map.product']

        return {
            'line_num': data['LineNum'],
            'item_map_id': map_product.id,
            'body': json.dumps(data),
            **adds,
        }
