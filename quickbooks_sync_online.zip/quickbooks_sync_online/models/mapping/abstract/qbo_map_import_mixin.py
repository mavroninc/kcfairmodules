# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo import models, fields


class QboMapImportMixin(models.AbstractModel):
    _name = 'qbo.map.import.mixin'
    _description = 'Abstract mixin for importing QuickBooks records'

    is_imported = fields.Boolean(
        string='Is Imported',
    )

    is_exported = fields.Boolean(
        string='Is Exported',
    )

    def mark_as_imported(self):
        self.write({'is_imported': True})

    def mark_as_exported(self):
        self.write({'is_exported': True})
