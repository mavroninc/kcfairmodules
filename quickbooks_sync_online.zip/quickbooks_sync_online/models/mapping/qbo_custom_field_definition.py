# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo import _, api, fields, models
from odoo.exceptions import UserError


class QboCustomFieldDefinition(models.Model):
    _name = 'qbo.custom.field.definition'
    _description = 'QuickBooks custom field definition'
    _order = 'qbo_field_name, qbo_field_definition_id, id'
    _rec_names_search = ['qbo_field_name']

    _qbo_field_definition_id_uniq = models.Constraint(
        'unique(quickbooks_integration_id, qbo_field_definition_id)',
        'Each QuickBooks custom field definition can only exist once per connection.',
    )

    quickbooks_integration_id = fields.Many2one(
        comodel_name='quickbooks.integration',
        string='QuickBooks Connection',
        ondelete='cascade',
        required=True,
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        related='quickbooks_integration_id.company_id',
        store=True,
        readonly=True,
    )
    qbo_field_definition_id = fields.Char(
        string='QuickBooks Definition ID',
        required=True,
        help=(
            'QuickBooks custom field DefinitionId (e.g. "540344"). '
            'It is never shown in the QuickBooks Online UI — copy it from a '
            'transaction or customer API response that includes '
            'include=enhancedAllCustomFields (CustomField[].DefinitionId). '
            'If no record has the field filled yet: create a throwaway invoice '
            'in QBO, fill the custom field, fetch that invoice once via the API, '
            'copy the DefinitionId, then delete the throwaway invoice. '
            'DefinitionId belongs to the field definition and does not change.'
        ),
    )
    qbo_field_name = fields.Char(
        string='QuickBooks Custom Field',
        help='Display label from QuickBooks (e.g. "Salesman"). Not used for matching.',
    )
    line_ids = fields.One2many(
        comodel_name='qbo.custom.field.definition.line',
        inverse_name='definition_id',
        string='Mapping Lines',
    )
    mapping_count = fields.Integer(
        string='Mappings',
        compute='_compute_mapping_count',
    )

    @api.depends('line_ids')
    def _compute_mapping_count(self):
        for rec in self:
            rec.mapping_count = len(rec.line_ids)

    @api.depends('qbo_field_name', 'qbo_field_definition_id')
    def _compute_display_name(self):
        for rec in self:
            rec.display_name = '%s [%s]' % (
                rec.qbo_field_name or '',
                rec.qbo_field_definition_id or '',
            )

    @api.model
    def name_create(self, name):
        raise UserError(_(
            'Custom field definitions can only be imported from QuickBooks.'
        ))
