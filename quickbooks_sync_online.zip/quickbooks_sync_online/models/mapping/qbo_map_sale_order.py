# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo import fields, models

from .abstract.qbo_map_tax_mixin import SALES_ITEM_LINE_DETAIL
from ...quickbooks_api import ObjectNotFoundException


class QboMapSaleOrder(models.Model):
    _name = 'qbo.map.sale.order'
    _inherit = [
        'qbo.map.abstract',
        'qbo.map.tax.mixin',
    ]
    _description = 'QuickBooks mapping: SalesReceipt'

    _related_odoo_field = 'order_id'
    _qbo_class_names = ('SalesReceipt',)

    _map_routes = {
        'qbo_name': ('DocNumber', ''),
        'total_tax': ('TxnTaxDetail.TotalTax', ''),
    }

    order_id = fields.Many2one(
        comodel_name='sale.order',
        string='Odoo Sale Order',
        domain='[("company_id", "=", company_id)]',
    )
    partner_id = fields.Many2one(
        related='order_id.partner_id',
    )
    qbo_tax_ids = fields.Many2many(
        comodel_name='qbo.map.tax',
        string='QuickBooks Taxes',
    )
    total_tax = fields.Char(
        string='Total Tax',
    )
    order_map_line_ids = fields.One2many(
        comodel_name='qbo.map.sale.order.line',
        inverse_name='order_map_id',
        string='Map Order Lines',
    )

    def action_delete_in_qbo(self):
        for record in self:
            record.delete_qbo_one_with_delay()

    def delete_qbo_one_with_delay(self):
        self.ensure_one()

        job_kwargs = {
            'identity_key': f'delete_qbo_salesreceipt-{self}',
            'description': '[Technical] %s: Delete QuickBooks SalesReceipt (id=%s)' % (self.qbo_name, self.qbo_id),
            'channel': self.job_channel,
        }

        self \
            .with_context(company_id=self.company_id.id) \
            .with_delay(**job_kwargs).delete_qbo_one()

    def delete_qbo_one(self):
        self.ensure_one()

        try:
            value = super().delete_qbo_one()
        except ObjectNotFoundException:
            value = True

        return value

    def get_or_create_qbo_mapping_from_response(self, qbo_lib_model, qi_id: int, odoo_id: int = None):
        mapping = super().get_or_create_qbo_mapping_from_response(qbo_lib_model, qi_id, odoo_id=odoo_id)

        if qbo_lib_model.TxnTaxDetail:
            map_tax = mapping._parse_mapping_taxes([l.to_dict() for l in qbo_lib_model.TxnTaxDetail.TaxLine])
            mapping.qbo_tax_ids = [(6, 0, map_tax.ids)]

            vals_list = mapping.prepare_mapping_lines(qbo_lib_model)
            mapping.env['qbo.map.sale.order.line'].create(vals_list)

        return mapping

    def apply_taxes_from_intuit(self):
        self.ensure_one()

        for tax in self.qbo_tax_ids.filtered(lambda r: not r.tax_id):
            tax.sudo().try_to_map(summary=False)

        zipper = zip(
            self.order_id.order_line.filtered('product_id'),
            self.order_map_line_ids,
        )

        lines = []
        for so_line, map_line in zipper:
            taxes = map_line.tax_map_ids.mapped('tax_id')

            lines.append(
                (1, so_line.id, {'tax_ids': [(6, 0, taxes.ids)]}),
            )

        return self.order_id \
            .write({'order_line': lines})

    def prepare_mapping_lines(self, qbo_lib_model) -> list:
        self.ensure_one()

        if not qbo_lib_model.TxnTaxDetail:
            return super().prepare_mapping_lines(qbo_lib_model)

        product_lines = []
        for line in qbo_lib_model.Line:
            if line.DetailType == SALES_ITEM_LINE_DETAIL:
                product_lines.append(line.to_dict())

        values = self._prepare_mapping_lines(
            product_lines,
            [l.to_dict() for l in qbo_lib_model.TxnTaxDetail.TaxLine],
            qbo_lib_model.ApplyTaxAfterDiscount,
        )

        for data in values:
            data['order_map_id'] = self.id

        return values
