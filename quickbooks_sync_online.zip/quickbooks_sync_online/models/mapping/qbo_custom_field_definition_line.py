# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

from ...tools import CUSTOM_FIELD_IMPORT_MAP_TYPES


class QboCustomFieldDefinitionLine(models.Model):
    _name = 'qbo.custom.field.definition.line'
    _description = 'QuickBooks custom field mapping line'
    _order = 'map_type, id'

    _definition_map_type_uniq = models.Constraint(
        'unique(definition_id, map_type)',
        'This QuickBooks custom field is already mapped for this transaction type.',
    )
    _odoo_field_name_uniq = models.Constraint(
        'unique(quickbooks_integration_id, map_type, odoo_field_name)',
        'Each Odoo field can only be mapped once per transaction type.',
    )

    definition_id = fields.Many2one(
        comodel_name='qbo.custom.field.definition',
        string='QuickBooks Custom Field',
        required=True,
        ondelete='cascade',
    )
    quickbooks_integration_id = fields.Many2one(
        comodel_name='quickbooks.integration',
        related='definition_id.quickbooks_integration_id',
        store=True,
        readonly=True,
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        related='definition_id.company_id',
        store=True,
        readonly=True,
    )
    map_type = fields.Selection(
        selection=[
            ('invoice', 'Customer Invoice'),
            ('creditmemo', 'Customer Credit Note'),
            ('bill', 'Vendor Bill'),
            ('vendorcredit', 'Vendor Refund'),
        ],
        string='Transaction Type',
        required=True,
        default='invoice',
    )
    odoo_field_name = fields.Selection(
        selection='_selection_odoo_field_name',
        string='Odoo Field',
        help=(
            'Only plain-text Odoo fields can be selected — QuickBooks custom '
            'fields are always plain-text values.'
        ),
    )
    apply_on_import = fields.Boolean(
        string='Apply on Import',
        default=True,
        help=(
            'Customer Invoices and Customer Credit Notes only — the connector '
            'does not import Vendor Bills or Vendor Refunds from QuickBooks, '
            'so this option is disabled on those lines.'
        ),
    )
    apply_on_export = fields.Boolean(
        string='Apply on Export',
        default=True,
    )
    qbo_field_definition_id = fields.Char(
        related='definition_id.qbo_field_definition_id',
        readonly=True,
    )
    qbo_field_name = fields.Char(
        related='definition_id.qbo_field_name',
        string='QuickBooks Field Name',
        readonly=True,
    )

    @property
    def is_bill_line(self):
        return self.map_type == 'bill'

    @property
    def is_invoice_line(self):
        return self.map_type == 'invoice'

    @property
    def is_import_supported_line(self):
        return self.map_type in CUSTOM_FIELD_IMPORT_MAP_TYPES

    @api.constrains('odoo_field_name')
    def _check_odoo_field_name(self):
        """A dynamic Selection is not validated on write.

        Odoo only renders ``_selection_odoo_field_name`` for the UI; a value
        outside that list is accepted by ``create``/``write`` (data import, XML
        data, direct ORM calls). Without this check an Html field such as
        ``narration`` can be mapped and its markup shipped to QuickBooks, which
        only ever accepts plain-text custom field values.
        """
        allowed = dict(self._selection_odoo_field_name())

        for line in self:
            if line.odoo_field_name and line.odoo_field_name not in allowed:
                raise ValidationError(_(
                    '"%(field)s" cannot be used as a custom field mapping target. '
                    'QuickBooks custom fields hold plain-text values, so only '
                    'stored text fields of the invoice/bill can be selected.'
                ) % {'field': line.odoo_field_name})

    @api.onchange('map_type')
    def _onchange_map_type(self):
        """Bill/VendorCredit import is not supported — do not leave the flag set."""
        for line in self:
            if not line.is_import_supported_line:
                line.apply_on_import = False

    @api.model
    def _selection_odoo_field_name(self):
        """Stored char/text fields on account.move — enforces plain-text-only targets."""
        Move, selection = self.env['account.move'], []

        for name, field in Move._fields.items():
            if field.type not in ('char', 'text') or not field.store:
                continue
            label = field.string or name
            selection.append((name, '%s (%s)' % (label, name)))

        return sorted(selection, key=lambda item: item[1].lower())
