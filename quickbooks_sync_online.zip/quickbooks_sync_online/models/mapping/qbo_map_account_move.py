# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from typing import List, Dict
from collections import defaultdict

from odoo import _, fields, models
from odoo.exceptions import ValidationError

from .abstract.qbo_map_tax_mixin import (
    GROUP_LINE_DETAIL,
    DISCOUNT_LINE_DETAIL,
    SALES_ITEM_LINE_DETAIL,
)
from ...tools import (
    parse_datetime_from_str,
    qbo_query_id_list,
    CUSTOM_FIELD_MAP_TYPES,
    CUSTOM_FIELD_QBO_OBJECTS,
)
from ...quickbooks_api import (
    ObjectNotFoundException,
    QuickBooksClient,
    QboClassManager,
    catch_exception,
)


DEFAULT_LINE_DETAIL_TYPES = (SALES_ITEM_LINE_DETAIL, DISCOUNT_LINE_DETAIL)


class QboMapAccountMove(models.Model):
    _name = 'qbo.map.account.move'
    _inherit = [
        'qbo.map.abstract',
        'qbo.map.import.mixin',
        'qbo.map.tax.mixin',
    ]
    _description = 'QuickBooks mapping: Invoice, Credit Memo, Bill, Vendor Credit'

    _related_odoo_field = 'invoice_id'
    _qbo_class_names = ('Invoice', 'CreditMemo', 'Bill', 'VendorCredit')

    _odoo_routes = {
        'name': ('DocNumber', False),
        'ref': ('PrivateNote', False),
        'currency_name_str': ('CurrencyRef.value', ''),
        'invoice_date_str': ('TxnDate', ''),
        'invoice_date_due_str': ('DueDate'  , ''),
    }

    _map_routes = {
        'qbo_name': ('DocNumber', ''),
        'total_amt': ('TotalAmt', 0),
        'invoice_link': ('InvoiceLink', ''),
        'total_tax': ('TxnTaxDetail.TotalTax', 0),
        'create_time_str': ('MetaData.CreateTime', None),
    }

    total_amt = fields.Float(
        string='Amount Total',
    )

    total_tax = fields.Float(
        string='Tax Total',
    )

    create_time = fields.Datetime(
        string='Create Time',
        help='Time the entity was created in the source domain.',
    )

    qbo_tax_ids = fields.Many2many(
        comodel_name='qbo.map.tax',
        string='QuickBooks Taxes',
    )

    invoice_link = fields.Char(
        string='Invoice Link',
    )

    invoice_id = fields.Many2one(
        comodel_name='account.move',
        string='Odoo Invoice',
        domain='[("company_id", "=", company_id)]',
    )

    partner_id = fields.Many2one(
        related='invoice_id.partner_id',
    )

    payment_state = fields.Selection(
        related='invoice_id.payment_state',
    )

    payment_ids = fields.One2many(
        comodel_name='qbo.map.payment',
        inverse_name='txn_id',
        string='Map Payments',
    )

    invoice_map_line_ids = fields.One2many(
        comodel_name='qbo.map.invoice.line',
        inverse_name='invoice_map_id',
        string='Map Invoice Lines',
    )

    is_imported = fields.Boolean(
        string='Is Imported',
    )

    is_exported = fields.Boolean(
        string='Is Exported',
    )

    @property
    def is_invoice(self):
        return self.map_type == 'invoice'

    @property
    def is_creditmemo(self):
        return self.map_type == 'creditmemo'

    @property
    def is_bill(self):
        return self.map_type == 'bill'

    @property
    def is_vendorcredit(self):
        return self.map_type == 'vendorcredit'

    @property
    def is_journal_entry(self):
        return self.map_type == 'journalentry'

    @property
    def is_customer_type(self):
        return self.is_invoice or self.is_creditmemo

    @property
    def is_vendor_type(self):
        return self.is_bill or self.is_vendorcredit

    @property
    def odoo_invoice_type(self):
        if self.is_invoice:
            return 'out_invoice'
        elif self.is_creditmemo:
            return 'out_refund'
        elif self.is_bill:
            return 'in_invoice'
        elif self.is_vendorcredit:
            return 'in_refund'
        elif self.is_journal_entry:
            return 'entry'
        else:
            raise ValidationError(_('Unsupported QuickBooks transaction type: %s') % self.qbo_lib_type)

    def mark_as_imported(self):
        self.write({'is_imported': True})

    def mark_as_exported(self):
        self.write({'is_exported': True})

    @catch_exception
    def _fetch_qbo_by_query(self, map_type: str, condition: str, client: QuickBooksClient):
        """Invoice and Bill queries always include ``enhancedAllCustomFields``."""
        if (map_type or '').lower() not in CUSTOM_FIELD_MAP_TYPES:
            return super()._fetch_qbo_by_query(map_type, condition, client)

        cls = QboClassManager.get_class(map_type)
        query_string = "SELECT * FROM %s WHERE %s" % (cls.qbo_object_name, condition)
        json_data = client.query(
            query_string,
            params={'include': 'enhancedAllCustomFields'},
        )

        obj_list = []
        object_name = cls.qbo_json_object_name or cls.qbo_object_name
        if object_name in json_data.get('QueryResponse', {}):
            for item_json in json_data['QueryResponse'][object_name]:
                obj_list.append(cls.from_json(item_json))

        return obj_list

    @catch_exception
    def _fetch_qbo_one_by_id(self, qbo_id: str, map_type: str, client: QuickBooksClient):
        """Invoice and Bill GET always include ``enhancedAllCustomFields``."""
        if (map_type or '').lower() not in CUSTOM_FIELD_MAP_TYPES:
            return super()._fetch_qbo_one_by_id(qbo_id, map_type, client)

        cls = QboClassManager.get_class(map_type)
        return cls.get(
            qbo_id,
            qb=client,
            params={'include': 'enhancedAllCustomFields'},
        )

    @catch_exception
    def _save_qbo_one(self, qbo_lib_model, client: QuickBooksClient):
        """Invoice and Bill save always include ``enhancedAllCustomFields``."""
        if getattr(qbo_lib_model, 'qbo_object_name', None) not in CUSTOM_FIELD_QBO_OBJECTS:
            return super()._save_qbo_one(qbo_lib_model, client)

        return qbo_lib_model.save(
            qb=client,
            params={'include': 'enhancedAllCustomFields'},
        )

    def fetch_resource_data_from_qbo(self, *args, **kw):
        raise NotImplementedError(_('This method is not implemented for this model.'))

    def process_in_odoo_with_delay(self):
        self.ensure_one()

        kwargs = self._job_kwargs_process_invoice_in_odoo()
        self.env['queue.job'].cancel_failed_jobs_by_identity_key(kwargs['identity_key'])

        job = self \
            .with_context(company_id=self.company_id.id) \
            .with_delay(**kwargs) \
            .create_instance_in_odoo()

        return job

    def process_in_odoo_and_open_wizard(self):
        self.ensure_one()

        self.process_in_odoo_with_delay()

        wizard_id = self.env.context.get('quickbooks_invoice_import_wizard_id')
        wizard = self.env['quickbooks.invoice.import'].browse(wizard_id)

        return wizard.action_display_notification_and_open_form_view(self.qbo_name)

    def create_instance_in_odoo(self):

        if self.invoice_id:
            return self.invoice_id

        partner, *__ = self.create_partner_in_odoo()

        ctx = {
            'default_partner_id': partner.id,
        }

        invoice = super(QboMapAccountMove, self.with_context(**ctx)) \
            .create_instance_in_odoo()

        # Create Odoo invoice lines
        self._create_lines_from_intuit()

        return invoice

    def create_partner_in_odoo(self):
        self.ensure_one()

        if self.partner_id:
            return self.partner_id

        if self.is_customer_type:
            partner_type = 'customer'
            partner_qbo_id = self.extract_node('CustomerRef.value', '')
        else:
            partner_type = 'vendor'
            partner_qbo_id = self.extract_node('VendorRef.value', '')

        if not partner_qbo_id:
            raise ValidationError(_('QuickBooks document has no partner reference.'))

        MapPartner = self.env['qbo.map.partner']
        qi_id = self.quickbooks_integration_id.id

        mapping = MapPartner._get_mapping_from_external(qi_id, partner_qbo_id, partner_type)
        if not mapping:
            qbo_lib_class = MapPartner.fetch_qbo_one_by_pk(qi_id, partner_qbo_id, partner_type)
            mapping = MapPartner.get_or_create_qbo_mapping_from_response(qbo_lib_class, qi_id)

        if mapping.partner_id:
            return mapping.partner_id

        # `create_instance_in_odoo` is what the "Create in Odoo" button runs: it
        # finds the partner or creates one, binds the mapping to it and writes the
        # addresses. Asking `_find_odoo_partner` here instead used the partner it
        # found and left the mapping unbound, because the binding lives inside the
        # branch that creates one.
        #
        # An unbound mapping is not merely untidy. The export then finds nothing to
        # update and pushes the partner as a new card, and the duplicate-name
        # recovery does not catch it either: a card a person made in QuickBooks has
        # no type suffix, the export adds one, so the names differ and QuickBooks
        # answers with a second contact rather than 6240.
        return mapping.create_instance_in_odoo()

    def _update_addresses_from_data(self, partner_id: int, first_time_import: bool):
        """
        This method currently not used due to no way parse correctly billing
        and shipping addresses from `free format strings` (Line<number>).

           "BillAddr": {
                "City": "",
                "Country": "",
                "CountrySubDivisionCode": "",
                "Id": "1737",
                "Lat": "",
                "Line1": "2017130 Sticks & Stones Replacement Parts",
                "Line2": "Sticks & Stones, LLC 102, 23422",
                "Line3": "Johna 123, 12343, Alabama, USA",
                "Line4": "",
                "Line5": "",
                "Long": "",
                "Note": "",
                "PostalCode": ""
            }
        """
        partner = self.env['res.partner'].browse(partner_id)
        MapPartner = self.env['qbo.map.partner']

        if self.is_customer_type:
            billing_ = MapPartner._format_to_odoo_address(
                self.extract_node('BillAddr', dict)
            )
            shipping_ = MapPartner._format_to_odoo_address(
                self.extract_node('ShipAddr', dict)
            )
        else:
            billing_ = MapPartner._format_to_odoo_address(
                self.extract_node('VendorAddr', dict)
            )
            shipping_ = {}

        billing, shipping = partner._update_addresses_from_data(
            billing_,
            shipping_,
            no_other_type_create=first_time_import,
        )

        return partner, billing, shipping

    def action_import_invoice_payments_button(self):
        self.ensure_one()

        self.with_context(
            qbo_skip_payment_registration=False,
        ).action_import_invoice_payments()

        return self.invoice_id._raise_jobs_notification(len(self))

    def action_import_invoice_payments(self):
        for mapping in self:
            if mapping.is_vendorcredit or mapping.is_creditmemo:
                continue

            qi = mapping.quickbooks_integration_id
            job_kwargs = mapping._job_kwargs_import_payments()
            self.env['queue.job'].cancel_failed_jobs_by_identity_key(job_kwargs['identity_key'])

            company = qi.company_id
            mapping_ = mapping.with_company(company).with_context(company_id=company.id)
            skip_registration_ = bool(mapping.env.context.get('qbo_skip_payment_registration'))

            mapping_.with_delay(**job_kwargs) \
                .import_payments(skip_registration=skip_registration_)

    def import_payments(self, pay_ids: list = None, skip_registration: bool = False):
        """
        Sync external payments from QuickBooks to Odoo.

        This method is used to sync and register external payments from QuickBooks to Odoo.
        It will actualize the external payment mappings and then register the payments.

        :return: None
        """
        self.actualize_payment_mappings(pay_ids)

        payments = self.payment_ids.filtered(lambda x: not x.payment_id)

        if not skip_registration:
            zero_balance = (self.extract_node('Balance', 0) == 0)

            # A payment that could be matched to an existing one in Odoo needs no
            # job, so the reconciliation has to be asked of the last payment that
            # actually gets one. Asking it of the last of `payments` would lose it
            # whenever that one turns out to be matched.
            to_register = payments.filtered(lambda x: not x._try_to_map_payment())

            for idx, payment in enumerate(to_register, start=1):
                job_kwargs = payment._job_kwargs_register_payment()
                self.env['queue.job'].cancel_failed_jobs_by_identity_key(job_kwargs['identity_key'])

                payment \
                    .with_context(company_id=payment.company_id.id) \
                    .with_delay(**job_kwargs) \
                    .register_payment_in_odoo(
                        reconcile=(idx == len(to_register) and zero_balance),
                    )

        return payments

    def actualize_payment_mappings(self, pay_ids: list = None):
        """
        Actualize the external payment mappings.

        This method is used to actualize the external payment mappings.
        It will fetch the external payments from QuickBooks and then create the payment mappings.

        :return: None
        """
        payments = self.get_payments_from_qbo(pay_ids)

        for payment in payments:
            mapping = self.payment_ids.filtered(lambda x: x.qbo_id == payment.Id)

            if mapping:
                mapping.update_qbo_mapping_from_response(payment)
            else:
                amount = self._parse_transaction_amount([l.to_dict() for l in payment.Line])

                mapping = self.env['qbo.map.payment'] \
                    .with_context(
                        default_txn_id=self.id,
                        default_txn_amount=amount,
                        default_is_imported=True,
                    ) \
                    .get_or_create_qbo_mapping_from_response(payment, self.quickbooks_integration_id.id, odoo_id=None)

        return self.payment_ids

    def get_payments_from_qbo(self, pay_ids: list = None):
        self.ensure_one()

        if not pay_ids:
            qbo_lib_object = self.fetch_qbo_one()
            self.update_qbo_mapping_from_response(qbo_lib_object)

            txn_type = 'Payment' if self.is_customer_type else 'BillPaymentCheck'
            pay_ids = [x.TxnId for x in qbo_lib_object.LinkedTxn if x.TxnType == txn_type]

        if not pay_ids:
            return []

        ids = list(set(pay_ids))
        ids.sort(key=int)

        condition = 'Id IN (%s)' % qbo_query_id_list(ids)
        payment_type = 'Payment' if self.is_customer_type else 'BillPayment'

        qb = self.quickbooks_integration_id.get_quickbooks_api_client()
        payments = self._fetch_qbo_by_query(payment_type, condition, client=qb)

        return payments

    def _create_lines_from_intuit(self):
        self._recompute_map_lines()
        self._auto_map_taxes()

        map_lines = self.invoice_map_line_ids

        if self.extract_node('ApplyTaxAfterDiscount', False):
            total_discount = sum(l._get_amount() for l in map_lines.filtered('is_discount_line'))

            if total_discount:
                candidate_lines = map_lines.filtered(lambda x: not x.is_discount_line)
                values_list = candidate_lines._apply_post_discount_to_prepared_line_dicts(total_discount)

                lines = [(0, 0, vals) for vals in values_list]
            else:
                lines = [(0, 0, line._prepare_odoo_values()) for line in map_lines]
        else:
            lines = [(0, 0, line._prepare_odoo_values()) for line in map_lines]

        self.invoice_id.write({'invoice_line_ids': lines})

    def apply_taxes_from_intuit(self):
        self._recompute_map_lines()
        self._auto_map_taxes()

        zipper = zip(
            self.invoice_id.invoice_line_ids.filtered(lambda x: x.display_type_product),
            self.invoice_map_line_ids,
        )

        lines = []
        for invoice_line, map_line in zipper:
            taxes = map_line.tax_map_ids.mapped('tax_id')

            lines.append(
                (1, invoice_line.id, {'tax_ids': [(6, 0, taxes.ids)]}),
            )

        return self.invoice_id \
            .write({'invoice_line_ids': lines})

    def _prepare_odoo_values(self) -> dict:
        values = super(QboMapAccountMove, self)._prepare_odoo_values()

        values.update(
            move_type=self.odoo_invoice_type,
            company_id=self.company_id.id,
            is_excluded_from_qbo_sync=True,
        )

        return values

    def _adjust_odoo_values(self, values: dict) -> dict:
        result = super(QboMapAccountMove, self)._adjust_odoo_values(values)

        invoice_date = parse_datetime_from_str(result.pop('invoice_date_str'))
        invoice_date_due = parse_datetime_from_str(result.pop('invoice_date_due_str'))
        currency_name = result.pop('currency_name_str')

        currency = self.env['res.currency'].search([
            ('name', '=ilike', currency_name),
        ], limit=1)

        result.update(
            currency_id=currency.id,
            invoice_date=invoice_date,
            invoice_date_due=invoice_date_due,
        )

        # Per-type lines: a DefinitionId can appear on several QBO transaction
        # types; only mapping lines of this record's map_type are applied.
        if self.map_type in CUSTOM_FIELD_MAP_TYPES:
            lines = self.quickbooks_integration_id.qbo_custom_field_mapping_line_ids.filtered(
                lambda r: r.odoo_field_name and r.apply_on_import and r.map_type == self.map_type
            )
            if lines:
                raw_custom_fields = self.extract_node('CustomField', list)
                by_definition_id = {
                    str(x.get('DefinitionId')): x.get('StringValue')
                    for x in raw_custom_fields
                    if x.get('DefinitionId') is not None
                }
                for line in lines:
                    value = by_definition_id.get(line.qbo_field_definition_id)
                    if value:
                        result[line.odoo_field_name] = value

        return result

    def _extract_custom_field_definitions(self):
        """Return ordered unique (DefinitionId, Name) pairs from invoice CustomField.

        StringType only: the connector's mapping lines only ever read or write
        StringValue, and only plain-text Odoo fields can be selected as a target,
        so a NumberType/DateType/List definition would be a mapping with no
        value it could ever actually carry.
        """
        self.ensure_one()
        result = []
        seen = set()
        for entry in self.extract_node('CustomField', list):
            if (entry.get('Type') or 'StringType') != 'StringType':
                continue
            definition_id = str(entry.get('DefinitionId') or '').strip()
            if not definition_id or definition_id in seen:
                continue
            seen.add(definition_id)
            result.append((definition_id, entry.get('Name') or ''))
        return result

    def _adjust_mapping_values(self, qi_id: int, values: dict, qbo_lib_model) -> dict:
        res = super(QboMapAccountMove, self)._adjust_mapping_values(qi_id, values, qbo_lib_model)

        create_time = parse_datetime_from_str(res.pop('create_time_str'))
        res['create_time'] = create_time

        return res

    def _parse_transaction_amount(self, lines: List[Dict]):
        txn_id = self.qbo_id
        txn_type = self.qbo_entity_name

        for line in lines:
            if any(x['TxnId'] == txn_id and x['TxnType'] == txn_type for x in line['LinkedTxn']):
                return line['Amount']

        return 0

    def _qbo_taxcode_rate_field(self):
        return 'purchase_tax_rate_ids' if self.is_vendor_type else 'sales_tax_rate_ids'

    def prepare_mapping_lines(self, qbo_lib_model) -> list:
        self.ensure_one()
        tax_detail = getattr(qbo_lib_model, 'TxnTaxDetail', None)
        if not tax_detail:
            return super().prepare_mapping_lines(qbo_lib_model)

        values, handle_bundle_lines_ = [], False
        product_lines = []
        for line in qbo_lib_model.Line:
            if line.DetailType in DEFAULT_LINE_DETAIL_TYPES:
                product_lines.append(line.to_dict())
            elif line.DetailType == GROUP_LINE_DETAIL:
                handle_bundle_lines_ = True
                line_dict = line.to_dict()
                detail_type = line_dict['DetailType']

                for sub_line in line_dict[detail_type]['Line']:
                    if sub_line['DetailType'] in DEFAULT_LINE_DETAIL_TYPES:
                        sub_line['_parent_line_num'] = line_dict['LineNum']
                        product_lines.append(sub_line)

        tax_lines = getattr(tax_detail, 'TaxLine', None) or []
        values = self._prepare_mapping_lines(
            product_lines,
            [l.to_dict() for l in tax_lines],
            getattr(qbo_lib_model, 'ApplyTaxAfterDiscount', False),
        )

        if handle_bundle_lines_ and self.is_mrp_module_installed:
            grouped_values = defaultdict(list)
            for value in values:
                grouped_values[value['parent_line_num']].append(value)

            values_ = []
            for parent_line_num, child_list in grouped_values.items():
                parent_line = next(filter(lambda x: x['LineNum'] == parent_line_num, qbo_lib_model.Line), None)

                # If parent line is not found or child values have different tax maps, skip preparing bundle line
                lists = [x['tax_map_ids'][0][2] for x in child_list]
                standard = sorted(lists[0])
                if not parent_line or not all(sorted(x) == standard for x in lists):
                    values_.extend(child_list)
                    continue

                # Prepare bundle line (instead of childs) and assign child taxes to it
                parent_line_dict = parent_line.to_dict()

                parent_values = self._prepare_mapping_grouped_line(
                    parent_line_dict,
                    tax_map_ids=child_list[0]['tax_map_ids'][0][2],
                )
                values_.append(parent_values)

            values = values_

        for data in values:
            data['invoice_map_id'] = self.id

        return values

    def _recompute_map_lines(self):
        # 0. Unlink old values for recomputing
        self.qbo_tax_ids = [(6, 0, [])]
        self.invoice_map_line_ids.unlink()

        qbo_lib_model = self.init_from_stored_json()

        # 1. Parse taxes
        map_tax = self.parse_mapping_taxes(qbo_lib_model)
        self.qbo_tax_ids = [(6, 0, map_tax.ids)]

        # 2. Create mapping-product-lines
        vals_list = self.prepare_mapping_lines(qbo_lib_model)

        self.env['qbo.map.invoice.line'].create(vals_list)

    def _auto_map_taxes(self):
        for tax in self.qbo_tax_ids.filtered(lambda r: not r.tax_id):
            tax.sudo().try_to_map(summary=False)

    def _format_raw_billing_address(self):
        dict_ = self.extract_node('BillAddr', dict)
        return self._format_raw_address_lines(dict_)

    def _format_raw_shipping_address(self):
        dict_ = self.extract_node('ShipAddr', dict)
        return self._format_raw_address_lines(dict_)

    @staticmethod
    def _format_raw_address_lines(dict_: dict) -> str:
        return '\n'.join(v for k, v in dict_.items() if k.startswith('Line'))

    def _job_kwargs_import_payments(self):
        return {
            'identity_key': f'qbo-import-invoice-payments-{self.quickbooks_integration_id.id}-{self.qbo_id}',
            'description': f'Import payments for Invoice "{self.qbo_name}" [qbo_id={self.qbo_id}]',
            'channel': self.job_channel,
        }

    def _job_kwargs_process_invoice_in_odoo(self):
        return {
            'identity_key': f'qbo-create-invoice-in-odoo-{self.quickbooks_integration_id.id}-{self.qbo_id}',
            'description': f'Create in Odoo Invoice "{self.qbo_name}" [qbo_id={self.qbo_id}]',
            'channel': self.job_channel,
        }

    def mapping_prune(self):
        self.ensure_one()

        invoice = self.invoice_id

        try:
            self.delete_qbo_one()
        except ObjectNotFoundException:
            pass

        self.payment_ids.unlink()
        self.unlink()

        invoice.unmark_excluded_from_qbo_sync()
