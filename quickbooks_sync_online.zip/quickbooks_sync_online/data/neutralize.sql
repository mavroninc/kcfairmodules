-- deactivating important settings on the integration
UPDATE  quickbooks_integration
SET     enable_invoices_auto_export = FALSE,
        enable_payments_sync_in = FALSE,
        enable_payments_sync_out = FALSE,
        enable_updates_auto_export = FALSE;

-- deactivating integrations
UPDATE  quickbooks_integration
SET     state = 'draft';
