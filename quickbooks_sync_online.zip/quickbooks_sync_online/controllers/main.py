# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import re
import logging

from werkzeug.exceptions import BadRequest, Forbidden

from odoo import http
from odoo.exceptions import AccessError, ValidationError


_logger = logging.getLogger(__name__)


def get_number_after_dot(s):
    match = re.search(r'\.(\d+)$', s or '')
    if match:
        return int(match.group(1))
    return None


class QboCallbackController(http.Controller):

    @http.route('/qbo/callback', type='http', auth='user')
    def qbo_callback(self, state=None, code=None, realmId=None, error=None, **kw):
        """QuickBooks callback response handler."""
        wizard = self._wizard_from_state(state)
        qi = self._connection_from_wizard(wizard)

        if error or not code or not realmId:
            # Intuit answers a refused or an abandoned grant with an error and no
            # code at all. Say so: returning to the form would reopen the wizard
            # as if nothing had happened, and the reason would be lost.
            reason = ', '.join(filter(None, [error, kw.get('error_description')])) \
                or 'QuickBooks returned no authorization code'

            _logger.info('QuickBooks authorization was not granted for "%s": %s', qi.name, reason)

            raise BadRequest('QuickBooks authorization was not granted: %s' % reason)

        # The access_tocken here is not defined yet, so we need to exclude it from the auth-client creation
        client = qi._get_qbo_auth_client(exclude_access_token=True)
        client.get_bearer_token(code, realm_id=realmId)

        qi._update_from_quth_client(client, qb_company_id=realmId)

        try:
            qbo_company = qi._validate_intuit_company_info()
        except ValidationError as e:
            qi._update_from_quth_client(client, qb_company_id=False)
            raise BadRequest(str(e)) from e

        qi._update_from_qbo_company_info(qbo_company)
        qi.action_active()

        # Redirect back to authentication form (for both success and error cases)
        return http.request.redirect(f'/odoo/qi-connection/{qi.id}')

    def _wizard_from_state(self, state):
        """Resolve the wizard the state token was issued for.

        The token is random and is compared in full: it is what tells an answer
        from Intuit apart from a forged call to this endpoint.
        """
        wizard_id = get_number_after_dot(state)

        if not wizard_id:
            raise BadRequest('Bad csrf! Rejected!')

        wizard = http.request.env['quickbooks.auth.wizard'].sudo().browse(wizard_id).exists()

        if not wizard:
            raise BadRequest(f'Quickbooks Auth Wizard (id={wizard_id}) not found! Rejected!')

        if state != wizard.state_token:
            raise BadRequest('Quickbooks Auth Wizard invalid csrf! Rejected!')

        return wizard

    def _connection_from_wizard(self, wizard):
        """The connection to store the granted tokens on.

        The wizard is read with elevated rights, so the rights of the user
        calling back have to be checked against the connection itself: granting
        access rewrites the credentials of a company.
        """
        qi = http.request.env['quickbooks.integration'].browse(wizard.qi_id.id).exists()

        if not qi:
            raise BadRequest('Quickbooks Connection not found! Rejected!')

        try:
            qi.check_access('write')
        except AccessError as e:
            _logger.warning(
                'User %s is not allowed to authorize the QuickBooks connection %s',
                http.request.env.user.login, qi.id,
            )
            raise Forbidden('You are not allowed to authorize this QuickBooks connection.') from e

        return qi
