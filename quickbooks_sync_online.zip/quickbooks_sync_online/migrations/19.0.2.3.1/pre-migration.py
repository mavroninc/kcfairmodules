# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import logging


_logger = logging.getLogger(__name__)

# Mapping tables that gain a uniqueness constraint, with the column pointing at
# the Odoo record and the columns the QuickBooks object is identified by.
MAPPING_TABLES = [
    ('qbo_map_account', 'account_id', ()),
    ('qbo_map_account_move', 'invoice_id', ()),
    ('qbo_map_department', 'warehouse_id', ()),
    ('qbo_map_inventory_adjustment', None, ()),
    ('qbo_map_partner', 'partner_id', ()),
    ('qbo_map_payment', 'payment_id', ('txn_id',)),
    ('qbo_map_payment_method', None, ()),
    ('qbo_map_product', 'product_id', ()),
    ('qbo_map_sale_order', 'order_id', ()),
    ('qbo_map_tax', 'tax_id', ()),
    ('qbo_map_taxcode', None, ()),
    ('qbo_map_term', None, ()),
]


def _drop_unbound_duplicates(cr):
    """Clear the way for the uniqueness constraint on the mapping tables.

    A QuickBooks object is one mapping per connection, but nothing enforced it,
    so a re-import could leave a second row behind. Where the duplicates
    disagree, the one pointing at an Odoo record is the one worth keeping;
    where none of them does, any one will do.

    Duplicates that all point at an Odoo record are left alone and reported:
    picking between them is a decision about someone's accounting data, not a
    migration step. The constraint then fails to install, which Odoo logs, and
    the connector goes on working exactly as it did before.
    """
    for table, odoo_column, extra_columns in MAPPING_TABLES:
        cr.execute("SELECT to_regclass(%s)", (table,))
        if not cr.fetchone()[0]:
            continue

        key = ', '.join(('quickbooks_integration_id', 'qbo_lib_type', 'qbo_id') + extra_columns)
        # Keep the bound rows first, then the oldest, and drop the rest of the group.
        ranking = ('%s DESC NULLS LAST, id' % odoo_column) if odoo_column else 'id'

        cr.execute(
            """
            DELETE FROM {table}
            WHERE id IN (
                SELECT id FROM (
                    SELECT id,
                           row_number() OVER (PARTITION BY {key} ORDER BY {ranking}) AS position,
                           count(*) FILTER (WHERE {bound}) OVER (PARTITION BY {key}) AS bound_rows
                    FROM {table}
                ) ranked
                WHERE position > 1 AND bound_rows < 2
            )
            """.format(
                table=table,
                key=key,
                ranking=ranking,
                bound=('%s IS NOT NULL' % odoo_column) if odoo_column else 'FALSE',
            )
        )

        if cr.rowcount:
            _logger.info('QuickBooks: removed %s duplicate mappings from %s.', cr.rowcount, table)

        cr.execute(
            """
            SELECT count(*) FROM (
                SELECT 1 FROM {table} GROUP BY {key} HAVING count(*) > 1
            ) still_duplicated
            """.format(table=table, key=key)
        )
        remaining = cr.fetchone()[0]

        if remaining:
            _logger.warning(
                'QuickBooks: %s groups of duplicate mappings in %s point at different Odoo '
                'records and were left as they are. The uniqueness constraint cannot be '
                'installed until they are resolved by hand.',
                remaining, table,
            )


def migrate(cr, version):
    """Make room for the uniqueness constraint on the mapping tables."""
    if not version:
        return

    _drop_unbound_duplicates(cr)
