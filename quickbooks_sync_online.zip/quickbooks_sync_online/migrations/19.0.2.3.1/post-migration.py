# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).


def migrate(cr, version):
    # qbo.custom.field.mapping only ever existed in 2.3.x. Upgrading from an
    # earlier version (migrations exist for 1.3.0 and 2.0.0) reaches this script
    # with no such table, and an unguarded SELECT would abort the upgrade.
    cr.execute("SELECT to_regclass('qbo_custom_field_mapping')")
    if not cr.fetchone()[0]:
        return

    cr.execute("""
        INSERT INTO qbo_custom_field_definition (
            quickbooks_integration_id, company_id,
            qbo_field_definition_id, qbo_field_name,
            create_uid, create_date, write_uid, write_date
        )
        SELECT m.quickbooks_integration_id, m.company_id,
               m.qbo_field_definition_id, m.qbo_field_name,
               m.create_uid, m.create_date, m.write_uid, m.write_date
        FROM qbo_custom_field_mapping m
        ON CONFLICT DO NOTHING
    """)

    cr.execute("""
        INSERT INTO qbo_custom_field_definition_line (
            definition_id, quickbooks_integration_id, company_id, map_type,
            odoo_field_name, apply_on_import, apply_on_export,
            create_uid, create_date, write_uid, write_date
        )
        SELECT d.id, m.quickbooks_integration_id, m.company_id, 'invoice',
               m.odoo_field_name, m.apply_on_import, m.apply_on_export,
               m.create_uid, m.create_date, m.write_uid, m.write_date
        FROM qbo_custom_field_mapping m
        JOIN qbo_custom_field_definition d
          ON d.quickbooks_integration_id = m.quickbooks_integration_id
         AND d.qbo_field_definition_id   = m.qbo_field_definition_id
        WHERE m.odoo_field_name IS NOT NULL
        ON CONFLICT DO NOTHING
    """)
