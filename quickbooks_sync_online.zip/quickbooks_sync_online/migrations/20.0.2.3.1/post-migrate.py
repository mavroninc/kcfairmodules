# Copyright 2026 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import logging

from odoo import SUPERUSER_ID, api

_logger = logging.getLogger(__name__)


def migrate(cr, version):
    env = api.Environment(cr, SUPERUSER_ID, {})
    if 'ir.model.access' not in env:
        return

    metadata = env['ir.model.data'].search([
        ('module', '=', 'quickbooks_sync_online'),
        ('model', '=', 'ir.model.access'),
    ])
    for row in metadata:
        record = env['ir.model.access'].browse(row.res_id).exists()
        if record:
            _logger.info('Removing obsolete ir.model.access %s', row.name)
            record.unlink()
