# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).


def _remove_obsolete_model_selection_metadata(cr, obsolete_models):
    """Remove stale selection metadata for models retired in 19.0.1.3.0.

    Odoo resolves the owning model through the new registry while deleting
    obsolete ``ir.model.fields.selection`` records. Without a migration
    cleanup, stale metadata may survive module upgrade or, on older Odoo
    versions without the Oct 2024 ORM patch, raise ``KeyError`` during
    ``_process_end``.

    ``qbo.map.mixin`` and ``qbo.transaction.mixin`` had Selection fields and
    were removed in 1.3.0. ``qbo.help.wizard`` kept its name but lost
    ``qbo_partner_type``. Only framework metadata is removed.
    """
    cr.execute(
        """
        DELETE FROM ir_model_data
        WHERE model = 'ir.model.fields.selection'
          AND res_id IN (
              SELECT selection.id
              FROM ir_model_fields_selection AS selection
              JOIN ir_model_fields AS field
                ON field.id = selection.field_id
              WHERE field.model IN %s
          )
        """,
        (obsolete_models,),
    )
    cr.execute(
        """
        DELETE FROM ir_model_fields_selection AS selection
        USING ir_model_fields AS field
        WHERE selection.field_id = field.id
          AND field.model IN %s
        """,
        (obsolete_models,),
    )


def migrate(cr, version):
    _remove_obsolete_model_selection_metadata(cr, (
        'job.transaction.mixin',
        'qbo.help.wizard',
        'qbo.map.mixin',
        'qbo.transaction.mixin',
    ))

    # Drop all the views from the quickbooks_sync_online module

    cr.execute("""
        SELECT id FROM ir_ui_view
            WHERE inherit_id IN (
                SELECT res_id
                FROM ir_model_data
                WHERE module = 'quickbooks_sync_online'
                AND model = 'ir.ui.view'
            )
    """)

    inherit_ids = cr.fetchall()

    if inherit_ids:
        inherit_ids_ = [x[0] for x in inherit_ids]
        cr.execute(
            'DELETE FROM ir_ui_view WHERE id IN %(inherit_ids)s',
            {'inherit_ids': tuple(inherit_ids_)},
        )
        cr.execute(
            "DELETE FROM ir_model_data WHERE model = 'ir.ui.view' AND res_id IN %(inherit_ids)s",
            {'inherit_ids': tuple(inherit_ids_)},
        )

    cr.execute("""
        DELETE FROM ir_ui_view
        WHERE id IN (
            SELECT res_id
            FROM ir_model_data
            WHERE module = 'quickbooks_sync_online'
            AND model = 'ir.ui.view'
        )

    """)

    # Drop all the xml-ids from the quickbooks_sync_online module
    cr.execute("""
        DELETE FROM ir_model_data
            WHERE module = 'quickbooks_sync_online'
            AND model = 'ir.ui.view'
    """)
