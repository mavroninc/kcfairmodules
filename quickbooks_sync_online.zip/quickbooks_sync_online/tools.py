# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import json
import logging
import secrets
import string

from datetime import timezone

from dateutil import parser
from copy import deepcopy
from typing import Union, Dict, List, Type

from odoo import _
from odoo.exceptions import ValidationError

from .quickbooks_api import qb_datetime_format


_logger = logging.getLogger(__name__)


TAXABLE, NON_TAXABLE = 'TAX', 'NON'

# The two kinds of line a QuickBooks bill is made of: one against an item, one
# against an account. A bill entered by hand in QuickBooks is ordinarily the
# second kind, and its detail takes no Qty or UnitPrice.
ITEM_BASED_EXPENSE_LINE_DETAIL = 'ItemBasedExpenseLineDetail'
ACCOUNT_BASED_EXPENSE_LINE_DETAIL = 'AccountBasedExpenseLineDetail'

CUSTOM_FIELD_MAP_TYPES = ('invoice', 'bill', 'creditmemo', 'vendorcredit')
CUSTOM_FIELD_QBO_OBJECTS = ('Invoice', 'Bill', 'CreditMemo', 'VendorCredit')

# Of the four supported types, only these two are ever pulled from QuickBooks
# into Odoo (see quickbooks.invoice.import) -- a mapping line for a Vendor
# Bill or Vendor Refund can only ever apply on export.
CUSTOM_FIELD_IMPORT_MAP_TYPES = ('invoice', 'creditmemo')

MAPPING_MENUS = {
    'account.tax': '[QuickBooks Online --> Mapping --> Taxes]',
    'account.account': '[QuickBooks Online --> Mapping --> Accounts]',
    'account.journal': '[QuickBooks Online --> Mapping --> Payment Methods / Journals]',
    'account.payment.term': '[QuickBooks Online --> Mapping --> Payment Terms]',
}


def generate_token(length=30, allowed_chars=''.join([string.ascii_letters, string.digits])):
    """Generates random CSRF token. Based on `intuitlib.tools.generate_token`."""
    return ''.join(secrets.choice(allowed_chars) for i in range(length))


def quote_qbo_query_value(value) -> str:
    """Quote a value for the QuickBooks query language.

    QuickBooks escapes with a backslash, not by doubling the quote: a name as
    ordinary as "O'Brien Ltd" is answered with "Error parsing query" when it is
    dropped into a condition as is.
    """
    escaped = str(value).replace('\\', '\\\\').replace("'", "\\'")
    return f"'{escaped}'"


def qbo_query_id_list(ids) -> str:
    """Quote QuickBooks ids for an ``IN`` condition, rejecting anything else.

    Ids are numeric in QuickBooks. Refusing the rest keeps a value that came
    from a form out of the query.
    """
    values = [str(x).strip() for x in ids]

    invalid = [x for x in values if not x.isdigit()]
    if invalid:
        raise ValidationError(
            _('QuickBooks ids must be numeric, got: %s') % ', '.join(invalid)
        )

    return ', '.join(f"'{x}'" for x in values)


def expected_one(method):
    def wrapper(self, *args, **kwargs):
        self.ensure_one()

        result, error = method(self, *args, **kwargs), False

        if not result:
            error = _(
                'Mappings: match %s "%s" before export please' % (self._description.lower(), self.name)
            )
        elif len(result) > 1:
            error = _(
                'Mappings: there are several map-objects %s for %s "%s". Define the only one please'
                % (result.mapped('qbo_name'), self._description.lower(), self.name)
            )

        if error:
            menu_path = MAPPING_MENUS.get(self._name, '')
            raise ValidationError('%s: %s.' % (error, menu_path))

        return result
    return wrapper


class QboCompanyInfo:

    def __init__(self, preference, company_info, currency_list):
        self._preference = preference
        self._company_info = company_info
        self._currencies = currency_list

    @property
    def name(self):
        return self._company_info.CompanyName

    @property
    def address(self):
        return self._company_info.CompanyAddr

    @property
    def country_iso(self):
        return self._company_info.Country

    @property
    def home_currency(self):
        return self._preference.CurrencyPrefs.HomeCurrency.value

    @property
    def is_us_company(self):
        return self.country_iso == 'US'

    @property
    def multi_currency_enabled(self):
        return self._preference.CurrencyPrefs.MultiCurrencyEnabled

    def get_qbo_preference(self):
        return self._preference.to_dict()

    def get_qbo_company_info(self):
        return self._company_info.to_dict()

    def get_qbo_external_currencies(self):
        return [x.to_dict() for x in self._currencies]

    def currency_codes(self):
        return [self.home_currency] + [x.Code for x in self._currencies]

    def currency_codes_str(self):
        return ', '.join(self.currency_codes())

    def address_format(self):
        return (
            f'{self.name}, {self.address}, {self.country_iso} [{self.currency_codes_str()}]'
        )

    def validate_country(self, country_code: str) -> bool:
        country_iso = self.country_iso

        if country_iso and len(country_iso) == 2 and country_code != country_iso:
            # TODO: `country_iso` is optional field. We really don't know exact 'len'
            return False

        return True

    def validate_home_currency(self, currency_name: str) -> bool:
        return currency_name.lower() == self.home_currency.lower()

    def validate_foreign_currency(self, foreign_currency: str) -> bool:
        codes_list_lower = [x.lower() for x in self.currency_codes()]
        return (foreign_currency or '').lower() in codes_list_lower


class ExtractNode:

    class MissedValue:
        pass

    def __init__(self, key_string: str, return_type):
        self.keys = key_string.split('.')
        self._type = return_type

    def __call__(self, func):
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)

            if isinstance(result, str):
                result = json.loads(result)

            data = self._extract(result, self.keys)

            if isinstance(data, ExtractNode.MissedValue):
                return self.get_default()

            return data

        return wrapper

    def _extract(self, data, key_list):
        """
        Recursively extract the value based on the provided key list
        """
        if not key_list:
            # No more keys to process, return the current data
            return data

        key, *remaining_keys = deepcopy(key_list)

        if isinstance(data, list):
            if key.isdigit():
                if int(key) < len(data):
                    # If the key is an integer and within the list bounds, continue extraction
                    return self._extract(data[int(key)], remaining_keys)

                # _logger.warning('GraphQL parse error: Index "%s" out of range', key)
                return ExtractNode.MissedValue()

            # Handle the all lists elements
            return list(filter(
                lambda x: not isinstance(x, ExtractNode.MissedValue),
                [self._extract(x, key_list) for x in data],
            ))

        if isinstance(data, dict):
            if key in data:
                return self._extract(data[key], remaining_keys)

            # _logger.warning('GraphQL parse error: Key "%s" not found', key)
            return ExtractNode.MissedValue()

        # Unknown data type (neither a list nor a dictionary)_extract
        # _logger.warning('GraphQL parse error: Expected list or dict at key "%s", got %s', key, type(data).__name__)
        return ExtractNode.MissedValue()

    def get_default(self):
        return self._type() if callable(self._type) else self._type

    @classmethod
    def extract_raw(cls, json_data : Union[str, Dict, List], key_string: str, return_type: Type):
        # 1. init instance
        # 2. invoke the __call__ method
        # 3. invoke the `wrapper` function returned from the step 2
        return cls(key_string, return_type)(lambda: json_data)()


def _parse_nodes(dict_to_parse: dict, routes: dict = None) -> dict:
    """Extract values from QuickBooks dict-object by routes."""
    data = {}
    if not routes:
        return data

    for key, (route, return_type) in routes.items():
        value = ExtractNode.extract_raw(dict_to_parse, route, return_type)
        data[key] = value

    return data


def _remove_dots(data: dict) -> dict:
    """
    Serializing values after extracting them into the 'temporary ones with the dot'.

    Example:: data` = {'a.b': 1, 'a.c': 2, 'd': 3} --> data` = {'a': {'b': 1, 'c': 2}}, 'd': 3}
    """
    cleaned_vals = {}
    for raw_field, value in data.items():
        if raw_field.count('.'):
            sub_fields = raw_field.split('.')
            current_dict = cleaned_vals
            for field in sub_fields[:-1]:
                current_dict.setdefault(field, {})
                current_dict = current_dict[field]
            current_dict[sub_fields[-1]] = value
        else:
            cleaned_vals[raw_field] = value

    return cleaned_vals


def parse_routes(dict_to_parse: dict, routes: dict = None) -> dict:
    raw_data = _parse_nodes(dict_to_parse, routes)
    return _remove_dots(raw_data)


class TaxSuiter:
    """
    Claude: AI generated.

    Map each QBO product line to the tax rates listed under ``TxnTaxDetail``.

    A QBO document never links its lines to the rates directly, so the link
    has to be reconstructed. Which signal carries it depends on how the
    QuickBooks company calculates tax, and the two flows carry it in
    different fields:

    - **US, Automated Sales Tax (``is_us_company=True``)**: the tax is
      computed by QuickBooks from the ship-to address. ``TaxCodeRef`` is
      reduced to "TAX"/"NON" and carries no rate, while
      ``TaxClassificationRef`` holds the product tax category that AST
      actually used to decide what to tax. Lines are therefore matched by
      the taxable amounts: the whole taxable base first, then a single
      classification group, then a single line.
    - **Non-US (``is_us_company=False``)**: the tax is driven by the tax
      code of the line. ``TaxCodeRef`` holds a real TaxCode id and
      ``TaxClassificationRef`` is empty, so the rates of a line are the
      rates of its tax code. This is exact and needs no matching at all,
      but it requires the tax codes to be imported: pass them in as
      ``taxcode_rates``. A zero rate is kept even though QuickBooks lists no
      ``TaxLine`` for it, so that "No VAT" and "Exempt" reach Odoo as the zero
      taxes they are instead of as no tax at all.

    Args:
        product_lines: Usually ``data["Line"]``. Mixed list of product,
            subtotal and discount rows.
        tax_lines: Usually ``data["TxnTaxDetail"]["TaxLine"]``.
        is_us_company: Selects the strategy described above.
        apply_taxes_after_discount: Usually ``data["ApplyTaxAfterDiscount"]``.
        taxcode_rates: ``{tax code id: [tax rate id, ...]}``, from the
            imported tax codes. Optional: without it the amounts are
            matched instead.

    Public API:
        ``suite()`` returns ``{line_num: [rate_id, ...]}`` for every
        product line; ``taxes_for_line(line_num)`` returns the list
        for one line (running ``suite()`` once and caching the result).

    Caveats:
        - The tax-code route is used only when it reproduces every
          ``NetAmountTaxable`` of the document. Otherwise the amounts are
          matched, and matching can be ambiguous when several subsets add
          up to the same target (the largest one wins) or when lines share
          both classification and ``Amount``. A line with a zero ``Amount``
          is ambiguous by definition: it fits every subset for free.
        - Amount matching falls back to a subset sum, which is bounded by
          ``MAX_SUBSET_SEARCH_LINES``. Above that the lines are left
          without rates rather than searched for.
    """

    EPS = 0.01
    NON_TAXABLE_CODES = {'NON', '', None}

    # Upper bound for the subset search. It runs in 2^(n/2), so 30 lines is
    # about 32k combinations per half, while the plain scan it replaced needed
    # 126 million of them just to reach a subset of 9 lines out of 27.
    MAX_SUBSET_SEARCH_LINES = 30

    def __init__(self, product_lines: list, tax_lines: list, is_us_company: bool,
                 apply_taxes_after_discount: bool, taxcode_rates: dict = None):
        self.result = None

        self._is_us_company = is_us_company
        self._apply_taxes_after_discount = apply_taxes_after_discount
        self._product_lines = product_lines
        self._tax_lines = tax_lines
        self._taxcode_rates = taxcode_rates or {}

        self._taxable_lines = [l for l in self._product_lines if self.is_taxable(l)]
        self._taxable_total = self._compute_taxable_total()

        self._groups = TaxSuiter.group_by_classification(self._taxable_lines)
        self._subset_tables_cache = {}

    def _compute_taxable_total(self):
        total = sum(l.get('Amount', 0) for l in self._taxable_lines)
        if self._apply_taxes_after_discount:
            for line in self._product_lines:
                if line['DetailType'] == 'DiscountLineDetail':
                    total -= line['Amount']
        return total

    @staticmethod
    def tax_code_from_product_line(line: dict):
        detail_type = line['DetailType']
        return ExtractNode.extract_raw(line, f'{detail_type}.TaxCodeRef.value', '')

    @staticmethod
    def tax_rate_from_tax_line(line: dict):
        detail_type = line['DetailType']
        return ExtractNode.extract_raw(line, f'{detail_type}.TaxRateRef.value', '')

    @staticmethod
    def net_amount_taxable(line: dict):
        detail_type = line['DetailType']
        return ExtractNode.extract_raw(line, f'{detail_type}.NetAmountTaxable', 0)

    @staticmethod
    def classification(line: dict):
        detail_type = line['DetailType']
        return ExtractNode.extract_raw(line, f'{detail_type}.TaxClassificationRef.value', '')

    @staticmethod
    def is_taxable(line: dict):
        return TaxSuiter.tax_code_from_product_line(line) not in TaxSuiter.NON_TAXABLE_CODES

    @staticmethod
    def group_by_classification(taxable_lines: list):
        groups = {}
        for line in taxable_lines:
            groups.setdefault(TaxSuiter.classification(line), []).append(line)
        return groups

    @staticmethod
    def _to_cents(amount):
        return int(round((amount or 0) * 100))

    def _enumerate_subsets(self, lines: list):
        """All reachable sums of `lines`, each with the largest subset that reaches it."""
        table = {0: ()}

        for line in lines:
            amount = TaxSuiter._to_cents(line.get('Amount', 0))

            for total, subset in list(table.items()):
                extended = subset + (line,)
                reached = total + amount

                known = table.get(reached)
                if known is None or len(known) < len(extended):
                    table[reached] = extended

        return table

    def _subset_tables(self, lines: list):
        key = tuple(l['LineNum'] for l in lines)

        if key not in self._subset_tables_cache:
            half = len(lines) // 2
            self._subset_tables_cache[key] = (
                self._enumerate_subsets(lines[:half]),
                self._enumerate_subsets(lines[half:]),
            )

        return self._subset_tables_cache[key]

    def _find_subset(self, lines, target):
        """Largest subset of `lines` adding up to `target`, by meet in the middle.

        Both halves are enumerated once per group and reused for every tax line,
        since they do not depend on the target.
        """
        if not lines:
            return []

        if len(lines) > self.MAX_SUBSET_SEARCH_LINES:
            _logger.warning(
                'QuickBooks taxes: %s taxable lines in one group is above the search limit of %s. '
                'The lines are left without tax rates: import the QuickBooks tax codes so that the '
                'rates can be taken from them instead.',
                len(lines), self.MAX_SUBSET_SEARCH_LINES,
            )
            return []

        left, right = self._subset_tables(lines)
        target_cents = TaxSuiter._to_cents(target)

        best = ()
        for total, subset in left.items():
            counterpart = right.get(target_cents - total)

            if counterpart is not None and len(subset) + len(counterpart) > len(best):
                best = subset + counterpart

        return list(best)

    def _matching_group(self, net_taxable):
        for group_lines in self._groups.values():
            total = sum(l.get('Amount', 0) for l in group_lines)

            if abs(total - net_taxable) < self.EPS:
                return group_lines

        return []

    def _matching_line(self, net_taxable):
        for line in self._taxable_lines:
            if abs(line.get('Amount', 0) - net_taxable) < self.EPS:
                return [line]

        return []

    def _lines_for_tax(self, net_taxable):
        """Lines that add up to one ``NetAmountTaxable``, cheapest check first."""
        if abs(net_taxable - self._taxable_total) < self.EPS:
            return self._taxable_lines

        matched = self._matching_group(net_taxable)
        if matched:
            return matched

        if self._is_us_company:
            # Automated Sales Tax applies the same rates to everything it taxes,
            # so a single line is a likelier answer than an arbitrary subset.
            matched = self._matching_line(net_taxable)
            if matched:
                return matched

            return self._find_subset(self._taxable_lines, net_taxable)

        for group_lines in self._groups.values():
            subset = self._find_subset(group_lines, net_taxable)
            if subset:
                return subset

        return self._find_subset(self._taxable_lines, net_taxable)

    def _suite_by_tax_code(self):
        """Rates of a line are the rates of its tax code. Exact, but only for the
        flows that put a real tax code on the line, and only when it adds up."""
        if not self._taxcode_rates:
            return None

        result = {}

        for line in self._product_lines:
            if not line.get('LineNum'):
                continue

            if not self.is_taxable(line):
                result[line['LineNum']] = []
                continue

            rates = self._taxcode_rates.get(TaxSuiter.tax_code_from_product_line(line))

            if rates is None:  # an unknown code makes the whole document unreliable
                return None

            # Every rate of the code, including the ones QuickBooks left out of
            # TxnTaxDetail: it lists nothing for a zero rate, but "No VAT" is a
            # deliberate choice on the line and has to survive the import.
            result[line['LineNum']] = list(rates)

        # The document states the taxed amount per rate. Use it as a checksum:
        # if the rates of the tax codes do not reproduce it, do not trust them.
        for tax_line in self._tax_lines:
            rate = TaxSuiter.tax_rate_from_tax_line(tax_line)
            net = TaxSuiter.net_amount_taxable(tax_line)

            taxed = sum(
                l.get('Amount', 0) for l in self._product_lines
                if l.get('LineNum') and rate in result[l['LineNum']]
            )

            if abs(taxed - net) >= self.EPS:
                _logger.info(
                    'QuickBooks taxes: tax code %s covers %s instead of the stated %s. '
                    'Falling back to matching the amounts.', rate, taxed, net,
                )
                return None

        return result

    def _suite_by_amounts(self):
        result = {x['LineNum']: [] for x in self._product_lines if x['LineNum']}

        for data in self._tax_lines:
            net = TaxSuiter.net_amount_taxable(data)
            rate = TaxSuiter.tax_rate_from_tax_line(data)

            for matched in self._lines_for_tax(net):
                result[matched['LineNum']].append(rate)

        return result

    def suite(self):
        result = self._suite_by_tax_code()

        if result is None:
            result = self._suite_by_amounts()

        self.result = result
        return result

    def taxes_for_line(self, line_num: int):
        if self.result is None:
            self.suite()

        return self.result.get(line_num, [])


def two_dicts_are_equal(dict1: dict, dict2: dict) -> bool:
    return set(tuple(dict1.items())) == set(tuple(dict2.items()))


def parse_datetime_from_str(dtime_str):
    """Read a QuickBooks datetime as the naive UTC value Odoo stores.

    QuickBooks answers with the time zone of the company, so dropping the
    offset rather than converting by it moves the moment by that offset:
    "2026-08-28T09:45:09-07:00" is 16:45 UTC, not 09:45.
    """
    try:
        value = parser.isoparse(dtime_str)
    except Exception:
        return False

    if value.tzinfo is not None:
        value = value.astimezone(timezone.utc)

    return value.replace(tzinfo=None)


def convert_utc_datetime_to_str(dtime_obj):
    """Format a datetime Odoo holds in UTC for a QuickBooks query.

    Without an offset QuickBooks reads the value in the time zone of the
    company, so a range asked for in UTC lands hours away from the one meant
    and quietly answers with the wrong documents.
    """
    try:
        return dtime_obj.strftime('%Y-%m-%dT%H:%M:%S+00:00')
    except Exception:
        return False


def convert_datetime_to_str(dtime_obj):
    try:
        value = qb_datetime_format(dtime_obj)
    except Exception:
        value = False

    return value
