# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo.tests import tagged, TransactionCase


@tagged('-at_install', 'post_install', 'qbo_state_lookup')
class TestStateLookup(TransactionCase):
    """QuickBooks stores CountrySubDivisionCode verbatim, so it comes back as
    whatever was typed or exported: a code, a name, either case."""

    def _state_of(self, country_code, subdivision):
        country = self.env['res.country'].search([('code', '=', country_code)], limit=1)
        values = self.env['qbo.map.partner']._format_to_odoo_address({
            'Line1': '1 Test St',
            'City': 'Town',
            'PostalCode': '00000',
            'Country': country_code,
            'CountrySubDivisionCode': subdivision,
        })

        self.assertEqual(values['country_id'], country.id)

        state = self.env['res.country.state'].browse(values['state_id'])

        return state.name if values['state_id'] else None

    def test_a_two_letter_code_and_its_name_agree(self):
        self.assertEqual(self._state_of('US', 'TX'), 'Texas')
        self.assertEqual(self._state_of('US', 'Texas'), 'Texas')

    def test_case_does_not_decide_it(self):
        """A name typed in QuickBooks in another case used to drop the state."""
        self.assertEqual(self._state_of('US', 'texas'), 'Texas')
        self.assertEqual(self._state_of('US', 'tx'), 'Texas')

    def test_a_three_letter_code_is_read(self):
        """Odoo's own code for New South Wales is NSW, and the branch that
        translated codes only looked at two-letter ones."""
        self.assertEqual(self._state_of('AU', 'NSW'), 'New South Wales')
        self.assertEqual(self._state_of('AU', 'nsw'), 'New South Wales')

    def test_a_code_odoo_does_not_use_goes_through_the_iso_name(self):
        """The United Kingdom is the exception: Odoo numbers its counties A1, A5,
        so ABD matches nothing here and has to be read as an ISO subdivision."""
        self.assertEqual(self._state_of('GB', 'Aberdeenshire'), 'Aberdeenshire')
        self.assertEqual(self._state_of('GB', 'ABD'), 'Aberdeenshire')

    def test_a_code_that_already_carries_its_country_is_read(self):
        self.assertEqual(self._state_of('DE', 'DE-BY'), 'Bayern')

    def test_a_subdivision_of_no_country_is_left_empty(self):
        self.assertIsNone(self._state_of('US', 'Nowhere'))
        self.assertIsNone(self._state_of('US', ''))

    def test_a_country_alone_still_resolves(self):
        values = self.env['qbo.map.partner']._format_to_odoo_address({
            'Line1': '1 Test St',
            'Country': 'USA',
            'CountrySubDivisionCode': '',
        })

        self.assertTrue(values['country_id'])
        self.assertFalse(values['state_id'])
