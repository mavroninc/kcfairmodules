# See LICENSE file for full copyright and licensing details.

import os
import tempfile
import textwrap

import odoo
from odoo.tests import tagged, TransactionCase


@tagged('post_install', '-at_install')
class TestInstallationWizardQueueJobConfig(TransactionCase):
    """Validate legacy queue_job_* and [queue_job] section formats."""

    def setUp(self):
        super().setUp()
        self.wizard = self.env['quickbooks.installation.wizard'].create({})
        self._original_config_path = odoo.tools.config['config']
        self.addCleanup(self._restore_config_path)

    def _restore_config_path(self):
        odoo.tools.config['config'] = self._original_config_path

    def _write_conf(self, content):
        fd, path = tempfile.mkstemp(suffix='.conf')
        with os.fdopen(fd, 'w') as conf_file:
            conf_file.write(textwrap.dedent(content).lstrip())
        self.addCleanup(lambda p=path: os.path.exists(p) and os.unlink(p))
        odoo.tools.config['config'] = path
        return path

    def test_legacy_format_valid(self):
        self._write_conf('''\
            [options]
            queue_job_channels = root:1
            queue_job_scheme = http
            queue_job_host = localhost
            queue_job_port = 8069
        ''')
        errors = self.wizard._check_queue_job_config('http', 'localhost', 8069)
        self.assertFalse(errors)

    def test_new_section_format_valid(self):
        self._write_conf('''\
            [options]
            db_name = test

            [queue_job]
            channels = root:1
            scheme = http
            host = localhost
            port = 8069
        ''')
        errors = self.wizard._check_queue_job_config('http', 'localhost', 8069)
        self.assertFalse(errors)

    def test_mixed_formats_rejected(self):
        self._write_conf('''\
            [options]
            queue_job_host = localhost
            queue_job_port = 8069

            [queue_job]
            channels = root:1
            scheme = http
        ''')
        errors = self.wizard._check_queue_job_config('http', 'localhost', 8069)
        self.assertEqual(len(errors), 1)
        self.assertIn('Mixed queue_job configuration formats', errors[0])

    def test_legacy_invalid_value_reports_error(self):
        self._write_conf('''\
            [options]
            queue_job_channels = root:1
            queue_job_scheme = http
            queue_job_host = localhost
            queue_job_port = 80
        ''')
        errors = self.wizard._check_queue_job_config('http', 'localhost', 8069)
        self.assertTrue(any('queue_job_port' in error for error in errors))

    def test_new_section_invalid_value_reports_error(self):
        self._write_conf('''\
            [options]
            db_name = test

            [queue_job]
            channels = root:1
            scheme = https
            host = localhost
            port = 8069
        ''')
        errors = self.wizard._check_queue_job_config('http', 'localhost', 8069)
        self.assertTrue(any('scheme' in error and 'expected: http' in error for error in errors))

    def test_config_template_uses_new_section_format(self):
        self.wizard._build_config_template(
            'http', 'localhost', 8069, False, 'base,web,integration_queue_job',
        )
        template = self.wizard.config_template
        self.assertIn('[queue_job]', template)
        self.assertIn('channels = root:1', template)
        self.assertIn('scheme = http', template)
        self.assertIn('host = localhost', template)
        self.assertIn('port = 8069', template)
        self.assertNotIn('queue_job_channels', template)
        self.assertNotIn('queue_job_scheme', template)
        self.assertNotIn('queue_job_host', template)
        self.assertNotIn('queue_job_port', template)
