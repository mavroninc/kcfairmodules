# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo.tests import tagged, TransactionCase

from ..tools import (
    ITEM_BASED_EXPENSE_LINE_DETAIL,
    ACCOUNT_BASED_EXPENSE_LINE_DETAIL,
)
from ..models.mapping.abstract.qbo_map_tax_mixin import SALES_ITEM_LINE_DETAIL


@tagged('-at_install', 'post_install', 'qbo_bill_expense_lines')
class TestBillExpenseLines(TransactionCase):
    """Which kind of line a bill hands to QuickBooks.

    A bill line without a product is an expense against an account. QuickBooks
    takes such a line on its own and alongside item lines in one bill, and it
    refuses an item line whose ItemRef is missing -- measured against the
    sandbox, error 2020 "Required parameter
    Line.ItemBasedExpenseLineDetail.ItemRef is required".
    """

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.country = cls.env.ref('base.us')
        cls.company = cls.env['res.company'].create({
            'name': 'Bill Lines Co',
            'country_id': cls.country.id,
        })
        cls.tax_group = cls.env['account.tax.group'].create({
            'name': 'Bill Lines Group',
            'company_id': cls.company.id,
        })
        cls.expense_account = cls.env['account.account'].create({
            'name': 'Expenses',
            'code': 'BL600000',
            'account_type': 'expense',
            'company_ids': [(6, 0, cls.company.ids)],
        })
        cls.product = cls.env['product.product'].create({'name': 'Bill Lines Product'})

    def _line(self, product=None):
        """A bill line of the given kind, not stored -- only its type is asked."""
        move = self.env['account.move'].new({
            'move_type': 'in_invoice',
            'company_id': self.company.id,
        })

        return self.env['account.move.line'].new({
            'move_id': move.id,
            'product_id': product and product.id,
            'account_id': self.expense_account.id,
        })

    def test_a_bill_line_with_a_product_is_an_item_line(self):
        self.assertEqual(self._line(self.product).qbo_detail_type,
                         ITEM_BASED_EXPENSE_LINE_DETAIL)

    def test_a_bill_line_without_a_product_is_an_account_line(self):
        self.assertEqual(self._line().qbo_detail_type,
                         ACCOUNT_BASED_EXPENSE_LINE_DETAIL)

    def test_a_customer_line_is_always_an_item_line(self):
        """The two kinds are a bill thing; a customer document has one kind."""
        move = self.env['account.move'].new({
            'move_type': 'out_invoice',
            'company_id': self.company.id,
        })
        line = self.env['account.move.line'].new({
            'move_id': move.id,
            'account_id': self.expense_account.id,
        })

        self.assertEqual(line.qbo_detail_type, SALES_ITEM_LINE_DETAIL)

    def test_a_bill_of_expense_lines_only_is_no_longer_refused(self):
        """The check used to refuse the whole bill over a product-less line."""
        move = self.env['account.move'].new({
            'move_type': 'in_invoice',
            'company_id': self.company.id,
            'invoice_line_ids': [
                (0, 0, {
                    'display_type': 'product',
                    'name': 'Rent',
                    'quantity': 1,
                    'price_unit': 500.0,
                    'account_id': self.expense_account.id,
                }),
            ],
        })

        self.assertTrue(move._check_products_qbo())

    def test_a_bill_with_no_lines_at_all_is_still_refused(self):
        move = self.env['account.move'].new({
            'move_type': 'in_invoice',
            'company_id': self.company.id,
        })

        with self.assertRaises(Exception):
            move._check_products_qbo()
