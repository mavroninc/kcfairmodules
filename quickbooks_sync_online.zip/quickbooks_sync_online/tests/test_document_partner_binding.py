# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import json

from odoo.tests import tagged, TransactionCase


@tagged('-at_install', 'post_install', 'qbo_document_partner')
class TestDocumentPartnerBinding(TransactionCase):
    """Importing a document binds the contact's mapping, whether the contact was
    created for it or matched to one Odoo already had."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'Document Partner Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Document partner connection',
            'company_id': cls.company.id,
        })

    def _customer_card(self, display_name, email):
        return self.env['qbo.map.partner'].create({
            'qbo_id': '660',
            'qbo_name': display_name,
            'qbo_lib_type': 'customer',
            'quickbooks_integration_id': self.connection.id,
            'qbo_object': json.dumps({
                'Id': '660',
                'DisplayName': display_name,
                'PrimaryEmailAddr': {'Address': email},
                'CurrencyRef': {'value': self.company.currency_id.name},
            }),
        })

    def _document(self):
        return self.env['qbo.map.account.move'].create({
            'qbo_id': '770',
            'qbo_name': 'INV-770',
            'qbo_lib_type': 'invoice',
            'quickbooks_integration_id': self.connection.id,
            'qbo_object': json.dumps({
                'Id': '770',
                'DocNumber': 'INV-770',
                'CustomerRef': {'value': '660'},
            }),
        })

    def test_a_matched_contact_leaves_the_mapping_bound(self):
        """The case that used to fail: the contact is found, so the branch that
        binds the mapping never ran and the export later pushed a second card."""
        existing = self.env['res.partner'].create({
            'name': 'Match Me',
            'email': 'match@example.com',
        })
        card = self._customer_card('Match Me', 'match@example.com')

        partner = self._document().create_partner_in_odoo()

        self.assertEqual(partner, existing)
        self.assertEqual(card.partner_id, existing)

    def test_a_contact_that_has_to_be_created_is_bound_too(self):
        card = self._customer_card('Brand New Co', 'new@example.com')

        partner = self._document().create_partner_in_odoo()

        self.assertEqual(partner.name, 'Brand New Co')
        self.assertEqual(card.partner_id, partner)

    def test_an_already_bound_mapping_is_taken_as_it_stands(self):
        partner = self.env['res.partner'].create({'name': 'Bound Already'})
        card = self._customer_card('Bound Already', 'bound@example.com')
        card.partner_id = partner.id

        self.assertEqual(self._document().create_partner_in_odoo(), partner)
        self.assertEqual(card.partner_id, partner)

    def test_the_export_then_finds_the_card_instead_of_making_another(self):
        """A bound mapping is what sends the export down the update path."""
        existing = self.env['res.partner'].create({
            'name': 'Match Me',
            'email': 'match@example.com',
        })
        self._customer_card('Match Me', 'match@example.com')

        self._document().create_partner_in_odoo()

        self.assertEqual(
            existing._get_qbo_mapping(self.connection.id, 'customer').qbo_id, '660')
