# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo.tests import tagged, TransactionCase


@tagged('-at_install', 'post_install', 'qbo_pending_actions')
class TestPendingActions(TransactionCase):
    """The "pending" shortcuts open a list, they do not enumerate it."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'Pending Lists Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Pending lists connection',
            'company_id': cls.company.id,
        })

    def test_pending_products_open_a_searchable_list(self):
        action = self.connection.action_get_all_pending_products()

        self.assertEqual(action['res_model'], 'product.product')
        self.assertEqual(action['domain'], [('is_qbo_update_required', '=', True)])

    def test_pending_partners_open_a_searchable_list(self):
        action = self.connection.action_get_all_pending_partners()

        self.assertEqual(action['res_model'], 'res.partner')
        self.assertEqual(action['domain'], [('is_qbo_update_required', '=', True)])

    def test_the_list_follows_the_records_that_are_marked(self):
        """A domain keeps up with the data, a list of ids is a snapshot."""
        product = self.env['product.product'].create({'name': 'Pending list product'})
        action = self.connection.action_get_all_pending_products()

        self.assertNotIn(product, self.env['product.product'].search(action['domain']))

        product.mark_for_qbo_update()
        self.assertIn(product, self.env['product.product'].search(action['domain']))
