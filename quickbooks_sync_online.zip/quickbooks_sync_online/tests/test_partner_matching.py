# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import json

from odoo.tests import tagged, TransactionCase


@tagged('-at_install', 'post_install', 'qbo_partner_matching')
class TestPartnerMatching(TransactionCase):
    """Which Odoo contact a QuickBooks card is taken to be."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'Partner matching Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Partner matching connection',
            'company_id': cls.company.id,
        })
        cls.sequence = iter(range(950, 999))

        cls.other_company = cls.env['res.company'].create({'name': 'Partner matching Co 2'})
        cls.other_connection = cls.env['quickbooks.integration'].create({
            'name': 'Partner matching connection 2',
            'company_id': cls.other_company.id,
        })

    def _card(self, display_name, company_name='', email='', connection=None):
        qbo_id = str(next(self.sequence))
        body = {
            'Id': qbo_id,
            'DisplayName': display_name,
            'CurrencyRef': {'value': self.company.currency_id.name},
        }

        if company_name:
            body['CompanyName'] = company_name
        if email:
            body['PrimaryEmailAddr'] = {'Address': email}

        return self.env['qbo.map.partner'].create({
            'qbo_id': qbo_id,
            'qbo_name': display_name,
            'qbo_lib_type': 'customer',
            'quickbooks_integration_id': (connection or self.connection).id,
            'qbo_object': json.dumps(body),
        })

    def test_a_name_in_another_case_is_the_same_contact(self):
        partner = self.env['res.partner'].create({'name': 'acme llc'})

        self.assertEqual(self._card('ACME LLC')._find_odoo_partner(), partner)

    def test_an_email_in_another_case_is_the_same_address(self):
        """The import lowercases the address it reads while Odoo keeps what was
        entered, so an exact comparison failed on the same address."""
        partner = self.env['res.partner'].create({
            'name': 'Bob',
            'email': 'Bob@Example.COM',
        })

        self.assertEqual(
            self._card('Bob', email='Bob@Example.COM')._find_odoo_partner(), partner)

    def test_a_person_at_a_company_matches_a_person(self):
        """A card naming a person at a company is read as a person, so the company
        half of the domain is not asked for and a plain contact matches.

        The contact carries no company of its own: Odoo 20 removed
        `res.partner.company_name`, the free text this used to be created with.
        """
        partner = self.env['res.partner'].create({'name': 'John Smith'})

        card = self._card('John Smith', company_name='Acme Inc')

        self.assertFalse(card.is_qbo_company)
        self.assertEqual(card._find_odoo_partner(), partner)

    def test_a_company_still_matches_a_company(self):
        """A contact of nobody is its own commercial partner, so
        `commercial_company_name` answers with its own name -- which is what the
        company half of the domain compares against.

        `is_company` is not set here and is not asked for: Odoo 20 computes it
        from the Tax ID, which a QuickBooks customer generally does not carry, so
        a domain asking for it would match no company card at all.
        """
        partner = self.env['res.partner'].create({'name': 'Cool Cars'})

        card = self._card('Cool Cars', company_name='Cool Cars')

        self.assertTrue(card.is_qbo_company)
        self.assertEqual(card._find_odoo_partner(), partner)

    def test_another_email_is_another_contact(self):
        self.env['res.partner'].create({'name': 'Bob', 'email': 'bob@example.com'})

        self.assertFalse(
            self._card('Bob', email='someone.else@example.com')._find_odoo_partner())

    def test_a_name_nobody_carries_matches_nothing(self):
        self.assertFalse(self._card('Nobody Here')._find_odoo_partner())

    def test_a_contact_of_another_company_is_not_a_candidate(self):
        """It used to be, and the document import then failed on Odoo's own
        company check rather than on anything to do with QuickBooks."""
        theirs = self.env['res.partner'].create({
            'name': 'Their Contact',
            'company_id': self.other_company.id,
        })

        self.assertFalse(self._card('Their Contact')._find_odoo_partner())
        self.assertEqual(
            self._card('Their Contact', connection=self.other_connection)._find_odoo_partner(),
            theirs,
        )

    def test_a_contact_of_this_company_still_matches(self):
        ours = self.env['res.partner'].create({
            'name': 'Our Contact',
            'company_id': self.company.id,
        })

        self.assertEqual(self._card('Our Contact')._find_odoo_partner(), ours)

    def test_a_shared_contact_matches_either_company(self):
        """Most contacts belong to no company in particular."""
        shared = self.env['res.partner'].create({'name': 'Shared Contact'})

        self.assertEqual(self._card('Shared Contact')._find_odoo_partner(), shared)
        self.assertEqual(
            self._card('Shared Contact', connection=self.other_connection)._find_odoo_partner(),
            shared,
        )
