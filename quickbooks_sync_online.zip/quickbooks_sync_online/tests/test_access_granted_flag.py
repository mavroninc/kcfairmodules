# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo.tests import tagged, TransactionCase


@tagged('-at_install', 'post_install', 'qbo_access_granted')
class TestAccessGrantedFlag(TransactionCase):
    """`qb_access_granted` follows the credentials on its own."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'Access Flag Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Access flag connection',
            'company_id': cls.company.id,
        })
        cls.credentials = {
            'qb_company_id': 'REALM',
            'qb_client_id': 'CLIENT',
            'qb_client_secret': 'SECRET',
            'qb_access_token': 'ACCESS',
            'qb_refresh_token': 'REFRESH',
        }

    def test_the_flag_is_declared_on_the_credentials(self):
        field = self.env['quickbooks.integration']._fields['qb_access_granted']
        depends = self.env.registry.field_depends[field]

        self.assertEqual(set(depends), set(self.credentials))

    def test_the_flag_follows_a_credential_being_set(self):
        self.assertFalse(self.connection.qb_access_granted)

        self.connection.write(self.credentials)
        self.assertTrue(self.connection.qb_access_granted)

    def test_the_flag_follows_a_credential_being_cleared(self):
        """Nobody has to call the compute by hand after writing the tokens."""
        self.connection.write(self.credentials)

        for name in self.credentials:
            self.connection.write({name: False})
            self.assertFalse(
                self.connection.qb_access_granted,
                'clearing %s left the connection marked as granted' % name,
            )
            self.connection.write({name: self.credentials[name]})
            self.assertTrue(self.connection.qb_access_granted)

    def test_a_user_without_rights_still_reads_the_flag(self):
        """The credentials are restricted, the flag they drive is not."""
        self.connection.write(self.credentials)

        employee = self.env['res.users'].create({
            'name': 'Employee',
            'login': 'qbo.access.flag.employee',
            'company_ids': [(4, self.company.id)],
            'company_id': self.company.id,
            'group_ids': [(6, 0, [self.env.ref('base.group_user').id])],
        })

        self.assertTrue(self.connection.with_user(employee).qb_access_granted)
