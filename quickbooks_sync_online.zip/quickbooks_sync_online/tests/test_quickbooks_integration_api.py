# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from datetime import datetime, date
from unittest.mock import patch, MagicMock

from psycopg2.errors import UniqueViolation

from odoo import fields
from odoo.tests import tagged
from odoo.tools import mute_logger
from odoo.exceptions import ValidationError, UserError

from .config.request_patcher import RequestPatcher
from .config.intuit_case import (
    IMPORT_MODELS_BY_BATCH,
    request_client,
    QuickbooksInit,
)

from ..tools import TAXABLE, NON_TAXABLE, ExtractNode


PRODUCT = 'item'
VENDOR = 'vendor'
CUSTOMER = 'customer'
INVOICE = 'invoice'
CREDIT_NOTE = 'creditmemo'
BILL = 'bill'
VENDOR_CREDIT = 'vendorcredit'
PAYMENT = 'payment'
SALE_ORDER = 'salesreceipt'


@tagged('-at_install', '-standard', 'post_install', 'qbo_test_api')
class TestQuickbooksIntegrationAPI(QuickbooksInit):

    def setUp(self):
        super(TestQuickbooksIntegrationAPI, self).setUp()

        self.patcher = RequestPatcher()

        self._set_up_connection()
        self._fill_the_dadabase()
        self._load_xml('init_accounts.xml')
        self._set_ir_defaults()
        self._configure_product_category_accounts()
        self.map_default_company_stock_account()
        self._ensure_qbo_import_auxiliary_products()

    def _ensure_qbo_import_auxiliary_products(self):
        """Discount and shipping lines in imported QBO invoices need configured service products."""
        Product = self.env['product.product']
        services_categ = self.env.ref('product.product_category_services')
        if not self.qi.discount_product_id:
            self.qi.discount_product_id = Product.create({
                'name': 'QBO Connector Test Discount',
                'type': 'service',
                'categ_id': services_categ.id,
            })
        if not self.qi.shipping_product_id:
            self.qi.shipping_product_id = Product.create({
                'name': 'QBO Connector Test Shipping',
                'type': 'service',
                'categ_id': services_categ.id,
            })

    def _invoice_product_lines(self, invoice):
        return invoice.invoice_line_ids.filtered(lambda l: l.display_type == 'product')

    def _set_ir_defaults(self):
        self.env['ir.default'].set(
            'product.category',
            'property_account_expense_categ_id',
            self.env.ref('quickbooks_sync_online.a_expense').id,
            company_id=self.company.id,
        )
        self.env['ir.default'].set(
            'product.category',
            'property_account_income_categ_id',
            self.env.ref('quickbooks_sync_online.a_sale').id,
            company_id=self.company.id,
        )
        self.env['ir.default'].set(
            'product.category',
            'property_stock_valuation_account_id',
            self.env.ref('quickbooks_sync_online.stk').id,
            company_id=self.company.id,
        )
        self.env['ir.default'].set(
            'res.partner',
            'property_account_payable_id',
            self.env.ref('quickbooks_sync_online.a_pay').id,
            company_id=self.company.id,
        )

    def _configure_product_category_accounts(self):
        """Existing standard categories do not inherit ir.defaults; set accounts explicitly."""
        a_sale = self.env.ref('quickbooks_sync_online.a_sale')
        a_expense = self.env.ref('quickbooks_sync_online.a_expense')
        stk = self.env.ref('quickbooks_sync_online.stk')
        self.company.write({
            'income_account_id': a_sale.id,
            'expense_account_id': a_expense.id,
        })
        Category = self.env['product.category'].with_company(self.company)
        for xmlid in (
            'product.product_category_goods',
            'product.product_category_services',
            'product.product_category_expenses',
        ):
            Category.browse(self.env.ref(xmlid).id).write({
                'property_account_income_categ_id': a_sale.id,
                'property_account_expense_categ_id': a_expense.id,
                'property_stock_valuation_account_id': stk.id,
            })

    def _set_product_qty_on_hand(self, product, quantity=1.0):
        """Set on-hand quantity required for first-time storable product export to QBO."""
        product.write({'qty_available': quantity})

    @patch(request_client)
    def _fill_the_dadabase(self, *args):
        for _name in IMPORT_MODELS_BY_BATCH:
            model_id = self.env[_name]
            for map_type in model_id.map_types:
                with self.patcher(map_type):
                    model_id._fetch_resource_data_from_qbo(self.qi.id, map_type)

    def create_tax(self):
        return self.env['account.tax'].create({
            'name': '15% Test',
            'type_tax_use': 'sale',
            'amount': 15,
            'tax_group_id': self.env.ref('quickbooks_sync_online.tax_group_15_test').id,
            'company_id': self.company.id,
            'amount_type': 'percent',
        })

    def proxy_models(self):
        return [self.env[name] for name in IMPORT_MODELS_BY_BATCH]

    def map_all_accounts(self):
        self.map_default_company_stock_account()

        intuit_accounts = self.env['qbo.map.account'].search([
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        intuit_accounts.try_to_map(do_create=False)
        return intuit_accounts.filtered('account_id')

    def map_cost_of_gods_sold(self):
        account = self.env['qbo.map.account'].search([
            ('qbo_name', '=', 'Cost of Goods Sold (test)'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        account.try_to_map(do_create=False)

    def map_sales_income(self):
        account = self.env['qbo.map.account'].search([
            ('qbo_name', '=', 'Sales of Product Income (test)'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        account.try_to_map(do_create=False)

    def map_default_company_stock_account(self):
        self.qi.write({
            'qi_default_stock_valuation_account_id': self.env.ref('quickbooks_sync_online.stk').id,
        })

    def map_inventory_asset(self):
        account = self.env['qbo.map.account'].search([
            ('qbo_name', '=', 'Inventory Asset (test)'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        account.try_to_map(do_create=False)

    def map_account_payable(self):
        account = self.env['qbo.map.account'].search([
            ('qbo_name', '=', 'Accounts Payable (A/P) (test)'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        account.try_to_map(do_create=False)

    def map_payment_defaults(self):
        self.qi.write({
            'qi_default_journal_id': self.env.ref('quickbooks_sync_online.bank_journal').id,
        })
        cash_method = self.env['qbo.map.payment.method'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        cash_method.write({
            'journal_id': self.env.ref('quickbooks_sync_online.cash_journal').id,
        })

    def test_import_count(self):
        for model_id in self.proxy_models():
            for map_type in model_id.map_types:
                records_count = model_id.search_count([
                    ('qbo_lib_type', '=', map_type),
                    ('quickbooks_integration_id', '=', self.qi.id),
                ])
                remote_records_count = self.patcher.get_records_count(map_type)
                self.assertEqual(records_count, remote_records_count)

    def test_map_or_create_inventory_product_from_map_object(self):
        inventory_214 = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '214'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        self.assertEqual(inventory_214.qbo_name, 'Flag_AWSECrfaew')
        self.assertEqual(inventory_214.display_name, '[8976] Flag_AWSECrfaew')
        self.assertEqual(inventory_214.stock_keeping_unit, '8976')
        self.assertEqual(inventory_214.product_id.id, False)
        self.assertEqual(inventory_214.qbo_lib_type, PRODUCT)

        inventory_214._create_odoo_record()
        product1 = inventory_214.product_id

        self.assertTrue(product1.active)
        self.assertEqual(product1.name, 'Flag_AWSECrfaew')
        self.assertEqual(product1.type, 'consu')
        self.assertTrue(product1.is_storable)
        self.assertEqual(product1.description_sale, 'Sale Description')
        self.assertEqual(product1.description_purchase, '')
        self.assertEqual(product1.default_code, '8976')
        self.assertEqual(product1.list_price, 90)
        self.assertEqual(product1.standard_price, 78)

        # Another one
        inventory_215 = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '215'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        self.assertEqual(inventory_215.qbo_name, 'Corner Desk Black_jhdrThg')
        self.assertEqual(inventory_215.display_name, '[FURN_1118_1] Corner Desk Black_jhdrThg')
        self.assertEqual(inventory_215.stock_keeping_unit, 'FURN_1118_1')
        self.assertEqual(inventory_215.product_id.id, False)
        self.assertEqual(inventory_215.qbo_lib_type, PRODUCT)

        inventory_215._create_odoo_record()
        product2 = inventory_215.product_id

        self.assertTrue(product2.active)
        self.assertEqual(product2.name, 'Corner Desk Black_jhdrThg')
        self.assertEqual(product2.type, 'consu')
        self.assertTrue(product1.is_storable)
        self.assertEqual(product2.description_sale, '')
        self.assertEqual(product2.description_purchase, '')
        self.assertEqual(product2.default_code, 'FURN_1118_1')
        self.assertEqual(product2.list_price, 85)
        self.assertEqual(product2.standard_price, 78)

        # Unmap models and create odoo product copy
        records = inventory_214 + inventory_215
        records.write({'product_id': False})
        product1.copy({
            'name': 'Flag_AWSECrfaew',
            'default_code': '8976',
        })
        # Try to map
        records.try_to_map(summary=False)
        # Check mapping result
        self.assertEqual(inventory_214.product_id.id, False)
        self.assertEqual(inventory_215.product_id.id, product2.id)

    def test_map_or_create_consumable_product_from_map_object(self):
        consum_126 = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '126'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        self.assertEqual(consum_126.qbo_name, 'Table_Ert254g')
        self.assertEqual(consum_126.display_name, '[89977897] Table_Ert254g')
        self.assertEqual(consum_126.stock_keeping_unit, '89977897')
        self.assertEqual(consum_126.product_id.id, False)
        self.assertEqual(consum_126.qbo_lib_type, PRODUCT)

        consum_126._create_odoo_record()
        product1 = consum_126.product_id

        self.assertTrue(product1.active)
        self.assertEqual(product1.name, 'Table_Ert254g')
        self.assertEqual(product1.type, 'consu')
        self.assertFalse(product1.is_storable)
        self.assertEqual(product1.description_sale, '')
        self.assertEqual(product1.description_purchase, '')
        self.assertEqual(product1.default_code, '89977897')
        self.assertEqual(product1.list_price, 99.9)
        self.assertEqual(product1.standard_price, 67.8)

        # Another one
        consum_137 = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '137'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        self.assertEqual(consum_137.qbo_name, 'Another Table_Ert254g')
        self.assertEqual(consum_137.display_name, 'Another Table_Ert254g')
        self.assertEqual(consum_137.stock_keeping_unit, False)
        self.assertEqual(consum_137.product_id.id, False)
        self.assertEqual(consum_137.qbo_lib_type, PRODUCT)

        consum_137._create_odoo_record()
        product2 = consum_137.product_id

        self.assertTrue(product2.active)
        self.assertEqual(product2.name, 'Another Table_Ert254g')
        self.assertEqual(product2.type, 'consu')
        self.assertFalse(product1.is_storable)
        self.assertEqual(product2.description_sale, '')
        self.assertEqual(product2.description_purchase, 'Some purchase description..')
        self.assertEqual(product2.default_code, False)
        self.assertEqual(product2.list_price, 89)
        self.assertEqual(product2.standard_price, 0)

        # Unmap models and create odoo product copy
        records = consum_126 + consum_137
        records.write({'product_id': False})
        product1.copy({
            'name': 'Table_Ert254g',
            'default_code': '89977897',
        })
        # Try to map
        records.try_to_map(summary=False)
        # Check mapping result
        self.assertEqual(consum_126.product_id.id, False)
        self.assertEqual(consum_137.product_id.id, product2.id)

    def test_map_or_create_service_product_from_map_object(self):
        service_3 = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '3'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        self.assertEqual(service_3.qbo_name, 'Concrete3_QDSVCrt')
        self.assertEqual(service_3.display_name, 'Concrete3_QDSVCrt')
        self.assertEqual(service_3.stock_keeping_unit, False)
        self.assertEqual(service_3.product_id.id, False)
        self.assertEqual(service_3.qbo_lib_type, PRODUCT)

        service_3._create_odoo_record()
        product1 = service_3.product_id

        self.assertTrue(product1.active)
        self.assertEqual(product1.name, 'Concrete3_QDSVCrt')
        self.assertEqual(product1.type, 'service')
        self.assertEqual(product1.description_sale, 'Concrete for fountain installation')
        self.assertEqual(product1.description_purchase, '')
        self.assertEqual(product1.default_code, False)
        self.assertEqual(product1.list_price, 0)
        self.assertEqual(product1.standard_price, 0)

        # Another one
        service_4 = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '4'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        self.assertEqual(service_4.qbo_name, 'Design CevrTw45')
        self.assertEqual(service_4.display_name, 'Design CevrTw45')
        self.assertEqual(service_4.stock_keeping_unit, False)
        self.assertEqual(service_4.product_id.id, False)
        self.assertEqual(service_3.qbo_lib_type, PRODUCT)

        service_4._create_odoo_record()
        product2 = service_4.product_id

        self.assertTrue(product2.active)
        self.assertEqual(product2.name, 'Design CevrTw45')
        self.assertEqual(product2.type, 'service')
        self.assertEqual(product2.description_sale, 'Custom Design')
        self.assertEqual(product2.description_purchase, '')
        self.assertEqual(product2.default_code, False)
        self.assertEqual(product2.list_price, 75)
        self.assertEqual(product2.standard_price, 0)

        # Unmap models and create odoo product copy
        records = service_3 + service_4
        records.write({'product_id': False})
        product1.copy({'name': 'Concrete3_QDSVCrt'})
        # Try to map
        records.try_to_map(summary=False)
        # Check mapping result
        self.assertEqual(service_3.product_id.id, False)
        self.assertEqual(service_4.product_id.id, product2.id)

    def test_map_or_create_unsupported_type_from_map_object(self):
        category_64 = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '64'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        self.assertEqual(category_64.qbo_name, 'T-Shirt Unisex')
        self.assertEqual(category_64.stock_keeping_unit, False)
        self.assertEqual(category_64.product_id.id, False)
        self.assertEqual(category_64.qbo_lib_type, PRODUCT)

        with self.assertRaises(ValidationError):
            category_64._create_odoo_record()

    def test_map_or_create_customer_from_map_object(self):
        map_customer_2 = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '2'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        self.assertEqual(map_customer_2.qbo_name, 'Bill Windsurf Display Name')
        self.assertEqual(map_customer_2.partner_id.id, False)

        map_customer_2.create_instance_in_odoo()
        customer1 = map_customer_2.partner_id

        self.assertTrue(customer1.active)
        self.assertEqual(customer1.name, 'Bill Windsurf Display Name')
        # Odoo 20 removed `res.partner.company_name`, so the card holds the
        # company the contact belongs to and the export reads it back from there.
        self.assertEqual(map_customer_2.qbo_company_name, 'Bill Windsurf Company')
        self.assertFalse(map_customer_2.is_qbo_company)
        self.assertEqual(customer1.email, 'surf_acesrcdfg@intuit.com')
        self.assertEqual(customer1.phone, '5555554354611')

        billing = customer1.child_ids.filtered(lambda r: r.type == 'invoice')
        self.assertFalse(bool(billing))

        self.assertEqual(customer1.city, '12 Ocean Dr.')
        self.assertEqual(customer1.country_id.name, 'United States')
        self.assertEqual(customer1.state_id.name, 'California')
        self.assertEqual(customer1.street, 'Half Moon Bay')
        self.assertEqual(customer1.street2, 'Moon bay-j')
        self.assertEqual(customer1.zip, '94213')

        shipping = customer1.child_ids.filtered(lambda r: r.type == 'delivery')
        self.assertFalse(bool(shipping))

    def test_map_or_create_vendor_from_map_object(self):
        map_vendor_30 = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '30'),
            ('qbo_lib_type', '=', VENDOR),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        self.assertEqual(map_vendor_30.qbo_name, 'Books by Bessie Display Name')
        self.assertEqual(map_vendor_30.partner_id.id, False)

        map_vendor_30.create_instance_in_odoo()
        vendor1 = map_vendor_30.partner_id

        self.assertTrue(vendor1.active)
        self.assertEqual(vendor1.name, 'Books by Bessie Display Name')
        self.assertEqual(map_vendor_30.qbo_company_name, 'Books by Bessie Company')
        self.assertFalse(map_vendor_30.is_qbo_company)
        self.assertEqual(vendor1.email, 'books_sadfvcdt54@intuit.com')
        self.assertEqual(vendor1.phone, '+16505557745')

        billing = vendor1.child_ids.filtered(lambda r: r.type == 'invoice')
        self.assertFalse(bool(billing))

        self.assertEqual(vendor1.city, 'Palo Alto')
        self.assertEqual(vendor1.country_id.name, 'United States')
        self.assertEqual(vendor1.state_id.name, 'California')
        self.assertEqual(vendor1.street, '15 Main St.')
        self.assertFalse(vendor1.street2)
        self.assertEqual(vendor1.zip, '94303')

        shipping = vendor1.child_ids.filtered(lambda r: r.type == 'delivery')
        self.assertEqual(shipping.city, 'Palo Alto Mid')
        self.assertEqual(shipping.country_id.name, 'United States')
        self.assertEqual(shipping.state_id.name, 'California')
        self.assertEqual(shipping.street, '10 Main St.')
        self.assertEqual(shipping.street2, '43 Main St.')
        self.assertEqual(shipping.zip, '94344')

    def test_auto_map_accounts(self):
        mapped_account_ids = self.map_all_accounts().mapped('qbo_id')
        for qbo_id in ['33', '81', '79', '113']:
            self.assertIn(qbo_id, mapped_account_ids)

    @patch(request_client)
    def test_update_map_product_from_odoo_product(self, *args):
        # Unmap default company stock account
        self.qi.write({
            'qi_default_stock_valuation_account_id': False,
        })
        records = self.env['qbo.map.product'].search([
            ('qbo_id', 'in', ['67', '71']),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        self.assertTrue(len(records) == 2)
        inventory_67 = records.filtered(lambda r: r.qbo_id == '67')
        inventory_71 = records.filtered(lambda r: r.qbo_id == '71')

        inventory_67.create_instance_in_odoo()
        product1 = inventory_67.product_id
        self.assertTrue(product1.id)

        # Assert raise due to product has no a mapping
        inventory_67.write({'product_id': False})
        with self.assertRaises(ValidationError):
            product1._get_map_instance_or_raise(self.qi.id, PRODUCT)

        # Assert raise due to product has the several mapping
        records.write({'product_id': product1.id})
        with self.assertRaises(ValidationError):
            product1._get_map_instance_or_raise(self.qi.id, PRODUCT)

        inventory_71.write({'product_id': False})
        get_inventory_67 = product1._get_map_instance_or_raise(self.qi.id, PRODUCT)
        self.assertEqual(inventory_67, get_inventory_67)

        # Assert raise due to unmapped accounts
        with self.assertRaises(ValidationError):
            product1._check_qbo_requirements(self.qi.id)

        self.map_sales_income()
        self.map_cost_of_gods_sold()
        self.map_default_company_stock_account()
        self.map_inventory_asset()
        product1._check_qbo_requirements(self.qi.id)

        # Update product after all checks
        with self.patcher(PRODUCT):
            inventory_67.update_qbo_one()

    @patch(request_client)
    def test_update_map_partner_from_odoo_partner(self, *args):
        customer_3 = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '3'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        self.assertTrue(len(customer_3) == 1)

        customer_3.create_instance_in_odoo()

        partner1 = customer_3.partner_id
        self.assertTrue(partner1.id)

        # Update the patrner after all checks
        with self.patcher(CUSTOMER):
            customer_3.update_qbo_one()

    def test_check_constraints_export_customer_to_qbo(self):
        partner1 = self.env['res.partner'].create({
            'name': 'John Wayne Customer',
        })
        # 1. No map-partner before export
        qbo_mapping_ids = partner1.qbo_mapping_ids.filtered(
            lambda r: r.quickbooks_integration_id == self.qi
        )
        self.assertFalse(qbo_mapping_ids)

        # 2. Assert raise due to more than one related map-objects exists
        map_partners = self.env['qbo.map.partner'].search([
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ], limit=2)

        self.assertTrue(len(map_partners) == 2)
        map_partners.write({'partner_id': partner1.id})

        with self.assertRaises(ValidationError):
            partner1.with_context(with_qbo_partner_type=CUSTOMER).action_export_to_quickbooks()

    @patch(request_client)
    def test_export_customer_to_qbo(self, *args):
        partner = self.env['res.partner'].create({
            'name': 'John Wayne Customer',
        })

        # No map-partner before export
        map_partner = partner._get_qbo_mapping(self.qi.id, CUSTOMER)
        self.assertFalse(map_partner)

        # Perform export
        self.assertFalse(partner.is_qbo_sync_done)

        with self.patcher(CUSTOMER):
            partner.with_context(with_qbo_partner_type=CUSTOMER).action_export_to_quickbooks()

        # Map-partner exist
        map_partner = partner._get_qbo_mapping(self.qi.id, CUSTOMER)

        self.assertTrue(len(map_partner) == 1)
        self.assertTrue(map_partner.qbo_lib_type == CUSTOMER)
        self.assertTrue(partner.is_qbo_sync_done)

    def test_check_constraints_export_vendor_to_qbo(self):
        partner1 = self.env['res.partner'].create({
            'name': 'John Wayne Vendor',
        })

        # 1. No map-partner before export
        qbo_mapping_ids = partner1.qbo_mapping_ids.filtered(
            lambda r: r.quickbooks_integration_id == self.qi
        )
        self.assertFalse(qbo_mapping_ids)

        # 2. Assert raise due to more than one related map-objects exists
        map_partners = self.env['qbo.map.partner'].search([
            ('qbo_lib_type', '=', VENDOR),
            ('quickbooks_integration_id', '=', self.qi.id),
        ], limit=2)

        self.assertTrue(len(map_partners) == 2)
        map_partners.write({'partner_id': partner1.id})

        with self.assertRaises(ValidationError):
            partner1.with_context(with_qbo_partner_type=VENDOR).action_export_to_quickbooks()

    @patch(request_client)
    def test_export_vendor_to_qbo(self, *args):
        partner = self.env['res.partner'].create({
            'name': 'John Wayne Vendor',
        })

        # No map-partner before export
        map_partner = partner.qbo_mapping_ids.filtered(
            lambda r: r.quickbooks_integration_id == self.qi
        )
        self.assertFalse(map_partner)

        # Perform export
        self.assertFalse(partner.is_qbo_sync_done)
        with self.patcher(VENDOR):
            partner.with_context(with_qbo_partner_type=VENDOR).action_export_to_quickbooks()

        # Map-partner exist
        map_partner = partner.qbo_mapping_ids.filtered(
            lambda r: r.quickbooks_integration_id == self.qi
        )
        self.assertTrue(len(map_partner) == 1)
        self.assertTrue(map_partner.qbo_lib_type == VENDOR)
        self.assertTrue(partner.is_qbo_sync_done)

    @patch(request_client)
    def test_export_inventory_product(self, *args):
        self.map_all_accounts()

        product = self.env['product.product'].create({
            'name': 'Inventory product',
            'type': 'consu',
            'is_storable': True,
            'categ_id': self.env.ref('product.product_category_goods').id,
        })
        self._set_product_qty_on_hand(product)
        mapping = product._get_qbo_mapping(self.qi.id, PRODUCT)
        self.assertFalse(mapping)
        self.assertFalse(product.is_qbo_sync_done)

        with self.patcher(PRODUCT):
            product.action_export_to_quickbooks()

        mapping = product._get_qbo_mapping(self.qi.id, PRODUCT)
        self.assertTrue(len(mapping) == 1)
        self.assertTrue(product.is_qbo_sync_done)

    @patch(request_client)
    def test_check_constraints_export_inventory_product(self, *args):
        # Unmap default company stock account
        self.qi.write({
            'qi_default_stock_valuation_account_id': False,
        })
        product1 = self.env['product.product'].create({
            'name': 'Inventory product',
            'type': 'consu',
            'is_storable': True,
            'categ_id': self.env.ref('product.product_category_goods').id,
        })

        # 1. No map-product before export
        mapping = product1._get_qbo_mapping(self.qi.id, PRODUCT)
        self.assertFalse(mapping)
        self.assertFalse(product1.is_qbo_sync_done)

        # 2. Assert raise due to more than one related mapping exists
        map_products = self.env['qbo.map.product'].search([
            ('qbo_lib_type', '=', PRODUCT),
            ('quickbooks_integration_id', '=', self.qi.id),
        ], limit=2)
        self.assertTrue(len(map_products) == 2)
        map_products.write({'product_id': product1.id})

        with self.assertRaises(ValidationError):
            product1.action_export_to_quickbooks()

        # 3. Assert raise due to unmapped accounts
        map_products.write({
            'qbo_name': 'Just erase names',
            'product_id': False,
        })
        with self.assertRaises(ValidationError):
            product1.action_export_to_quickbooks()

        # 4. Map only income account
        self.map_sales_income()
        with self.assertRaises(ValidationError):
            product1.action_export_to_quickbooks()

        # 5. Map income + expense accounts
        self.map_sales_income()
        self.map_cost_of_gods_sold()
        self.map_default_company_stock_account()
        with self.assertRaises(ValidationError):
            product1.action_export_to_quickbooks()

        # 6. Map income + expense + inventory accounts
        self.map_sales_income()
        self.map_cost_of_gods_sold()
        self.map_inventory_asset()

        with self.assertRaises(ValidationError):
            product1.action_export_to_quickbooks()

        # 7. Set initial quantity on hand and export
        self._set_product_qty_on_hand(product1)

        with self.patcher(PRODUCT):
            product1.action_export_to_quickbooks()

        mapping = product1._get_qbo_mapping(self.qi.id, PRODUCT)
        self.assertTrue(len(mapping) == 1)
        self.assertTrue(product1.is_qbo_sync_done)

    @patch(request_client)
    def test_export_service_product(self, *args):
        self.map_all_accounts()

        product = self.env['product.product'].create({
            'name': 'Service product',
            'type': 'service',
            'categ_id': self.env.ref('product.product_category_services').id,
        })
        mapping = product._get_qbo_mapping(self.qi.id, PRODUCT)
        self.assertFalse(mapping)
        self.assertFalse(product.is_qbo_sync_done)

        with self.patcher(PRODUCT):
            product.action_export_to_quickbooks()

        mapping = product._get_qbo_mapping(self.qi.id, PRODUCT)
        self.assertTrue(len(mapping) == 1)
        self.assertTrue(product.is_qbo_sync_done)

    @patch(request_client)
    def test_check_constraints_export_service_product(self, *args):
        product1 = self.env['product.product'].create({
            'name': 'Service product',
            'type': 'service',
            'categ_id': self.env.ref('product.product_category_services').id,
        })
        self.assertFalse(product1.is_qbo_sync_done)

        # 1. No map-product before export
        mapping = product1._get_qbo_mapping(self.qi.id, PRODUCT)
        self.assertFalse(mapping)

        # 2. Assert raise due to more than one related mapping exists
        map_products = self.env['qbo.map.product'].search([
            ('qbo_lib_type', '=', PRODUCT),
            ('quickbooks_integration_id', '=', self.qi.id),
        ], limit=2)
        self.assertTrue(len(map_products) == 2)
        map_products.write({'product_id': product1.id})

        with self.assertRaises(ValidationError):
            product1.action_export_to_quickbooks()

        # 3. Assert raise due to unmapped accounts
        map_products.write({
            'qbo_name': 'Just erase names',
            'product_id': False,
        })
        with self.assertRaises(ValidationError):
            product1.action_export_to_quickbooks()

        # 4. Map only income account
        self.map_sales_income()
        with self.assertRaises(ValidationError):
            product1.action_export_to_quickbooks()

        # 5. Map income + expense accounts
        self.map_sales_income()
        self.map_cost_of_gods_sold()

        with self.patcher(PRODUCT):
            product1.action_export_to_quickbooks()

        mapping = product1._get_qbo_mapping(self.qi.id, PRODUCT)
        self.assertTrue(len(mapping) == 1)
        self.assertTrue(product1.is_qbo_sync_done)

    @patch(request_client)
    def test_export_consu_product(self, *args):
        self.map_all_accounts()

        product = self.env['product.product'].create({
            'name': 'Consumable product',
            'type': 'consu',
            'categ_id': self.env.ref('product.product_category_goods').id,
        })
        mapping = product._get_qbo_mapping(self.qi.id, PRODUCT)
        self.assertFalse(mapping)
        self.assertFalse(product.is_qbo_sync_done)

        with self.patcher(PRODUCT):
            product.action_export_to_quickbooks()

        mapping = product._get_qbo_mapping(self.qi.id, PRODUCT)
        self.assertTrue(len(mapping) == 1)
        self.assertTrue(product.is_qbo_sync_done)

    @patch(request_client)
    def test_check_constraints_export_consu_product(self, *args):
        product1 = self.env['product.product'].create({
            'name': 'Consumable product',
            'type': 'consu',
            'categ_id': self.env.ref('product.product_category_goods').id,
        })
        self.assertFalse(product1.is_qbo_sync_done)

        # 1. No map-product before export
        mapping = product1._get_qbo_mapping(self.qi.id, PRODUCT)
        self.assertFalse(mapping)

        # 2. Assert raise due to more than one related mapping exists
        map_products = self.env['qbo.map.product'].search([
            ('qbo_lib_type', '=', PRODUCT),
            ('quickbooks_integration_id', '=', self.qi.id),
        ], limit=2)
        self.assertTrue(len(map_products) == 2)
        map_products.write({'product_id': product1.id})

        with self.assertRaises(ValidationError):
            product1.action_export_to_quickbooks()

        # 3. Assert raise due to unmapped accounts
        map_products.write({
            'qbo_name': 'Just erase names',
            'product_id': False,
        })
        with self.assertRaises(ValidationError):
            product1.action_export_to_quickbooks()

        # 4. Map only income account
        self.map_sales_income()
        with self.assertRaises(ValidationError):
            product1.action_export_to_quickbooks()

        # 5. Map income + expense accounts
        self.map_sales_income()
        self.map_cost_of_gods_sold()

        with self.patcher(PRODUCT):
            product1.action_export_to_quickbooks()

        mapping = product1._get_qbo_mapping(self.qi.id, PRODUCT)
        self.assertTrue(len(mapping) == 1)
        self.assertTrue(product1.is_qbo_sync_done)

    @patch(request_client)
    def test_export_customer_invoice(self, *args):
        self.map_all_accounts()

        map_product = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '2'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])

        map_product.create_instance_in_odoo()
        map_customer.create_instance_in_odoo()

        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': map_customer.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 10.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        })

        # Confirm invoice
        invoice.action_post()
        # Map-invoice before export
        mapping = invoice._get_qbo_mapping()
        self.assertFalse(mapping)
        self.assertFalse(invoice.is_qbo_sync_done)

        with self.patcher(INVOICE):
            invoice.action_export_to_quickbooks()

        # Map-invoice after export
        mapping = invoice._get_qbo_mapping()
        self.assertTrue(len(mapping) == 1)
        self.assertTrue(invoice.is_qbo_sync_done)

    @patch(request_client)
    def test_import_customer_invoice_apply_tax_after_discount(self, *args):
        """ApplyTaxAfterDiscount: QBO still has a discount row in map lines; Odoo gets one merged product line."""
        self.map_all_accounts()

        map_product = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '2'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_product.create_instance_in_odoo()
        map_customer.create_instance_in_odoo()

        # 1. Fetch QBO invoice and create mapping
        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(INVOICE):
            qbo_inv = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99001', INVOICE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_inv, self.qi.id, odoo_id=None,
            )

        self.assertEqual(mapping.qbo_id, '99001')
        self.assertEqual(mapping.qbo_name, 'INV-TAX-AFTER-DISC')
        self.assertTrue(mapping.extract_node('ApplyTaxAfterDiscount', False))
        self.assertAlmostEqual(mapping.total_amt, 103.5, places=2)
        self.assertAlmostEqual(mapping.total_tax, 13.5, places=2)

        qbo_payload = mapping.qbo_dict_body
        line_dicts = [ln for ln in qbo_payload['Line'] if ln.get('DetailType') != 'SubTotalLineDetail']
        self.assertEqual(len(line_dicts), 2)
        prod_raw = next(ln for ln in line_dicts if ln['DetailType'] == 'SalesItemLineDetail')
        disc_raw = next(ln for ln in line_dicts if ln['DetailType'] == 'DiscountLineDetail')
        self.assertAlmostEqual(prod_raw['Amount'], 100.0, places=2)
        self.assertAlmostEqual(
            float(ExtractNode.extract_raw(prod_raw, 'SalesItemLineDetail.UnitPrice', 0)), 100.0,
            places=2,
        )
        self.assertEqual(ExtractNode.extract_raw(prod_raw, 'SalesItemLineDetail.TaxCodeRef.value', ''), 'TAX')
        self.assertAlmostEqual(disc_raw['Amount'], 10.0, places=2)
        self.assertTrue(disc_raw.get('DiscountLineDetail'))

        self.assertAlmostEqual(qbo_payload['TxnTaxDetail']['TotalTax'], 13.5, places=2)
        tax_line = qbo_payload['TxnTaxDetail']['TaxLine'][0]
        self.assertAlmostEqual(
            float(ExtractNode.extract_raw(tax_line, 'TaxLineDetail.NetAmountTaxable', 0)),
            90.0,
            places=2,
        )

        qbo_product_amount = prod_raw['Amount']
        qbo_discount_amount = disc_raw['Amount']
        self.assertAlmostEqual(qbo_product_amount - qbo_discount_amount, 90.0, places=2)

        # invoice_map_line_ids are created in _recompute_map_lines during create_instance_in_odoo only.
        # 2. Create Odoo invoice from mapping
        invoice = mapping.create_instance_in_odoo()
        self.assertTrue(invoice)
        self.assertEqual(invoice.move_type, 'out_invoice')
        self.assertEqual(invoice.partner_id, map_customer.partner_id)
        self.assertEqual(invoice.quickbooks_integration, self.qi)
        self.assertEqual(invoice.currency_id.name, 'USD')

        map_lines = mapping.invoice_map_line_ids
        map_product_line = map_lines.filtered(lambda l: not l.is_discount_line and not l.is_delivery_line)
        map_discount_line = map_lines.filtered('is_discount_line')
        self.assertEqual(len(map_product_line), 1)
        self.assertEqual(len(map_discount_line), 1)
        self.assertAlmostEqual(map_product_line._get_amount(), qbo_product_amount, places=2)
        self.assertTrue(map_discount_line.is_discount_line)
        self.assertAlmostEqual(map_discount_line._get_amount(), qbo_discount_amount, places=2)

        line = self._invoice_product_lines(invoice)
        self.assertEqual(
            len(line),
            1,
            'ApplyTaxAfterDiscount: discount must not become a second Odoo product line.',
        )
        self.assertEqual(line.product_id, map_product.product_id)
        self.assertIn('Taxable line import test', line.name or '')
        self.assertAlmostEqual(line.quantity, 1.0, places=2)
        self.assertAlmostEqual(line.price_unit, 90.0, places=2)
        self.assertAlmostEqual(line.price_subtotal, 90.0, places=2)
        self.assertAlmostEqual(
            qbo_product_amount - qbo_discount_amount,
            line.price_subtotal,
            places=2,
            msg='Odoo untaxed subtotal must equal QBO product Amount minus discount Amount.',
        )

        discount_product = self.qi.get_discount_product()
        self.assertFalse(
            line.product_id == discount_product,
            'Discount must be embedded in the product line, not posted as the discount product.',
        )

        if invoice.amount_tax:
            self.assertAlmostEqual(invoice.amount_untaxed, 90.0, places=2)
            self.assertAlmostEqual(invoice.amount_total, 103.5, places=2)

    @patch(request_client)
    def test_import_customer_invoice_multi_line_discount_shipping_tax_after_discount(self, *args):
        """Several taxable lines, percent discount, shipping; ApplyTaxAfterDiscount updates taxable lines only."""
        self.map_all_accounts()

        for qbo_id in ('524', '528'):
            self.env['qbo.map.product'].search([
                ('qbo_id', '=', qbo_id),
                ('quickbooks_integration_id', '=', self.qi.id),
            ]).create_instance_in_odoo()

        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '230'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer.create_instance_in_odoo()

        # 1. Fetch QBO invoice and create mapping
        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(INVOICE):
            qbo_inv = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99002', INVOICE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_inv, self.qi.id, odoo_id=None,
            )

        self.assertEqual(mapping.qbo_id, '99002')
        self.assertEqual(mapping.qbo_name, 'INV/2026/00005.106')
        self.assertTrue(mapping.extract_node('ApplyTaxAfterDiscount', False))
        self.assertAlmostEqual(mapping.total_amt, 1007.03, places=2)
        self.assertAlmostEqual(mapping.total_tax, 124.83, places=2)

        qbo_payload = mapping.qbo_dict_body
        line_dicts = [
            ln for ln in qbo_payload['Line']
            if ln.get('DetailType') != 'SubTotalLineDetail'
        ]
        self.assertEqual(len(line_dicts), 4)
        sales_lines = [ln for ln in line_dicts if ln['DetailType'] == 'SalesItemLineDetail']
        disc_lines = [ln for ln in line_dicts if ln['DetailType'] == 'DiscountLineDetail']
        self.assertEqual(len(sales_lines), 3)
        self.assertEqual(len(disc_lines), 1)

        apple_raw = next(
            ln for ln in sales_lines
            if ExtractNode.extract_raw(ln, 'SalesItemLineDetail.ItemRef.value', '') == '524'
        )
        juice_raw = next(
            ln for ln in sales_lines
            if ExtractNode.extract_raw(ln, 'SalesItemLineDetail.ItemRef.value', '') == '528'
        )
        ship_raw = next(
            ln for ln in sales_lines
            if ExtractNode.extract_raw(ln, 'SalesItemLineDetail.ItemRef.value', '') == 'SHIPPING_ITEM_ID'
        )
        self.assertAlmostEqual(apple_raw['Amount'], 12.0, places=2)
        self.assertAlmostEqual(juice_raw['Amount'], 864.0, places=2)
        self.assertEqual(ExtractNode.extract_raw(apple_raw, 'SalesItemLineDetail.TaxCodeRef.value', ''), 'TAX')
        self.assertEqual(ExtractNode.extract_raw(juice_raw, 'SalesItemLineDetail.TaxCodeRef.value', ''), 'TAX')
        self.assertFalse(ExtractNode.extract_raw(ship_raw, 'SalesItemLineDetail.TaxCodeRef.value', False))
        self.assertAlmostEqual(ship_raw['Amount'], 50.0, places=2)

        disc_raw = disc_lines[0]
        self.assertAlmostEqual(disc_raw['Amount'], 43.8, places=2)

        taxable_qbo_sum = apple_raw['Amount'] + juice_raw['Amount']
        self.assertAlmostEqual(taxable_qbo_sum, 876.0, places=2)
        qbo_discount_amount = disc_raw['Amount']
        self.assertAlmostEqual(taxable_qbo_sum - qbo_discount_amount, 832.2, places=2)

        self.assertAlmostEqual(qbo_payload['TxnTaxDetail']['TotalTax'], 124.83, places=2)
        tax_line = qbo_payload['TxnTaxDetail']['TaxLine'][0]
        self.assertAlmostEqual(
            float(ExtractNode.extract_raw(tax_line, 'TaxLineDetail.NetAmountTaxable', 0)),
            832.2,
            places=2,
        )

        # 2. Create Odoo invoice from mapping
        invoice = mapping.with_context(
            default_account_id=self.env.ref('quickbooks_sync_online.a_sale').id,
        ).create_instance_in_odoo()
        self.assertEqual(invoice.move_type, 'out_invoice')
        self.assertEqual(invoice.partner_id, map_customer.partner_id)
        self.assertEqual(invoice.quickbooks_integration, self.qi)
        self.assertEqual(invoice.currency_id.name, 'USD')

        map_lines = mapping.invoice_map_line_ids
        map_products_only = map_lines.filtered(lambda l: not l.is_discount_line and not l.is_delivery_line)
        map_discount_line = map_lines.filtered('is_discount_line')
        map_ship_line = map_lines.filtered('is_delivery_line')
        self.assertEqual(len(map_products_only), 2)
        self.assertEqual(len(map_discount_line), 1)
        self.assertEqual(len(map_ship_line), 1)
        self.assertAlmostEqual(sum(m._get_amount() for m in map_products_only), taxable_qbo_sum, places=2)
        self.assertAlmostEqual(map_discount_line._get_amount(), qbo_discount_amount, places=2)
        self.assertAlmostEqual(map_ship_line._get_amount(), 50.0, places=2)

        product_lines = self._invoice_product_lines(invoice)
        self.assertEqual(len(product_lines), 3)

        map_apple = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '524'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_juice = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '528'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        ship_product = invoice.quickbooks_integration.get_shipping_product()
        chair_line = product_lines.filtered(lambda l: l.product_id == map_apple.product_id)
        juice_line = product_lines.filtered(lambda l: l.product_id == map_juice.product_id)
        ship_line = product_lines.filtered(lambda l: l.product_id == ship_product)
        chair_line.ensure_one()
        juice_line.ensure_one()
        ship_line.ensure_one()

        share_apple = qbo_discount_amount * (apple_raw['Amount'] / taxable_qbo_sum)
        share_juice = qbo_discount_amount * (juice_raw['Amount'] / taxable_qbo_sum)
        self.assertAlmostEqual(share_apple, 0.6, places=2)
        self.assertAlmostEqual(share_juice, 43.2, places=2)
        self.assertAlmostEqual(chair_line.price_subtotal, apple_raw['Amount'] - share_apple, places=2)
        self.assertAlmostEqual(juice_line.price_subtotal, juice_raw['Amount'] - share_juice, places=2)
        self.assertAlmostEqual(ship_line.price_subtotal, ship_raw['Amount'], places=2)

        self.assertAlmostEqual(chair_line.price_unit, 11.4, places=2)
        self.assertAlmostEqual(juice_line.quantity, 2.0, places=2)
        self.assertAlmostEqual(juice_line.price_unit, 410.4, places=2)
        self.assertAlmostEqual(ship_line.price_unit, 50.0, places=2)

        total_untaxed_lines = sum(product_lines.mapped('price_subtotal'))
        self.assertAlmostEqual(total_untaxed_lines, 882.2, places=2)

        discount_product = self.qi.get_discount_product()
        self.assertFalse(
            any(l.product_id == discount_product for l in product_lines),
            'Discount must not appear as a separate Odoo product line (only embedded in taxable lines).',
        )

        if invoice.amount_tax:
            self.assertAlmostEqual(invoice.amount_untaxed, 882.2, places=2)
            self.assertAlmostEqual(invoice.amount_total, 1007.03, places=2)

    @patch(request_client)
    def test_constraints_export_customer_invoice(self, *args):
        customer = self.env['res.partner'].create({
            'name': 'Test Invoice Customer',
        })
        product = self.env['product.product'].create({
            'name': 'Test Invoice Product',
        })
        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
        })
        self.assertFalse(invoice.is_qbo_sync_done)

        # 2.
        try:
            invoice.action_export_to_quickbooks()
        except ValidationError as ex:
            self.assertIn('You need to assign partner', ex.args[0])

        # 3.
        invoice.write({
            'partner_id': customer.id,
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 10.0,
                'quantity': 1,
                'product_id': product.id,
                'account_id': self.env.ref('quickbooks_sync_online.a_expense').id,
            })],
        })

        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ], limit=1)
        self.assertTrue(map_customer)
        map_customer.write({'partner_id': customer.id})

        map_product = self.env['qbo.map.product'].search([
            ('qbo_lib_type', '=', PRODUCT),
            ('quickbooks_integration_id', '=', self.qi.id),
        ], limit=1)
        self.assertTrue(map_product)
        map_product.write({'product_id': product.id})

        # 4.
        try:
            invoice.action_export_to_quickbooks()
        except ValidationError as ex:
            self.assertIn('Confirm invoice', ex.args[0])

        invoice.action_post()

        # 5.
        with self.patcher(INVOICE):
            invoice.action_export_to_quickbooks()
        self.assertTrue(invoice.is_qbo_sync_done)

        # Map-invoice after export
        mapping = invoice._get_qbo_mapping()
        self.assertTrue(len(mapping) == 1)
        self.assertTrue(invoice.is_qbo_sync_done)

    @patch(request_client)
    def test_export_vendor_bill(self, *args):
        self.map_all_accounts()

        map_product = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '67'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_vendor = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '31'),
            ('qbo_lib_type', '=', VENDOR),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])

        map_product.create_instance_in_odoo()
        map_vendor.create_instance_in_odoo()

        bill = self.env['account.move'].create({
            'move_type': 'in_invoice',
            'invoice_date': date.today(),
            'partner_id': map_vendor.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.expenses_journal').id,
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 10.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        })

        # Confirm invoice
        bill.action_post()
        # Map-invoice before export
        mapping = bill._get_qbo_mapping()
        self.assertFalse(mapping)
        self.assertFalse(bill.is_qbo_sync_done)

        with self.patcher(BILL):
            bill.action_export_to_quickbooks()

        # Map-invoice after export
        mapping = bill._get_qbo_mapping()
        self.assertTrue(len(mapping) == 1)
        self.assertTrue(bill.is_qbo_sync_done)

    @patch(request_client)
    def test_constraints_export_vendor_bill(self, *args):
        vendor = self.env['res.partner'].create({
            'name': 'Test Bill Vendor',
        })
        product = self.env['product.product'].create({
            'name': 'Test Bill Product',
        })
        bill = self.env['account.move'].create({
            'move_type': 'in_invoice',
            'invoice_date': date.today(),
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.expenses_journal').id,
        })
        self.assertFalse(bill.is_qbo_sync_done)

        # 2.
        try:
            bill.action_export_to_quickbooks()
        except ValidationError as ex:
            self.assertIn('You need to assign partner', ex.args[0])

        # 3.
        map_vendor = self.env['qbo.map.partner'].search([
            ('qbo_lib_type', '=', VENDOR),
            ('quickbooks_integration_id', '=', self.qi.id),
        ], limit=1)
        self.assertTrue(map_vendor)
        map_vendor.write({'partner_id': vendor.id})

        bill.write({'partner_id': vendor.id})

        # 4.
        try:
            bill.action_export_to_quickbooks()
        except ValidationError as ex:
            self.assertIn('You need to add lines', ex.args[0])

        # 5.
        map_product = self.env['qbo.map.product'].search([
            ('qbo_lib_type', '=', PRODUCT),
            ('quickbooks_integration_id', '=', self.qi.id),
        ], limit=1)
        self.assertTrue(map_product)
        map_product.write({'product_id': product.id})

        bill.write({
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 10.0,
                'quantity': 1,
                'product_id': product.id,
                'account_id': self.env.ref('quickbooks_sync_online.a_expense').id,
            })],
        })

        # 6.
        try:
            bill.action_export_to_quickbooks()
        except ValidationError as ex:
            self.assertIn('Confirm invoice', ex.args[0])

        bill.action_post()

        # 7.
        try:
            bill.action_export_to_quickbooks()
        except ValidationError as ex:
            self.assertIn('Accounts Payable', ex.args[0])

        self.map_account_payable()

        # 8.
        with self.patcher(BILL):
            bill.action_export_to_quickbooks()

        # Map-invoice after export
        mapping = bill._get_qbo_mapping()
        self.assertTrue(len(mapping) == 1)
        self.assertTrue(bill.is_qbo_sync_done)

    @patch(request_client)
    def test_pay_customer_invoice(self, *args):
        self.map_all_accounts()

        map_product = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '2'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])

        map_product.create_instance_in_odoo()
        map_customer.create_instance_in_odoo()

        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': map_customer.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 1000.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        })

        invoice.action_post()

        with self.patcher(INVOICE):
            invoice.action_export_to_quickbooks()

        map_invoice = invoice._get_qbo_mapping()
        self.assertTrue(len(map_invoice) == 1)

        payments = self.env['qbo.map.payment'].search([
            ('txn_id', '=', map_invoice.id),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        self.assertFalse(payments)

        # 2. Make a partially payment amount by cash ('1')
        pay_id = self.patcher.make_intuit_payment(map_invoice.qbo_id, 'Invoice', 900.0, '1')

        def _get_outstanding_account_patch(payment, *args, **kw):
            return payment.env.ref('quickbooks_sync_online.o_payments')

        self.patch(type(self.env['account.payment']), '_get_outstanding_account', _get_outstanding_account_patch)

        with self.patcher(PAYMENT):
            payment = self.env['qbo.map.payment'].fetch_qbo_one_by_pk(self.qi.id, pay_id, 'Payment')

            pay = self.env['qbo.map.payment'] \
                .with_context(
                    default_txn_id=map_invoice.id,
                    default_txn_amount='900.0',
                ).get_or_create_qbo_mapping_from_response(payment, self.qi.id, odoo_id=None)

        self.assertTrue(len(pay) == 1)
        self.assertEqual(pay.pay_method, '1')
        self.assertEqual(pay.payment_id.id, False)
        self.assertEqual(pay.txn_type, 'invoice')
        self.assertEqual(pay.currency_ref, 'USD')
        self.assertEqual(pay.txn_amount, '900.0')
        self.assertEqual(pay.invoice_id, invoice)
        self.assertEqual(pay.txn_date, datetime.today().strftime('%Y-%m-%d'))

        pay._try_to_map_payment()
        self.assertFalse(pay.payment_id)

        # 3. Register payment
        try:
            pay.register_payment_in_odoo(reconcile=False)
        except ValidationError as ex:
            self.assertIn('Unable to register payment in Odoo', ex.args[0])

        self.map_payment_defaults()
        pay.register_payment_in_odoo(reconcile=False)

        payment = pay.payment_id
        payment.ensure_one()

        self.assertEqual(payment.memo, invoice.name)
        self.assertEqual(int(payment.amount), 900)
        self.assertTrue(payment.state in ['paid', 'reconciled'])
        self.assertTrue(invoice.payment_state in ['partial', 'in_payment'])

    @patch(request_client)
    def test_pay_creditnote(self, *args):
        self.qi.write({
            'allow_out_invoice_export': True,
        })

        self.map_all_accounts()

        map_product = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '2'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])

        map_product.create_instance_in_odoo()
        map_customer.create_instance_in_odoo()

        credit_note = self.env['account.move'].create({
            'move_type': 'out_refund',
            'partner_id': map_customer.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 1000.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        })

        credit_note.action_post()

        with self.patcher(CREDIT_NOTE):
            credit_note.action_export_to_quickbooks()

        mapping = credit_note._get_qbo_mapping()
        self.assertTrue(len(mapping) == 1)

        def _get_outstanding_account_patch(payment, *args, **kw):
            return payment.env.ref('quickbooks_sync_online.o_payments')

        self.patch(type(self.env['account.payment']), '_get_outstanding_account', _get_outstanding_account_patch)

        wizard = self.env['account.payment.register'] \
            .with_context(
                active_model=credit_note._name,
                active_ids=credit_note.ids,
            ).create({
                'journal_id': self.env.ref('quickbooks_sync_online.bank_journal').id,
            })

        payment = wizard._create_payments()
        payment.ensure_one()

        self.assertEqual(int(payment.amount), 1000)
        self.assertTrue(payment.state in ['paid', 'reconciled'])

        self.assertFalse(payment.is_qbo_export_allowed)

    @patch(request_client)
    def test_pay_customer_invoice_in_odoo(self, *args):
        self.map_all_accounts()
        self.map_payment_defaults()

        map_product = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '2'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])

        map_product.create_instance_in_odoo()
        map_customer.create_instance_in_odoo()

        # A.
        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': map_customer.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 1000.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        })

        invoice.action_post()

        with self.patcher(INVOICE):
            invoice.action_export_to_quickbooks()

        map_invoice = invoice.qbo_mapping_ids
        self.assertTrue(len(map_invoice) == 1)

        ctx = {
            'active_model': 'account.move',
            'active_ids': invoice.ids,
        }
        ac_pay_reg1 = self.env['account.payment.register'].with_context(**ctx).create({
            'amount': 400.0,
            'journal_id': self.env.ref('quickbooks_sync_online.bank_journal').id,
            'partner_type': 'customer',
            'payment_date': date.today(),
            'payment_method_line_id':
                self.env.ref('quickbooks_sync_online.line_check_in').id,
            'currency_id': invoice.currency_id.id,
            'payment_type': 'inbound',
        })
        payment_1 = ac_pay_reg1._create_payments()

        ac_pay_reg2 = self.env['account.payment.register'].with_context(**ctx).create({
            'amount': invoice.amount_total - 400.0,
            'journal_id': self.env.ref('quickbooks_sync_online.bank_journal').id,
            'partner_type': 'customer',
            'payment_date': date.today(),
            'payment_method_line_id':
                self.env.ref('quickbooks_sync_online.line_check_in').id,
            'currency_id': invoice.currency_id.id,
            'payment_type': 'inbound',
        })
        payment_2 = ac_pay_reg2._create_payments()

        payments = payment_1 + payment_2

        self.assertTrue(len(payment_1.qbo_mapping_ids) == 0)
        self.assertTrue(len(payment_2.qbo_mapping_ids) == 0)

        # Map `payment.joutnal_id` to any `qbo.map.payment.method` before export.
        map_pay_met = self.env['qbo.map.payment.method'].search([
            ('quickbooks_integration_id', '=', self.qi.id),
        ], limit=1)
        journal = payments.mapped('journal_id')

        self.assertTrue(len(journal) == 1)

        map_pay_met.journal_id = journal.id

        with self.patcher(PAYMENT):
            payments.with_context(qbo_invoice_export_allowed=True).action_export_to_quickbooks()

        self.assertTrue(len(payment_1.qbo_mapping_ids) == 1)
        self.assertTrue(payment_1.is_qbo_sync_done)
        self.assertTrue(payment_1.is_excluded_from_qbo_sync)

        self.assertTrue(len(payment_2.qbo_mapping_ids) == 1)
        self.assertTrue(payment_2.is_qbo_sync_done)
        self.assertTrue(payment_2.is_excluded_from_qbo_sync)

        self.assertTrue(map_invoice.payment_state in ['paid', 'in_payment'])
        self.assertTrue(len(map_invoice.payment_ids) == 2)

    @patch(request_client)
    def test_export_payment_multi_invoice(self, *args):
        """A single Odoo payment reconciled against several invoices must be exported as
        ONE QBO Payment with one Line per invoice (not one separate payment per invoice).
        """
        self.map_all_accounts()
        self.map_payment_defaults()

        map_product = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '2'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])

        map_product.create_instance_in_odoo()
        map_customer.create_instance_in_odoo()

        product = map_product.product_id
        partner = map_customer.partner_id

        # The bare test company has no chart of accounts installed, so wire the minimal
        # accounts required to post a customer invoice explicitly.
        product.product_tmpl_id.property_account_income_id = \
            self.env.ref('quickbooks_sync_online.a_sale')
        partner.property_account_receivable_id = \
            self.env.ref('quickbooks_sync_online.a_recv')

        def _make_invoice(price):
            invoice = self.env['account.move'].create({
                'move_type': 'out_invoice',
                'partner_id': partner.id,
                'invoice_user_id': self.user.id,
                'company_id': self.company.id,
                'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
                'invoice_line_ids': [(0, 0, {
                    'name': 'Test line',
                    'price_unit': price,
                    'quantity': 1,
                    'product_id': product.id,
                })],
            })
            invoice.action_post()
            return invoice

        invoice_1 = _make_invoice(100.0)
        invoice_2 = _make_invoice(200.0)
        invoices = invoice_1 + invoice_2

        with self.patcher(INVOICE):
            invoices.action_export_to_quickbooks()

        self.assertEqual(len(invoice_1._get_qbo_mapping()), 1)
        self.assertEqual(len(invoice_2._get_qbo_mapping()), 1)

        # Register a SINGLE grouped payment that reconciles both invoices.
        ctx = {
            'active_model': 'account.move',
            'active_ids': invoices.ids,
        }
        register = self.env['account.payment.register'].with_context(**ctx).create({
            'journal_id': self.env.ref('quickbooks_sync_online.bank_journal').id,
            'payment_date': date.today(),
            'group_payment': True,
            'payment_method_line_id': self.env.ref('quickbooks_sync_online.line_check_in').id,
        })
        payment = register._create_payments()
        payment.ensure_one()

        # Sanity: one payment reconciled against both invoices.
        self.assertEqual(len(payment.qbo_reconciled_ids), 2)
        self.assertEqual(payment.amount, 300.0)

        # Make the payment's journal resolvable to a QBO payment method.
        map_pay_met = self.env['qbo.map.payment.method'].search([
            ('quickbooks_integration_id', '=', self.qi.id),
        ], limit=1)
        map_pay_met.journal_id = payment.journal_id.id

        # The prepared QBO payload is a single Payment with one Line per invoice.
        chunks = payment.qbo_reconciled_ids._get_amount_chunks_for_qbo_payments(payment.id, payment.amount)
        qbo_lib_model = payment._prepare_qbo_api_lib_instance(self.qi.id, chunks)

        self.assertEqual(len(qbo_lib_model.Line), 2)
        self.assertEqual(qbo_lib_model.TotalAmt, 300.0)
        linked_ids = {line['LinkedTxn'][0]['TxnId'] for line in qbo_lib_model.Line}
        self.assertEqual(
            linked_ids,
            {invoice_1._get_qbo_mapping().qbo_id, invoice_2._get_qbo_mapping().qbo_id},
        )

        # Exporting the payment creates exactly ONE QBO payment mapping for the payment.
        with self.patcher(PAYMENT):
            payment.with_context(qbo_invoice_export_allowed=True) \
                .action_export_to_quickbooks()

        self.assertEqual(len(payment.qbo_mapping_ids), 2)
        self.assertTrue(payment.is_qbo_sync_done)
        self.assertTrue(payment.is_excluded_from_qbo_sync)

    @patch(request_client)
    def test_export_payment_by_payment_method_mapping(self, *args):
        """Export uses Odoo Payment Method mapping when configured, without journal mapping."""
        self.map_all_accounts()

        map_product = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '2'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])

        map_product.create_instance_in_odoo()
        map_customer.create_instance_in_odoo()

        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': map_customer.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 1000.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        })
        invoice.action_post()

        with self.patcher(INVOICE):
            invoice.action_export_to_quickbooks()

        ctx = {
            'active_model': 'account.move',
            'active_ids': invoice.ids,
        }
        register = self.env['account.payment.register'].with_context(**ctx).create({
            'amount': invoice.amount_total,
            'journal_id': self.env.ref('quickbooks_sync_online.bank_journal').id,
            'partner_type': 'customer',
            'payment_date': date.today(),
            'payment_method_line_id':
                self.env.ref('quickbooks_sync_online.line_check_in').id,
            'currency_id': invoice.currency_id.id,
            'payment_type': 'inbound',
        })
        payment = register._create_payments()

        map_pay_met = self.env['qbo.map.payment.method'].search([
            ('quickbooks_integration_id', '=', self.qi.id),
        ], limit=1)
        map_pay_met.write({
            'payment_method_line_id': self.env.ref('quickbooks_sync_online.line_check_in').id,
            'journal_id': False,
        })

        chunks = payment.qbo_reconciled_ids._get_amount_chunks_for_qbo_payments(payment.id, payment.amount)
        qbo_lib_model = payment._prepare_qbo_api_lib_instance(self.qi.id, chunks)
        self.assertEqual(qbo_lib_model.PaymentMethodRef['value'], map_pay_met.qbo_id)

        with self.patcher(PAYMENT):
            payment.with_context(qbo_invoice_export_allowed=True).action_export_to_quickbooks()

        self.assertEqual(len(payment.qbo_mapping_ids), 1)
        self.assertTrue(payment.is_qbo_sync_done)

    @patch(request_client)
    def test_import_payment_by_payment_method_mapping(self, *args):
        """Import assigns Odoo Payment Method from mapping, falling back to journal only when unset."""
        self.map_all_accounts()

        map_product = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '2'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])

        map_product.create_instance_in_odoo()
        map_customer.create_instance_in_odoo()

        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': map_customer.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 1000.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        })
        invoice.action_post()

        with self.patcher(INVOICE):
            invoice.action_export_to_quickbooks()

        map_invoice = invoice._get_qbo_mapping()
        pay_id = self.patcher.make_intuit_payment(map_invoice.qbo_id, 'Invoice', 500.0, '1')

        def _get_outstanding_account_patch(payment, *args, **kw):
            return payment.env.ref('quickbooks_sync_online.o_payments')

        self.patch(type(self.env['account.payment']), '_get_outstanding_account', _get_outstanding_account_patch)

        with self.patcher(PAYMENT):
            payment = self.env['qbo.map.payment'].fetch_qbo_one_by_pk(self.qi.id, pay_id, 'Payment')
            pay = self.env['qbo.map.payment'] \
                .with_context(
                    default_txn_id=map_invoice.id,
                    default_txn_amount='500.0',
                ).get_or_create_qbo_mapping_from_response(payment, self.qi.id, odoo_id=None)

        self.qi.write({
            'qi_default_journal_id': self.env.ref('quickbooks_sync_online.bank_journal').id,
        })
        cash_method = self.env['qbo.map.payment.method'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        cash_method.write({
            'payment_method_line_id': self.env.ref('quickbooks_sync_online.line_check_in').id,
            'journal_id': False,
        })

        pay.register_payment_in_odoo(reconcile=False)

        odoo_payment = pay.payment_id
        odoo_payment.ensure_one()
        self.assertEqual(
            odoo_payment.payment_method_id,
            self.env.ref('quickbooks_sync_online.method_manual_in'),
        )
        self.assertEqual(
            odoo_payment.journal_id,
            self.env.ref('quickbooks_sync_online.bank_journal'),
        )

    @patch(request_client)
    def test_pay_customer_credit_in_odoo(self, *args):
        self.map_all_accounts()
        self.map_payment_defaults()

        map_product = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '2'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])

        map_product.create_instance_in_odoo()
        map_customer.create_instance_in_odoo()

        credit_note = self.env['account.move'].create({
            'move_type': 'out_refund',
            'partner_id': map_customer.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 1000.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        })
        credit_note.action_post()

        with self.patcher(CREDIT_NOTE):
            credit_note.action_export_to_quickbooks()

        map_credit_note = credit_note._get_qbo_mapping()
        self.assertTrue(len(map_credit_note) == 1)

        ctx = {
            'active_model': 'account.move',
            'active_ids': credit_note.ids,
        }
        ac_pay_reg1 = self.env['account.payment.register'].with_context(**ctx).create({
            'amount': 400.0,
            'journal_id': self.env.ref('quickbooks_sync_online.bank_journal').id,
            'partner_type': 'customer',
            'payment_date': date.today(),
            'payment_method_line_id':
                self.env.ref('quickbooks_sync_online.line_check_in').id,
            'currency_id': credit_note.currency_id.id,
            'payment_type': 'inbound',
        })
        payment_1 = ac_pay_reg1._create_payments()

        ac_pay_reg2 = self.env['account.payment.register'].with_context(**ctx).create({
            'amount': credit_note.amount_total - 400.0,
            'journal_id': self.env.ref('quickbooks_sync_online.bank_journal').id,
            'partner_type': 'customer',
            'payment_date': date.today(),
            'payment_method_line_id':
                self.env.ref('quickbooks_sync_online.line_check_in').id,
            'currency_id': credit_note.currency_id.id,
            'payment_type': 'inbound',
        })
        payment_2 = ac_pay_reg2._create_payments()

        payments = payment_1 + payment_2
        company_payment_ids = self.qi._search_to_qbo_payments()

        for p in payments:
            self.assertTrue(p.id not in company_payment_ids.ids)

    @patch(request_client)
    def test_requires_update_partner_to_qbo(self, *args):
        # A. Create and export new partner
        ctx = {
            'with_qbo_partner_type': VENDOR,
        }

        country_id = self.env.ref('base.us', False) and self.env.ref('base.us').id
        state_id = self.env.ref('base.state_us_1', False) and self.env.ref('base.state_us_1').id

        parent_partner = self.env['res.partner'].create({
            'name': 'John Wayne Vendor Parent',
        })
        partner = self.env['res.partner'].create({
            'name': 'John Wayne Vendor',
            'parent_id': parent_partner.id,
            'email': 'mail@mail.info',
            'phone': '8029-555555',
            'country_id': country_id,
            'city': 'Minsk',
            'state_id': state_id,
            'street': 'Lenina',
            'street2': 'Stalina',
            'zip': '666',
        })

        self.assertFalse(partner.is_qbo_update_required)
        partner.write({'name': 'John Wayne Vendor-2'})
        self.assertFalse(partner.is_qbo_update_required)

        # Perform export
        with self.patcher(VENDOR):
            partner.with_context(**ctx).action_export_to_quickbooks()

        # Map-partner exist
        map_partner = partner.qbo_mapping_ids.filtered(
            lambda r: r.quickbooks_integration_id == self.qi
        )
        self.assertTrue(len(map_partner) == 1)
        self.assertTrue(map_partner.qbo_lib_type == VENDOR)
        self.assertTrue(partner.is_qbo_sync_done)

        # B. Change 'track-fields' in partner after export

        self.assertFalse(partner.is_qbo_update_required)
        partner.with_context(no_mark_quickbooks_update=True).write({
            'name': 'John Wayne Vendor-3',
        })
        self.assertFalse(partner.is_qbo_update_required)

        # 1. name
        self.assertFalse(partner.is_qbo_update_required)
        partner.write({'name': 'John Wayne Vendor-4'})
        self.assertTrue(partner.is_qbo_update_required)
        partner.write({'is_qbo_update_required': False})

        # 2. parent_id
        self.assertFalse(partner.is_qbo_update_required)
        partner.write({'parent_id': False})
        self.assertTrue(partner.is_qbo_update_required)
        partner.write({'is_qbo_update_required': False})

        # 3. phone
        self.assertFalse(partner.is_qbo_update_required)
        partner.write({'phone': '8044-555555'})
        self.assertTrue(partner.is_qbo_update_required)
        partner.write({'is_qbo_update_required': False})

        # 5. state_id
        self.assertFalse(partner.is_qbo_update_required)
        partner.write({'state_id': False})
        self.assertTrue(partner.is_qbo_update_required)
        partner.write({'is_qbo_update_required': False})

        # 6. country_id
        self.assertFalse(partner.is_qbo_update_required)
        partner.write({'country_id': False})
        self.assertTrue(partner.is_qbo_update_required)
        partner.write({'is_qbo_update_required': False})

        # 7. city
        self.assertFalse(partner.is_qbo_update_required)
        partner.write({'city': 'Kiev'})
        self.assertTrue(partner.is_qbo_update_required)
        partner.write({'is_qbo_update_required': False})

        # 8. street
        self.assertFalse(partner.is_qbo_update_required)
        partner.write({'street': 'Peremen'})
        self.assertTrue(partner.is_qbo_update_required)
        partner.write({'is_qbo_update_required': False})

        # 9. street2
        self.assertFalse(partner.is_qbo_update_required)
        partner.write({'street2': 'Pr. Peremen'})
        self.assertTrue(partner.is_qbo_update_required)
        partner.write({'is_qbo_update_required': False})

        # 10. zip
        self.assertFalse(partner.is_qbo_update_required)
        partner.write({'zip': '999'})
        self.assertTrue(partner.is_qbo_update_required)
        partner.write({'is_qbo_update_required': False})

        # 11. email
        self.assertFalse(partner.is_qbo_update_required)
        partner.write({'email': 'mail@mail.com'})
        self.assertTrue(partner.is_qbo_update_required)

        records_to_update = self.env['res.partner'].search([('is_qbo_update_required', '=', True)])
        self.assertIn(partner.id, records_to_update.ids)

        # Perform update
        with self.patcher(VENDOR):
            partner.with_context(**ctx).action_export_to_quickbooks()

        self.assertFalse(partner.is_qbo_update_required)

        # 11. change non-track field --> website
        partner.write({'website': 'https://portal.pl'})
        self.assertFalse(partner.is_qbo_update_required)

        records_to_update = self.env['res.partner'].search([('is_qbo_update_required', '=', True)])
        self.assertNotIn(partner.id, records_to_update.ids)

    @patch(request_client)
    def test_get_taxes_from_qbo_taxable_customer(self, *args):
        self.map_all_accounts()
        tax = self.create_tax()

        MAP_PARTNER = self.env['qbo.map.partner']

        def refresh_qbo_mapping_body(*args, **kw):
            return

        # Patch 'refresh_qbo_mapping_body()' method for 'qbo.map.partner'
        self.patch(type(MAP_PARTNER), 'refresh_qbo_mapping_body', refresh_qbo_mapping_body)

        map_product_1 = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '4'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_product_2 = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '3'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])

        product_1 = map_product_1.create_instance_in_odoo()
        product_2 = map_product_2.create_instance_in_odoo()
        customer = map_customer.create_instance_in_odoo()

        product_1.write({
            'taxes_id': [(6, 0, tax.ids)],
        })

        sale_order = self.env['sale.order'].create({
            'partner_id': customer.id,
            'company_id': self.company.id,
            'order_line': [
                (0, 0, {
                    'name': map_product_1.qbo_name,
                    'product_id': product_1.id,
                    'product_uom_qty': 2,
                    'product_uom_id': self.env.ref('uom.product_uom_unit').id,
                    'price_unit': 42,
                }),
                (0, 0, {
                    'name': map_product_2.qbo_name,
                    'product_id': product_2.id,
                    'product_uom_qty': 1,
                    'product_uom_id': self.env.ref('uom.product_uom_unit').id,
                    'price_unit': 58,
                }),
            ],
        })

        taxes_before = self.env['account.tax'].search([
            ('company_id', '=', self.company.id)
        ])
        self.assertTrue(len(taxes_before) == 1)

        with self.patcher(SALE_ORDER):
            sale_order.get_qbo_taxes_from_salereceipt()

        taxes_after = self.env['account.tax'].search([
            ('company_id', '=', self.company.id)
        ])
        self.assertTrue(len(taxes_after) == 5)

        self.assertTrue(sale_order.is_qbo_sync_done)

        salereceipt = sale_order._get_map_instance_or_raise(self.qi.id, SALE_ORDER)

        self.assertTrue(str(salereceipt.total_tax), '7.77')
        self.assertTrue(len(salereceipt.qbo_tax_ids) == 4)

        line_1 = sale_order.order_line.filtered(lambda r: r.product_id == product_1)
        line_2 = sale_order.order_line.filtered(lambda r: r.product_id == product_2)
        self.assertEqual(
            sorted(line_1.tax_ids.ids),
            sorted(salereceipt.qbo_tax_ids.mapped('tax_id.id')),
        )
        self.assertEqual(
            sorted(line_2.tax_ids.ids),
            [],  # Because of TaxCodeRef --> NON in received json
        )
        self.assertAlmostEqual(sale_order.amount_total, 149.77, 2)

    @patch(request_client)
    def test_get_taxes_from_qbo_non_taxable_customer(self, *args):
        self.map_all_accounts()
        tax = self.create_tax()

        MAP_PARTNER = self.env['qbo.map.partner']

        def refresh_qbo_mapping_body(*args, **kw):
            return

        # Patch 'refresh_qbo_mapping_body()' method for 'qbo.map.partner'
        self.patch(type(MAP_PARTNER), 'refresh_qbo_mapping_body', refresh_qbo_mapping_body)

        map_product_1 = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '4'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_product_2 = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '4'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])

        product_1 = map_product_1.create_instance_in_odoo()
        product_2 = map_product_2.create_instance_in_odoo()
        customer = map_customer.create_instance_in_odoo()

        sale_order = self.env['sale.order'].create({
            'partner_id': customer.id,
            'company_id': self.company.id,
            'order_line': [
                (0, 0, {
                    'name': map_product_1.qbo_name,
                    'product_id': product_1.id,
                    'product_uom_qty': 2,
                    'product_uom_id': self.env.ref('uom.product_uom_unit').id,
                    'price_unit': 42,
                    'tax_ids': [(6, 0, tax.ids)],
                }),
                (0, 0, {
                    'name': map_product_2.qbo_name,
                    'product_id': product_2.id,
                    'product_uom_qty': 1,
                    'product_uom_id': self.env.ref('uom.product_uom_unit').id,
                    'price_unit': 58,
                    'tax_ids': False,
                }),
            ],
        })

        taxes_before = self.env['account.tax'].search([
            ('company_id', '=', self.company.id)
        ])
        self.assertTrue(len(taxes_before) == 1)

        with self.patcher(SALE_ORDER):
            sale_order.get_qbo_taxes_from_salereceipt()

        taxes_after = self.env['account.tax'].search([
            ('company_id', '=', self.company.id)
        ])
        self.assertTrue(len(taxes_after) == 1)
        self.assertFalse(sale_order.is_qbo_sync_done)

        with self.assertRaises(ValidationError):
            # No mapping due to `non-taxable customer`
            sale_order._get_map_instance_or_raise(self.qi.id, SALE_ORDER)

        line_1 = sale_order.order_line.filtered(lambda r: r.product_id == product_1)
        line_2 = sale_order.order_line.filtered(lambda r: r.product_id == product_2)

        self.assertFalse(bool(line_1.tax_ids))
        self.assertFalse(bool(line_2.tax_ids))

        self.assertEqual(str(sale_order.amount_total), '142.0')

    @patch(request_client)
    def test_constraints_get_taxes_from_qbo(self, *args):
        self.map_all_accounts()
        tax = self.create_tax()

        MAP_PARTNER = self.env['qbo.map.partner']

        def refresh_qbo_mapping_body(*args, **kw):
            return

        # Patch 'refresh_qbo_mapping_body()' method for 'qbo.map.partner'
        self.patch(type(MAP_PARTNER), 'refresh_qbo_mapping_body', refresh_qbo_mapping_body)

        map_product = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '4'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer = MAP_PARTNER.search([
            ('qbo_id', '=', '3'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])

        product = map_product.create_instance_in_odoo()
        customer = map_customer.create_instance_in_odoo()

        # 1. SaleOrder not in 'draft' state
        sale_order_1 = self.env['sale.order'].create({
            'partner_id': customer.id,
            'company_id': self.company.id,
            'order_line': [(0, 0, {
                'name': map_product.qbo_name,
                'product_id': product.id,
                'product_uom_qty': 1,
                'product_uom_id': self.env.ref('uom.product_uom_unit').id,
                'price_unit': 50,
                'tax_ids': [(6, 0, tax.ids)],
            })],
        })
        sale_order_1.action_confirm()

        with self.assertRaises(UserError):
            sale_order_1.get_qbo_taxes_from_salereceipt()

        # 2. No products
        map_customer.write({'partner_id': customer.id})
        map_product.write({'product_id': product.id})
        sale_order_4 = self.env['sale.order'].create({
            'partner_id': customer.id,
            'company_id': self.company.id,
        })

        with self.assertRaises(UserError):
            sale_order_4.get_qbo_taxes_from_salereceipt()

        # 3. Happy-path case
        sale_order_5 = self.env['sale.order'].create({
            'partner_id': customer.id,
            'company_id': self.company.id,
            'order_line': [(0, 0, {
                'name': map_product.qbo_name,
                'product_id': product.id,
                'product_uom_qty': 1,
                'product_uom_id': self.env.ref('uom.product_uom_unit').id,
                'price_unit': 50,
                'tax_ids': [(6, 0, tax.ids)],
            })],
        })

        sale_order_5._check_qbo_requirements()

        with self.patcher(SALE_ORDER):
            sale_order_5.get_qbo_taxes_from_salereceipt()

        self.assertTrue(sale_order_5.is_qbo_sync_done)

    def test_get_products_to_qbo_export_method(self):
        partner = self.env['res.partner'].create({
            'name': 'Test Invoice Partner',
        })
        product1 = self.env['product.product'].create({
            'name': 'Test Invoice Product1',
        })
        product2 = self.env['product.product'].create({
            'name': 'Test Invoice Product2',
        })
        product3 = self.env['product.product'].create({
            'name': 'Test Invoice Product3',
        })
        product4 = self.env['product.product'].create({
            'name': 'Test Invoice Product4',
        })
        invoice1 = self.env['account.move'].create({
            'partner_id': partner.id,
            'move_type': 'out_invoice',
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'invoice_line_ids': [
                (0, 0, {
                    'name': 'Test line',
                    'price_unit': 10.0,
                    'quantity': 1,
                    'product_id': product1.id,
                    'account_id': self.env.ref('quickbooks_sync_online.a_expense').id,
                }),
            ],
        })
        invoice2 = self.env['account.move'].create({
            'partner_id': partner.id,
            'move_type': 'out_invoice',
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'invoice_line_ids': [
                (0, 0, {
                    'name': 'Test line',
                    'price_unit': 10.0,
                    'quantity': 1,
                    'product_id': product2.id,
                    'account_id': self.env.ref('quickbooks_sync_online.a_expense').id,
                }),
            ],
        })

        bill = self.env['account.move'].create({
            'move_type': 'in_invoice',
            'invoice_date': date.today(),
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.expenses_journal').id,
            'invoice_line_ids': [
                (0, 0, {
                    'name': 'Test line1',
                    'price_unit': 10.0,
                    'quantity': 1,
                    'product_id': product3.id,
                    'account_id': self.env.ref('quickbooks_sync_online.a_expense').id,
                }),
                (0, 0, {
                    'name': 'Test line2',
                    'price_unit': 10.0,
                    'quantity': 1,
                    'product_id': product4.id,
                    'account_id': self.env.ref('quickbooks_sync_online.a_expense').id,
                }),
            ],
        })

        all_invoices = invoice1 + invoice2 + bill

        # 1.
        self.qi.write({
            'include_product_to_invoice': True,
            'sync_product_as_category': False,
        })

        products = self.env['product.product']
        for invoice in all_invoices:
            products |= invoice._get_products_to_qbo_export()

        self.assertIn(product1.id, products.ids)
        self.assertIn(product2.id, products.ids)
        self.assertIn(product3.id, products.ids)
        self.assertIn(product4.id, products.ids)

        # 2.
        self.qi.write({
            'include_product_to_invoice': False,
            'sync_product_as_category': False,
        })

        products = self.env['product.product']
        for invoice in all_invoices:
            products |= invoice._get_products_to_qbo_export()

        self.assertNotIn(product1.id, products.ids)
        self.assertNotIn(product2.id, products.ids)
        self.assertIn(product3.id, products.ids)
        self.assertIn(product4.id, products.ids)

        # 3.
        products = self.env['product.product']
        for invoice in (invoice1 + invoice2):
            products |= invoice._get_products_to_qbo_export()

        self.assertFalse(bool(products))
        self.assertEqual(products._name, 'product.product')

        # 4.
        products = bill._get_products_to_qbo_export()

        self.assertIn(product3.id, products.ids)
        self.assertIn(product4.id, products.ids)

        # 5.
        products = self.env['product.product']
        for invoice in (invoice1 + invoice2):
            products |= invoice._get_products_to_qbo_export()

        self.assertFalse(bool(products))
        self.assertEqual(products._name, 'product.product')

        # 6.
        self.qi.write({
            'sync_product_as_category': True,
        })

        products = self.env['product.category']
        for invoice in all_invoices:
            products |= invoice._get_products_to_qbo_export()

        self.assertEqual(products._name, 'product.category')
        self.assertEqual(products, all_invoices.mapped('invoice_line_ids.product_id.categ_id'))

    def test_create_qbo_invoice_line_method(self):
        partner = self.env['res.partner'].create({
            'name': 'Test Invoice Partner',
        })
        consum_127 = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '127'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        consum_127._create_odoo_record()
        product = consum_127.product_id

        consum_137 = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '137'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        consum_137.write({
            'category_id': product.categ_id.id,
        })

        # A bill line without a product is exported against its account, so that
        # account has to be matched for the line to be built at all.
        expense_account = self.env.ref('quickbooks_sync_online.o_expense')
        expense_map = self.env['qbo.map.account'].search([
            ('quickbooks_integration_id', '=', self.qi.id),
            ('account_id', '=', False),
        ], limit=1)
        expense_map.account_id = expense_account.id

        invoice = self.env['account.move'].create({
            'partner_id': partner.id,
            'move_type': 'out_invoice',
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'invoice_line_ids': [
                (0, 0, {
                    'name': 'Test line1',
                    'price_unit': 10.0,
                    'quantity': 1,
                    'product_id': product.id,
                    'account_id': self.env.ref('quickbooks_sync_online.a_sale').id
                }),
                (0, 0, {
                    'name': 'Test line2',
                    'price_unit': 10.0,
                    'quantity': 1,
                    'product_id': False,
                    'account_id': self.env.ref('quickbooks_sync_online.a_sale').id
                }),
            ],
        })
        bill = self.env['account.move'].create({
            'move_type': 'in_invoice',
            'invoice_date': date.today(),
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.expenses_journal').id,
            'invoice_line_ids': [
                (0, 0, {
                    'name': 'Test line1',
                    'price_unit': 10.0,
                    'quantity': 1,
                    'product_id': product.id,
                    'account_id': self.env.ref('quickbooks_sync_online.o_expense').id
                }),
                (0, 0, {
                    'name': 'Test line2',
                    'price_unit': 10.0,
                    'quantity': 1,
                    'product_id': False,
                    'account_id': self.env.ref('quickbooks_sync_online.o_expense').id
                }),
            ],
        })

        inv_line1 = invoice.invoice_line_ids.filtered(lambda r: r.name == 'Test line1')
        inv_line2 = invoice.invoice_line_ids.filtered(lambda r: r.name == 'Test line2')

        bill_line1 = bill.invoice_line_ids.filtered(lambda r: r.name == 'Test line1')
        bill_line2 = bill.invoice_line_ids.filtered(lambda r: r.name == 'Test line2')

        # 1.
        self.qi.write({
            'include_product_to_invoice': True,
            'sync_product_as_category': False,
        })
        exp_inv_line1 = inv_line1._create_qbo_invoice_line()
        exp_inv_line2 = inv_line2._create_qbo_invoice_line()

        self.assertEqual(
            exp_inv_line1['SalesItemLineDetail']['ItemRef']['value'],
            consum_127.qbo_id,
        )
        self.assertEqual(
            exp_inv_line2['SalesItemLineDetail'].get('ItemRef', {}).get('value', '100500'),
            '100500',
        )

        exp_bill_line1 = bill_line1._create_qbo_invoice_line()
        exp_bill_line2 = bill_line2._create_qbo_invoice_line()

        self.assertEqual(
            exp_bill_line1['ItemBasedExpenseLineDetail']['ItemRef']['value'],
            consum_127.qbo_id,
        )
        # A bill line without a product is an expense against its account, and
        # carries no ItemRef at all -- QuickBooks refuses an item line without one.
        self.assertNotIn('ItemBasedExpenseLineDetail', exp_bill_line2)
        self.assertEqual(
            exp_bill_line2['AccountBasedExpenseLineDetail']['AccountRef']['value'],
            expense_map.qbo_id,
        )

        # 2.
        self.qi.write({
            'include_product_to_invoice': True,
            'sync_product_as_category': True,
        })
        exp_inv_line1 = inv_line1._create_qbo_invoice_line()
        exp_inv_line2 = inv_line2._create_qbo_invoice_line()

        self.assertEqual(
            exp_inv_line1['SalesItemLineDetail']['ItemRef']['value'],
            consum_137.qbo_id,
        )
        self.assertEqual(
            exp_inv_line2['SalesItemLineDetail'].get('ItemRef', 'NONE'),
            'NONE',
        )

        exp_bill_line1 = bill_line1._create_qbo_invoice_line()
        exp_bill_line2 = bill_line2._create_qbo_invoice_line()

        self.assertEqual(
            exp_bill_line1['ItemBasedExpenseLineDetail']['ItemRef']['value'],
            consum_137.qbo_id,
        )
        self.assertEqual(
            exp_bill_line2['AccountBasedExpenseLineDetail'].get('ItemRef', 'NONE'),
            'NONE',
        )

        # 3.
        self.qi.write({
            'include_product_to_invoice': False,
            'sync_product_as_category': False,
        })
        exp_inv_line1 = inv_line1._create_qbo_invoice_line()
        exp_inv_line2 = inv_line2._create_qbo_invoice_line()

        self.assertEqual(
            exp_inv_line1['SalesItemLineDetail'].get('ItemRef', 'NONE'),
            'NONE',
        )
        self.assertEqual(
            exp_inv_line2['SalesItemLineDetail'].get('ItemRef', 'NONE'),
            'NONE',
        )

        exp_bill_line1 = bill_line1._create_qbo_invoice_line()
        exp_bill_line2 = bill_line2._create_qbo_invoice_line()

        self.assertEqual(
            exp_bill_line1['ItemBasedExpenseLineDetail']['ItemRef']['value'],
            consum_127.qbo_id,
        )
        self.assertEqual(
            exp_bill_line2['AccountBasedExpenseLineDetail'].get('ItemRef', 'NONE'),
            'NONE',
        )

    def test_get_tax_from_invoice_line(self):
        self.map_all_accounts()
        tax = self.create_tax()

        partner = self.env['res.partner'].create({
            'name': 'Test Invoice Partner',
        })
        product1 = self.env['product.product'].create({
            'name': 'Test Invoice Product1',
            'taxes_id': [(6, 0, tax.ids)],
        })
        product2 = self.env['product.product'].create({
            'name': 'Test Invoice Product2',
            'taxes_id': [(6, 0, tax.ids)],
        })
        product3 = self.env['product.product'].create({
            'name': 'Test Invoice Product3',
        })
        product3.taxes_id = False

        product4 = self.env['product.product'].create({
            'name': 'Test Invoice Product4',
        })
        product4.taxes_id = False

        invoice = self.env['account.move'].create({
            'partner_id': partner.id,
            'move_type': 'out_invoice',
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'invoice_line_ids': [
                (0, 0, {
                    'name': 'Test line 1',
                    'price_unit': 10.0,
                    'quantity': 1,
                    'product_id': product1.id,
                    'tax_ids': [(6, 0, tax.ids)],
                    'account_id': self.env.ref('quickbooks_sync_online.a_sale').id
                }),
                (0, 0, {
                    'name': 'Test line 2',
                    'price_unit': 11.0,
                    'quantity': 1,
                    'product_id': product2.id,
                    'tax_ids': False,
                    'account_id': self.env.ref('quickbooks_sync_online.a_sale').id
                }),
                (0, 0, {
                    'name': 'Test line 3',
                    'price_unit': 12.0,
                    'quantity': 1,
                    'product_id': product3.id,
                    'tax_ids': False,
                    'account_id': self.env.ref('quickbooks_sync_online.a_sale').id
                }),
                (0, 0, {
                    'name': 'Test line 4',
                    'price_unit': 12.0,
                    'quantity': 1,
                    'product_id': product4.id,
                    'tax_ids': [(6, 0, tax.ids)],
                    'account_id': self.env.ref('quickbooks_sync_online.a_sale').id
                }),
            ],
        })

        line1, line2, line3, line4 = invoice.invoice_line_ids
        taxcode_line_detail = 'SalesItemLineDetail'

        # 1. Line tax + product tax
        self.assertEqual(line1.name, 'Test line 1')
        export_line1 = line1._create_qbo_invoice_line()
        value = export_line1[taxcode_line_detail]['TaxCodeRef']['value']
        self.assertEqual(value, TAXABLE)

        # 2. Not line tax + product tax
        self.assertEqual(line2.name, 'Test line 2')
        export_line2 = line2._create_qbo_invoice_line()
        value = export_line2[taxcode_line_detail]['TaxCodeRef']['value']
        self.assertEqual(value, TAXABLE)

        # 3. Not line tax + not product tax
        self.assertEqual(line3.name, 'Test line 3')
        export_line3 = line3._create_qbo_invoice_line()
        value = export_line3[taxcode_line_detail]['TaxCodeRef']['value']
        self.assertEqual(value, NON_TAXABLE)

        # 4. Line tax + not product tax
        self.assertEqual(line4.name, 'Test line 4')
        export_line4 = line4._create_qbo_invoice_line()
        value = export_line4[taxcode_line_detail]['TaxCodeRef']['value']
        self.assertEqual(value, TAXABLE)

    def test_inventory_adjustment_class_works(self):
        mapping = self.env['qbo.map.inventory.adjustment'].init_mapping(self.qi.id)

        # 1. Assert raise due to no map-account exists
        with self.assertRaises(ValidationError):
            mapping.init_inventory()

        map_account = self.env['qbo.map.account'].search([
            ('qbo_name', '=', 'Inventory Shrinkage'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])

        self.qi.write({
            'qi_adjust_inventory_account_id': map_account.id,
        })

        # 2. Assert inventory adjustment object is set up
        inventory = mapping.init_inventory()

        self.assertFalse(inventory.has_payload)

        self.assertTrue(inventory.qbo_object_name == 'InventoryAdjustment')
        self.assertEqual(inventory.AdjustAccountRef['value'], map_account.qbo_id)

        inventory.add_line('123', 10)
        inventory.add_line('125', 12)

        self.assertTrue(inventory.has_payload)

        self.assertEqual(len(inventory.Line), 2)
        self.assertEqual(inventory.Line[0]['ItemAdjustmentLineDetail']['ItemRef']['value'], '123')
        self.assertEqual(inventory.Line[0]['ItemAdjustmentLineDetail']['QtyDiff'], 10)
        self.assertEqual(inventory.Line[1]['ItemAdjustmentLineDetail']['ItemRef']['value'], '125')
        self.assertEqual(inventory.Line[1]['ItemAdjustmentLineDetail']['QtyDiff'], 12)

    def _create_custom_field_definition(self, **vals):
        defaults = {
            'quickbooks_integration_id': self.qi.id,
            'qbo_field_definition_id': '540344',
            'qbo_field_name': 'Salesman',
        }
        defaults.update(vals)
        Definition = self.env['qbo.custom.field.definition']
        existing = Definition.search([
            ('quickbooks_integration_id', '=', defaults['quickbooks_integration_id']),
            ('qbo_field_definition_id', '=', defaults['qbo_field_definition_id']),
        ], limit=1)
        if existing:

            return existing

        return Definition.create(defaults)

    def _create_custom_field_line(self, definition=None, **vals):
        def_vals = {}
        for key in ('qbo_field_definition_id', 'qbo_field_name', 'quickbooks_integration_id'):
            if key in vals:
                def_vals[key] = vals.pop(key)
        if definition is None:
            definition = self._create_custom_field_definition(**def_vals)
        defaults = {
            'definition_id': definition.id,
            'map_type': 'invoice',
            'odoo_field_name': 'ref',
            'apply_on_import': True,
            'apply_on_export': False,
        }
        defaults.update(vals)

        return self.env['qbo.custom.field.definition.line'].create(defaults)

    def _prepare_custom_field_invoice_dependencies(self):
        self.map_all_accounts()
        map_product = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '1'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_customer = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '2'),
            ('qbo_lib_type', '=', CUSTOMER),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_product.create_instance_in_odoo()
        map_customer.create_instance_in_odoo()

        return map_product, map_customer

    def _prepare_custom_field_bill_dependencies(self):
        self.map_all_accounts()
        map_product = self.env['qbo.map.product'].search([
            ('qbo_id', '=', '67'),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_vendor = self.env['qbo.map.partner'].search([
            ('qbo_id', '=', '31'),
            ('qbo_lib_type', '=', VENDOR),
            ('quickbooks_integration_id', '=', self.qi.id),
        ])
        map_product.create_instance_in_odoo()
        map_vendor.create_instance_in_odoo()

        return map_product, map_vendor

    def _create_custom_field_bill(self, **vals):
        map_product, map_vendor = self._prepare_custom_field_bill_dependencies()
        values = {
            'move_type': 'in_invoice',
            'invoice_date': date.today(),
            'partner_id': map_vendor.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.expenses_journal').id,
            'ref': vals.pop('ref', 'John'),
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 10.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        }
        values.update(vals)
        bill = self.env['account.move'].create(values)
        bill.action_post()

        return bill

    def _create_custom_field_creditmemo(self, **vals):
        """Same customer/product pair as the invoice fixture (CustomerRef "2", item "1")."""
        map_product, map_customer = self._prepare_custom_field_invoice_dependencies()
        values = {
            'move_type': 'out_refund',
            'invoice_date': date.today(),
            'partner_id': map_customer.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'ref': vals.pop('ref', 'John'),
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 10.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        }
        values.update(vals)
        credit_note = self.env['account.move'].create(values)
        credit_note.action_post()

        return credit_note

    def _create_custom_field_vendorcredit(self, **vals):
        """Same vendor/product pair as the bill fixture (VendorRef "31", item "67")."""
        map_product, map_vendor = self._prepare_custom_field_bill_dependencies()
        values = {
            'move_type': 'in_refund',
            'invoice_date': date.today(),
            'partner_id': map_vendor.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.expenses_journal').id,
            'ref': vals.pop('ref', 'John'),
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 10.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        }
        values.update(vals)
        vendor_credit = self.env['account.move'].create(values)
        vendor_credit.action_post()

        return vendor_credit

    @patch(request_client)
    def test_import_customer_invoice_custom_field_mapping(self, *args):
        """Import applies CustomField StringValue onto the configured Odoo field."""
        self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(apply_on_import=True)

        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(INVOICE):
            qbo_inv = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99003', INVOICE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_inv, self.qi.id, odoo_id=None,
            )

        self.assertEqual(
            mapping.extract_node('CustomField', list)[0].get('StringValue'),
            'John',
        )
        invoice = mapping.create_instance_in_odoo()
        self.assertEqual(invoice.ref, 'John')

    @patch(request_client)
    def test_import_customer_invoice_custom_field_no_odoo_field(self, *args):
        """No odoo_field_name configured → import is a no-op."""
        self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(odoo_field_name=False, apply_on_import=True)

        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(INVOICE):
            qbo_inv = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99003', INVOICE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_inv, self.qi.id, odoo_id=None,
            )

        invoice = mapping.create_instance_in_odoo()
        self.assertFalse(invoice.ref)

    @patch(request_client)
    def test_import_customer_invoice_custom_field_apply_on_import_false(self, *args):
        """apply_on_import=False → import is a no-op despite odoo_field_name."""
        self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(apply_on_import=False)

        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(INVOICE):
            qbo_inv = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99003', INVOICE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_inv, self.qi.id, odoo_id=None,
            )

        invoice = mapping.create_instance_in_odoo()
        self.assertFalse(invoice.ref)

    @patch(request_client)
    def test_import_customer_invoice_custom_field_unmatched_definition(self, *args):
        """Unmatched DefinitionId → leave field at default, no crash."""
        self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(
            qbo_field_definition_id='999999',
            apply_on_import=True,
        )

        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(INVOICE):
            qbo_inv = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99003', INVOICE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_inv, self.qi.id, odoo_id=None,
            )

        invoice = mapping.create_instance_in_odoo()
        self.assertFalse(invoice.ref)

    @patch(request_client)
    def test_import_customer_invoice_custom_field_empty_value_skipped(self, *args):
        """Empty/null QBO StringValue → do not write the Odoo field."""
        import json

        self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(apply_on_import=True)

        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(INVOICE):
            qbo_inv = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99003', INVOICE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_inv, self.qi.id, odoo_id=None,
            )

        body = mapping.qbo_dict_body
        body['CustomField'][0]['StringValue'] = ''
        mapping.qbo_object = json.dumps(body)

        values = mapping._prepare_odoo_values()
        self.assertFalse(values.get('ref'))

    @patch(request_client)
    def test_import_bill_skips_invoice_custom_field_mapping(self, *args):
        """Invoice-typed mapping must not apply when the same DefinitionId arrives on a Bill."""
        self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(apply_on_import=True, map_type='invoice')

        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(INVOICE):
            qbo_inv = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99003', INVOICE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_inv, self.qi.id, odoo_id=None,
            )

        bill_mapping = mapping.copy({
            'qbo_id': '99005',
            'qbo_lib_type': 'bill',
        })
        self.assertTrue(bill_mapping.is_bill)
        self.assertFalse(bill_mapping.is_invoice)

        values = bill_mapping._prepare_odoo_values()
        self.assertNotEqual(values.get('ref'), 'John')

    @patch(request_client)
    def test_import_invoice_skips_bill_custom_field_mapping(self, *args):
        """Bill-typed mapping must not apply when the same DefinitionId arrives on an Invoice."""
        self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(apply_on_import=True, map_type='bill')

        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(INVOICE):
            qbo_inv = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99003', INVOICE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_inv, self.qi.id, odoo_id=None,
            )

        invoice = mapping.create_instance_in_odoo()
        self.assertFalse(invoice.ref)

    @patch(request_client)
    def test_import_same_definition_maps_to_different_odoo_fields_per_type(self, *args):
        """One definition, two lines: invoice writes field A, bill writes field B."""
        self._prepare_custom_field_invoice_dependencies()
        definition = self._create_custom_field_definition()
        self._create_custom_field_line(
            definition, map_type='invoice', odoo_field_name='ref', apply_on_import=True,
        )
        self._create_custom_field_line(
            definition, map_type='bill', odoo_field_name='payment_reference', apply_on_import=True,
        )

        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(INVOICE):
            qbo_inv = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99003', INVOICE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_inv, self.qi.id, odoo_id=None,
            )

        invoice = mapping.create_instance_in_odoo()
        self.assertEqual(invoice.ref, 'John')
        self.assertNotEqual(invoice.payment_reference, 'John')

        bill_mapping = mapping.copy({
            'qbo_id': '99005',
            'qbo_lib_type': 'bill',
        })
        values = bill_mapping._prepare_odoo_values()
        self.assertNotEqual(values.get('ref'), 'John')
        self.assertEqual(values.get('payment_reference'), 'John')

    @patch(request_client)
    def test_import_vendor_bill_custom_field_mapping(self, *args):
        """Import applies CustomField StringValue onto the configured Odoo field for Bills."""
        self._prepare_custom_field_bill_dependencies()
        self._create_custom_field_line(apply_on_import=True, map_type='bill')

        MapMove = self.env['qbo.map.account.move']
        with self.patcher(BILL):
            qbo_bill = MapMove.fetch_qbo_one_by_pk(self.qi.id, '99004', BILL)
            mapping = MapMove.get_or_create_qbo_mapping_from_response(
                qbo_bill, self.qi.id, odoo_id=None,
            )

        self.assertEqual(
            mapping.extract_node('CustomField', list)[0].get('StringValue'),
            'John',
        )
        bill = mapping.create_instance_in_odoo()
        self.assertEqual(bill.ref, 'John')

    @patch(request_client)
    def test_import_vendor_bill_custom_field_no_odoo_field(self, *args):
        """No odoo_field_name configured → bill import is a no-op."""
        self._prepare_custom_field_bill_dependencies()
        self._create_custom_field_line(
            odoo_field_name=False, apply_on_import=True, map_type='bill',
        )

        MapMove = self.env['qbo.map.account.move']
        with self.patcher(BILL):
            qbo_bill = MapMove.fetch_qbo_one_by_pk(self.qi.id, '99004', BILL)
            mapping = MapMove.get_or_create_qbo_mapping_from_response(
                qbo_bill, self.qi.id, odoo_id=None,
            )

        bill = mapping.create_instance_in_odoo()
        self.assertFalse(bill.ref)

    @patch(request_client)
    def test_import_vendor_bill_custom_field_apply_on_import_false(self, *args):
        """apply_on_import=False → bill import is a no-op despite odoo_field_name."""
        self._prepare_custom_field_bill_dependencies()
        self._create_custom_field_line(apply_on_import=False, map_type='bill')

        MapMove = self.env['qbo.map.account.move']
        with self.patcher(BILL):
            qbo_bill = MapMove.fetch_qbo_one_by_pk(self.qi.id, '99004', BILL)
            mapping = MapMove.get_or_create_qbo_mapping_from_response(
                qbo_bill, self.qi.id, odoo_id=None,
            )

        bill = mapping.create_instance_in_odoo()
        self.assertFalse(bill.ref)

    @patch(request_client)
    def test_import_vendor_bill_custom_field_unmatched_definition(self, *args):
        """Unmatched DefinitionId on a Bill → leave field at default, no crash."""
        self._prepare_custom_field_bill_dependencies()
        self._create_custom_field_line(
            qbo_field_definition_id='999999',
            apply_on_import=True,
            map_type='bill',
        )

        MapMove = self.env['qbo.map.account.move']
        with self.patcher(BILL):
            qbo_bill = MapMove.fetch_qbo_one_by_pk(self.qi.id, '99004', BILL)
            mapping = MapMove.get_or_create_qbo_mapping_from_response(
                qbo_bill, self.qi.id, odoo_id=None,
            )

        bill = mapping.create_instance_in_odoo()
        self.assertFalse(bill.ref)

    @patch(request_client)
    def test_import_vendor_bill_custom_field_empty_value_skipped(self, *args):
        """Empty/null QBO StringValue on a Bill → do not write the Odoo field."""
        import json

        self._prepare_custom_field_bill_dependencies()
        self._create_custom_field_line(apply_on_import=True, map_type='bill')

        MapMove = self.env['qbo.map.account.move']
        with self.patcher(BILL):
            qbo_bill = MapMove.fetch_qbo_one_by_pk(self.qi.id, '99004', BILL)
            mapping = MapMove.get_or_create_qbo_mapping_from_response(
                qbo_bill, self.qi.id, odoo_id=None,
            )

        body = mapping.qbo_dict_body
        body['CustomField'][0]['StringValue'] = ''
        mapping.qbo_object = json.dumps(body)

        values = mapping._prepare_odoo_values()
        self.assertFalse(values.get('ref'))

    @patch(request_client)
    def test_export_customer_invoice_custom_field_mapping(self, *args):
        """Export writes CustomField from the configured Odoo field."""
        map_product, map_customer = self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(apply_on_import=False, apply_on_export=True)

        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': map_customer.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'ref': 'John',
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 10.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        })
        invoice.action_post()

        qbo_lib_model = invoice._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertEqual(
            qbo_lib_model.CustomField,
            [{'DefinitionId': '540344', 'Type': 'StringType', 'StringValue': 'John'}],
        )

    @patch(request_client)
    def test_export_customer_invoice_custom_field_empty_value_skipped(self, *args):
        """Empty/null Odoo field → do not include CustomField on export."""
        map_product, map_customer = self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(apply_on_import=False, apply_on_export=True)

        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': map_customer.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'ref': False,
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 10.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        })
        invoice.action_post()

        qbo_lib_model = invoice._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertFalse(qbo_lib_model.CustomField)

    def test_save_qbo_one_passes_enhanced_custom_fields_params(self):
        """Invoice, Bill, CreditMemo and VendorCredit save always include enhancedAllCustomFields."""
        from quickbooks.objects.invoice import Invoice
        from quickbooks.objects.bill import Bill
        from quickbooks.objects.creditmemo import CreditMemo
        from quickbooks.objects.vendorcredit import VendorCredit

        for qbo_lib_model in (Invoice(), Bill(), CreditMemo(), VendorCredit()):
            with self.subTest(qbo_object_name=qbo_lib_model.qbo_object_name):
                client = MagicMock()
                with patch.object(type(qbo_lib_model), 'save', return_value=qbo_lib_model) as save_mock:
                    self.env['qbo.map.account.move']._save_qbo_one(qbo_lib_model, client=client)

                save_mock.assert_called_once_with(
                    qb=client,
                    params={'include': 'enhancedAllCustomFields'},
                )

    def test_save_qbo_one_skips_enhanced_params_for_non_invoice(self):
        """A type outside the custom-field set delegates to abstract (no enhanced include)."""
        from quickbooks.objects.journalentry import JournalEntry

        qbo_lib_model = JournalEntry()
        client = MagicMock()

        with patch.object(type(qbo_lib_model), 'save', return_value=qbo_lib_model) as save_mock:
            self.env['qbo.map.account.move']._save_qbo_one(qbo_lib_model, client=client)

        save_mock.assert_called_once_with(qb=client)

    @patch(request_client)
    def test_export_customer_invoice_custom_field_apply_on_export_false(self, *args):
        """apply_on_export=False → CustomField is not set from mapping."""
        map_product, map_customer = self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(apply_on_import=False, apply_on_export=False)

        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': map_customer.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'ref': 'John',
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 10.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        })
        invoice.action_post()

        qbo_lib_model = invoice._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertFalse(qbo_lib_model.CustomField)

    @patch(request_client)
    def test_export_customer_invoice_custom_field_no_odoo_field(self, *args):
        """No odoo_field_name → export does not set CustomField."""
        map_product, map_customer = self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(
            odoo_field_name=False,
            apply_on_import=False,
            apply_on_export=True,
        )

        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': map_customer.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'ref': 'John',
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 10.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        })
        invoice.action_post()

        qbo_lib_model = invoice._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertFalse(qbo_lib_model.CustomField)

    @patch(request_client)
    def test_export_vendor_bill_skips_invoice_custom_field_mapping(self, *args):
        """Invoice-typed mapping must not set CustomField on vendor bill export."""
        bill = self._create_custom_field_bill()
        self._create_custom_field_line(
            apply_on_import=False, apply_on_export=True, map_type='invoice',
        )

        qbo_lib_model = bill._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertFalse(getattr(qbo_lib_model, 'CustomField', None))

    @patch(request_client)
    def test_export_customer_invoice_skips_bill_custom_field_mapping(self, *args):
        """Bill-typed mapping must not set CustomField on customer invoice export."""
        map_product, map_customer = self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(
            apply_on_import=False, apply_on_export=True, map_type='bill',
        )

        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': map_customer.partner_id.id,
            'invoice_user_id': self.user.id,
            'company_id': self.company.id,
            'journal_id': self.env.ref('quickbooks_sync_online.sales_journal').id,
            'ref': 'John',
            'invoice_line_ids': [(0, 0, {
                'name': 'Test line',
                'price_unit': 10.0,
                'quantity': 1,
                'product_id': map_product.product_id.id,
            })],
        })
        invoice.action_post()

        qbo_lib_model = invoice._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertFalse(qbo_lib_model.CustomField)

    @patch(request_client)
    def test_export_same_definition_maps_to_different_odoo_fields_per_type(self, *args):
        """One definition, two lines: each export carries its own Odoo field value."""
        bill = self._create_custom_field_bill(ref='InvoiceVal', payment_reference='BillVal')
        definition = self._create_custom_field_definition()
        self._create_custom_field_line(
            definition,
            map_type='invoice',
            odoo_field_name='ref',
            apply_on_import=False,
            apply_on_export=True,
        )
        self._create_custom_field_line(
            definition,
            map_type='bill',
            odoo_field_name='payment_reference',
            apply_on_import=False,
            apply_on_export=True,
        )

        qbo_lib_model = bill._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertEqual(
            getattr(qbo_lib_model, 'CustomField', None),
            [{'DefinitionId': '540344', 'Type': 'StringType', 'StringValue': 'BillVal'}],
        )

    @patch(request_client)
    def test_export_vendor_bill_custom_field_mapping(self, *args):
        """Export writes CustomField from the configured Odoo field on a Bill."""
        bill = self._create_custom_field_bill()
        self._create_custom_field_line(
            apply_on_import=False, apply_on_export=True, map_type='bill',
        )

        qbo_lib_model = bill._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertEqual(
            getattr(qbo_lib_model, 'CustomField', None),
            [{'DefinitionId': '540344', 'Type': 'StringType', 'StringValue': 'John'}],
        )

    @patch(request_client)
    def test_export_vendor_bill_custom_field_empty_value_skipped(self, *args):
        """Empty/null Odoo field → do not include CustomField on bill export."""
        bill = self._create_custom_field_bill(ref=False)
        self._create_custom_field_line(
            apply_on_import=False, apply_on_export=True, map_type='bill',
        )

        qbo_lib_model = bill._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertFalse(getattr(qbo_lib_model, 'CustomField', None))

    @patch(request_client)
    def test_export_vendor_bill_custom_field_apply_on_export_false(self, *args):
        """apply_on_export=False → CustomField is not set from bill mapping."""
        bill = self._create_custom_field_bill()
        self._create_custom_field_line(
            apply_on_import=False, apply_on_export=False, map_type='bill',
        )

        qbo_lib_model = bill._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertFalse(getattr(qbo_lib_model, 'CustomField', None))

    @patch(request_client)
    def test_export_vendor_bill_custom_field_no_odoo_field(self, *args):
        """No odoo_field_name → bill export does not set CustomField."""
        bill = self._create_custom_field_bill()
        self._create_custom_field_line(
            odoo_field_name=False,
            apply_on_import=False,
            apply_on_export=True,
            map_type='bill',
        )

        qbo_lib_model = bill._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertFalse(getattr(qbo_lib_model, 'CustomField', None))

    @patch(request_client)
    def test_import_customer_credit_note_custom_field_mapping(self, *args):
        """Import applies CustomField StringValue onto the configured Odoo field."""
        self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(apply_on_import=True, map_type='creditmemo')

        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(CREDIT_NOTE):
            qbo_cm = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99005', CREDIT_NOTE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_cm, self.qi.id, odoo_id=None,
            )

        self.assertTrue(mapping.is_creditmemo)
        credit_note = mapping.create_instance_in_odoo()
        self.assertEqual(credit_note.ref, 'John')

    @patch(request_client)
    def test_import_customer_credit_note_custom_field_apply_on_import_false(self, *args):
        """apply_on_import=False → import is a no-op despite odoo_field_name."""
        self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(apply_on_import=False, map_type='creditmemo')

        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(CREDIT_NOTE):
            qbo_cm = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99005', CREDIT_NOTE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_cm, self.qi.id, odoo_id=None,
            )

        credit_note = mapping.create_instance_in_odoo()
        self.assertFalse(credit_note.ref)

    @patch(request_client)
    def test_import_creditmemo_skips_invoice_custom_field_mapping(self, *args):
        """Invoice-typed mapping must not apply when the same DefinitionId arrives on a Credit Note."""
        self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(apply_on_import=True, map_type='invoice')

        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(CREDIT_NOTE):
            qbo_cm = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99005', CREDIT_NOTE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_cm, self.qi.id, odoo_id=None,
            )

        credit_note = mapping.create_instance_in_odoo()
        self.assertFalse(credit_note.ref)

    @patch(request_client)
    def test_import_invoice_skips_creditmemo_custom_field_mapping(self, *args):
        """Credit-Note-typed mapping must not apply when the same DefinitionId arrives on an Invoice."""
        self._prepare_custom_field_invoice_dependencies()
        self._create_custom_field_line(apply_on_import=True, map_type='creditmemo')

        MapInvoice = self.env['qbo.map.account.move']
        with self.patcher(INVOICE):
            qbo_inv = MapInvoice.fetch_qbo_one_by_pk(self.qi.id, '99003', INVOICE)
            mapping = MapInvoice.get_or_create_qbo_mapping_from_response(
                qbo_inv, self.qi.id, odoo_id=None,
            )

        invoice = mapping.create_instance_in_odoo()
        self.assertFalse(invoice.ref)

    @patch(request_client)
    def test_export_customer_credit_note_custom_field_mapping(self, *args):
        """Export writes CustomField from the configured Odoo field on a Credit Note."""
        credit_note = self._create_custom_field_creditmemo()
        self._create_custom_field_line(
            apply_on_import=False, apply_on_export=True, map_type='creditmemo',
        )

        qbo_lib_model = credit_note._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertEqual(
            qbo_lib_model.CustomField,
            [{'DefinitionId': '540344', 'Type': 'StringType', 'StringValue': 'John'}],
        )

    @patch(request_client)
    def test_export_customer_credit_note_custom_field_apply_on_export_false(self, *args):
        """apply_on_export=False → CustomField is not set from credit note mapping."""
        credit_note = self._create_custom_field_creditmemo()
        self._create_custom_field_line(
            apply_on_import=False, apply_on_export=False, map_type='creditmemo',
        )

        qbo_lib_model = credit_note._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertFalse(qbo_lib_model.CustomField)

    @patch(request_client)
    def test_export_vendor_credit_custom_field_mapping(self, *args):
        """Export writes CustomField from the configured Odoo field on a Vendor Refund."""
        vendor_credit = self._create_custom_field_vendorcredit()
        self._create_custom_field_line(
            apply_on_import=False, apply_on_export=True, map_type='vendorcredit',
        )

        qbo_lib_model = vendor_credit._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertEqual(
            getattr(qbo_lib_model, 'CustomField', None),
            [{'DefinitionId': '540344', 'Type': 'StringType', 'StringValue': 'John'}],
        )

    @patch(request_client)
    def test_export_vendor_credit_custom_field_apply_on_export_false(self, *args):
        """apply_on_export=False → CustomField is not set from vendor credit mapping."""
        vendor_credit = self._create_custom_field_vendorcredit()
        self._create_custom_field_line(
            apply_on_import=False, apply_on_export=False, map_type='vendorcredit',
        )

        qbo_lib_model = vendor_credit._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertFalse(getattr(qbo_lib_model, 'CustomField', None))

    @patch(request_client)
    def test_export_vendor_credit_skips_bill_custom_field_mapping(self, *args):
        """Bill-typed mapping must not set CustomField on vendor credit export."""
        vendor_credit = self._create_custom_field_vendorcredit()
        self._create_custom_field_line(
            apply_on_import=False, apply_on_export=True, map_type='bill',
        )

        qbo_lib_model = vendor_credit._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertFalse(getattr(qbo_lib_model, 'CustomField', None))

    @patch(request_client)
    def test_export_vendor_bill_skips_vendorcredit_custom_field_mapping(self, *args):
        """Vendor-Refund-typed mapping must not set CustomField on bill export."""
        bill = self._create_custom_field_bill()
        self._create_custom_field_line(
            apply_on_import=False, apply_on_export=True, map_type='vendorcredit',
        )

        qbo_lib_model = bill._prepare_qbo_api_lib_instance(self.qi.id)
        self.assertFalse(getattr(qbo_lib_model, 'CustomField', None))

    def test_fetch_qbo_by_query_adds_enhanced_params_for_customer_invoice(self):
        """Customer Invoice query always forces include=enhancedAllCustomFields."""
        client = MagicMock()
        client.query.return_value = {
            'QueryResponse': {
                'Invoice': [{
                    'Id': '99003',
                    'DocNumber': 'INV-CUSTOM-FIELD',
                    'CustomField': [{
                        'DefinitionId': '540344',
                        'StringValue': 'John',
                    }],
                }],
            },
        }

        result = self.env['qbo.map.account.move']._fetch_qbo_by_query(
            INVOICE,
            "Id = '99003'",
            client=client,
        )

        client.query.assert_called_once_with(
            "SELECT * FROM Invoice WHERE Id = '99003'",
            params={'include': 'enhancedAllCustomFields'},
        )
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].Id, '99003')
        self.assertEqual(result[0].CustomField[0].StringValue, 'John')

    def test_fetch_qbo_by_query_skips_enhanced_params_for_non_invoice(self):
        """JournalEntry query delegates to abstract (no enhanced include)."""
        from quickbooks.objects.journalentry import JournalEntry

        client = MagicMock()

        with patch(
            'odoo.addons.quickbooks_sync_online.models.mapping.abstract.qbo_map_abstract.'
            'QboClassManager.get_class',
            return_value=JournalEntry,
        ), patch.object(JournalEntry, 'query', return_value=[]) as query_mock:
            self.env['qbo.map.account.move']._fetch_qbo_by_query(
                'journalentry',
                "Id = '1'",
                client=client,
            )

        query_mock.assert_called_once_with(
            "SELECT * FROM JournalEntry WHERE Id = '1'",
            qb=client,
        )

    def test_fetch_qbo_by_query_adds_enhanced_params_for_bill(self):
        """Bill query always forces include=enhancedAllCustomFields."""
        client = MagicMock()
        client.query.return_value = {
            'QueryResponse': {
                'Bill': [{
                    'Id': '99004',
                    'DocNumber': 'BILL-CUSTOM-FIELD',
                    'CustomField': [{
                        'DefinitionId': '540344',
                        'StringValue': 'John',
                    }],
                }],
            },
        }

        result = self.env['qbo.map.account.move']._fetch_qbo_by_query(
            BILL,
            "Id = '99004'",
            client=client,
        )

        client.query.assert_called_once_with(
            "SELECT * FROM Bill WHERE Id = '99004'",
            params={'include': 'enhancedAllCustomFields'},
        )
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].Id, '99004')
        custom = result[0].CustomField[0]
        self.assertEqual(
            getattr(custom, 'StringValue', None) or custom.get('StringValue'),
            'John',
        )

    def test_fetch_qbo_by_query_adds_enhanced_params_for_creditmemo(self):
        """Customer Credit Note query always forces include=enhancedAllCustomFields."""
        client = MagicMock()
        client.query.return_value = {
            'QueryResponse': {
                'CreditMemo': [{
                    'Id': '99005',
                    'DocNumber': 'CM-CUSTOM-FIELD',
                    'CustomField': [{
                        'DefinitionId': '540344',
                        'StringValue': 'John',
                    }],
                }],
            },
        }

        result = self.env['qbo.map.account.move']._fetch_qbo_by_query(
            'creditmemo',
            "Id = '99005'",
            client=client,
        )

        client.query.assert_called_once_with(
            "SELECT * FROM CreditMemo WHERE Id = '99005'",
            params={'include': 'enhancedAllCustomFields'},
        )
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].Id, '99005')
        self.assertEqual(result[0].CustomField[0].StringValue, 'John')

    def test_fetch_qbo_by_query_adds_enhanced_params_for_vendorcredit(self):
        """Vendor Refund query always forces include=enhancedAllCustomFields."""
        client = MagicMock()
        client.query.return_value = {
            'QueryResponse': {
                'VendorCredit': [{
                    'Id': '99006',
                    'DocNumber': 'VC-CUSTOM-FIELD',
                    'CustomField': [{
                        'DefinitionId': '540344',
                        'StringValue': 'John',
                    }],
                }],
            },
        }

        result = self.env['qbo.map.account.move']._fetch_qbo_by_query(
            'vendorcredit',
            "Id = '99006'",
            client=client,
        )

        client.query.assert_called_once_with(
            "SELECT * FROM VendorCredit WHERE Id = '99006'",
            params={'include': 'enhancedAllCustomFields'},
        )
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].Id, '99006')
        custom = result[0].CustomField[0]
        self.assertEqual(
            getattr(custom, 'StringValue', None) or custom.get('StringValue'),
            'John',
        )

    def test_fetch_qbo_one_by_id_adds_enhanced_params_for_customer_invoice(self):
        """Customer Invoice GET always forces include=enhancedAllCustomFields."""
        from quickbooks.objects.invoice import Invoice

        client = MagicMock()
        response = Invoice()
        response.Id = '99003'

        with patch(
            'odoo.addons.quickbooks_sync_online.models.mapping.qbo_map_account_move.'
            'QboClassManager.get_class',
            return_value=Invoice,
        ), patch.object(Invoice, 'get', return_value=response) as get_mock:
            result = self.env['qbo.map.account.move']._fetch_qbo_one_by_id(
                '99003',
                INVOICE,
                client=client,
            )

        get_mock.assert_called_once_with(
            '99003',
            qb=client,
            params={'include': 'enhancedAllCustomFields'},
        )
        self.assertEqual(result.Id, '99003')

    def test_fetch_qbo_one_by_id_skips_enhanced_params_for_non_invoice(self):
        """JournalEntry GET delegates to abstract (no enhanced include)."""
        from quickbooks.objects.journalentry import JournalEntry

        client = MagicMock()
        response = JournalEntry()
        response.Id = '1'

        with patch(
            'odoo.addons.quickbooks_sync_online.models.mapping.abstract.qbo_map_abstract.'
            'QboClassManager.get_class',
            return_value=JournalEntry,
        ), patch.object(JournalEntry, 'get', return_value=response) as get_mock:
            self.env['qbo.map.account.move']._fetch_qbo_one_by_id(
                '1',
                'journalentry',
                client=client,
            )

        get_mock.assert_called_once_with('1', qb=client)

    def test_fetch_qbo_one_by_id_adds_enhanced_params_for_bill(self):
        """Bill GET always forces include=enhancedAllCustomFields."""
        from quickbooks.objects.bill import Bill

        client = MagicMock()
        response = Bill()
        response.Id = '99004'

        with patch(
            'odoo.addons.quickbooks_sync_online.models.mapping.qbo_map_account_move.'
            'QboClassManager.get_class',
            return_value=Bill,
        ), patch.object(Bill, 'get', return_value=response) as get_mock:
            result = self.env['qbo.map.account.move']._fetch_qbo_one_by_id(
                '99004',
                BILL,
                client=client,
            )

        get_mock.assert_called_once_with(
            '99004',
            qb=client,
            params={'include': 'enhancedAllCustomFields'},
        )
        self.assertEqual(result.Id, '99004')

    def test_fetch_qbo_one_by_id_adds_enhanced_params_for_creditmemo(self):
        """Customer Credit Note GET always forces include=enhancedAllCustomFields."""
        from quickbooks.objects.creditmemo import CreditMemo

        client = MagicMock()
        response = CreditMemo()
        response.Id = '99005'

        with patch(
            'odoo.addons.quickbooks_sync_online.models.mapping.qbo_map_account_move.'
            'QboClassManager.get_class',
            return_value=CreditMemo,
        ), patch.object(CreditMemo, 'get', return_value=response) as get_mock:
            result = self.env['qbo.map.account.move']._fetch_qbo_one_by_id(
                '99005',
                'creditmemo',
                client=client,
            )

        get_mock.assert_called_once_with(
            '99005',
            qb=client,
            params={'include': 'enhancedAllCustomFields'},
        )
        self.assertEqual(result.Id, '99005')

    def test_fetch_qbo_one_by_id_adds_enhanced_params_for_vendorcredit(self):
        """Vendor Refund GET always forces include=enhancedAllCustomFields."""
        from quickbooks.objects.vendorcredit import VendorCredit

        client = MagicMock()
        response = VendorCredit()
        response.Id = '99006'

        with patch(
            'odoo.addons.quickbooks_sync_online.models.mapping.qbo_map_account_move.'
            'QboClassManager.get_class',
            return_value=VendorCredit,
        ), patch.object(VendorCredit, 'get', return_value=response) as get_mock:
            result = self.env['qbo.map.account.move']._fetch_qbo_one_by_id(
                '99006',
                'vendorcredit',
                client=client,
            )

        get_mock.assert_called_once_with(
            '99006',
            qb=client,
            params={'include': 'enhancedAllCustomFields'},
        )
        self.assertEqual(result.Id, '99006')

    def test_invoice_import_wizard_uses_enhanced_custom_fields_on_fetch(self):
        """Invoice import wizard fetch goes through account-move query (auto include)."""
        wizard = self.env['quickbooks.invoice.import'].create({
            'qi_id': self.qi.id,
            'ttype': INVOICE,
            'fetch_method': 'by_ids',
            'external_ids': '99003',
        })
        client = MagicMock()
        client.query.return_value = {'QueryResponse': {}}

        with patch.object(
            type(self.qi),
            'get_quickbooks_api_client',
            return_value=client,
        ):
            wizard._fetch_records_by_ids()

        self.assertTrue(client.query.called)
        _args, kwargs = client.query.call_args
        self.assertEqual(kwargs.get('params'), {'include': 'enhancedAllCustomFields'})

        wizard_dates = self.env['quickbooks.invoice.import'].create({
            'qi_id': self.qi.id,
            'ttype': INVOICE,
            'fetch_method': 'by_dates',
            'datetime_start': fields.Datetime.now(),
        })
        client_dates = MagicMock()
        client_dates.query.return_value = {'QueryResponse': {}}

        with patch.object(
            type(self.qi),
            'get_quickbooks_api_client',
            return_value=client_dates,
        ):
            wizard_dates._fetch_records_by_date_range()

        self.assertTrue(client_dates.query.called)
        _args, kwargs = client_dates.query.call_args
        self.assertEqual(kwargs.get('params'), {'include': 'enhancedAllCustomFields'})

    def test_sync_custom_field_definitions_from_qbo_transaction_is_additive(self):
        """Sync creates/updates definitions and never deletes catalog or mapping lines."""
        from quickbooks.objects.invoice import Invoice

        keep_line = self._create_custom_field_line(
            qbo_field_name='Old Salesman',
            apply_on_export=True,
        )
        obsolete_def = self._create_custom_field_definition(
            qbo_field_definition_id='111111',
            qbo_field_name='Obsolete',
        )
        obsolete_line = self._create_custom_field_line(
            obsolete_def,
            odoo_field_name='payment_reference',
        )

        qbo_invoice = Invoice.from_json({
            'Id': '99003',
            'CustomField': [
                {
                    'DefinitionId': '540344',
                    'Name': 'Salesman',
                    'Type': 'StringType',
                    'StringValue': 'John',
                },
                {
                    'DefinitionId': '540355',
                    'Name': 'Region',
                    'Type': 'StringType',
                    'StringValue': 'West',
                },
            ],
        })

        created, updated = self.qi.sync_custom_field_definitions_from_qbo_transaction(
            qbo_invoice.to_json(),
        )

        self.assertEqual(created, 1)
        self.assertEqual(updated, 1)
        self.assertTrue(obsolete_def.exists())
        self.assertTrue(obsolete_line.exists())
        self.assertTrue(keep_line.exists())
        self.assertEqual(keep_line.odoo_field_name, 'ref')
        self.assertTrue(keep_line.apply_on_export)

        keep_line.invalidate_recordset()
        self.assertEqual(keep_line.qbo_field_name, 'Salesman')

        region = self.qi.qbo_custom_field_definition_ids.filtered(
            lambda r: r.qbo_field_definition_id == '540355'
        )
        self.assertEqual(region.qbo_field_name, 'Region')
        self.assertFalse(region.line_ids)

    def test_sync_custom_field_definitions_from_qbo_transaction_empty_raises(self):
        from quickbooks.objects.invoice import Invoice

        qbo_invoice = Invoice.from_json({
            'Id': '99003',
            'CustomField': [],
        })
        with self.assertRaises(UserError):
            self.qi.sync_custom_field_definitions_from_qbo_transaction(
                qbo_invoice.to_json(),
            )

    def test_sync_custom_field_definitions_from_qbo_bill_does_not_touch_invoice_lines(self):
        """A Bill fetch must not delete invoice definitions or their mapping lines."""
        from quickbooks.objects.bill import Bill

        invoice_keep = self._create_custom_field_line(
            qbo_field_name='Invoice Salesman',
            map_type='invoice',
        )
        invoice_obsolete = self._create_custom_field_line(
            qbo_field_definition_id='111111',
            qbo_field_name='Invoice Obsolete',
            odoo_field_name='payment_reference',
            map_type='invoice',
        )

        qbo_bill = Bill.from_json({
            'Id': '99004',
            'CustomField': [
                {
                    'DefinitionId': '540344',
                    'Name': 'Salesman',
                    'Type': 'StringType',
                    'StringValue': 'John',
                },
                {
                    'DefinitionId': '540355',
                    'Name': 'Region',
                    'Type': 'StringType',
                    'StringValue': 'West',
                },
            ],
        })

        created, updated = self.qi.sync_custom_field_definitions_from_qbo_transaction(
            qbo_bill.to_json(),
        )

        self.assertEqual(created, 1)
        self.assertEqual(updated, 1)
        self.assertTrue(invoice_keep.exists())
        self.assertTrue(invoice_obsolete.exists())
        self.assertEqual(invoice_keep.map_type, 'invoice')
        self.assertEqual(invoice_keep.qbo_field_name, 'Salesman')
        self.assertEqual(len(invoice_keep.definition_id.line_ids), 1)

        region = self.qi.qbo_custom_field_definition_ids.filtered(
            lambda r: r.qbo_field_definition_id == '540355'
        )
        self.assertTrue(region)
        self.assertFalse(region.line_ids)

    def test_custom_field_fetch_wizard_process(self):
        """Wizard fetches the test invoice and fills the catalog only."""
        from quickbooks.objects.invoice import Invoice

        obsolete = self._create_custom_field_definition(
            qbo_field_definition_id='111111',
            qbo_field_name='Obsolete',
        )

        qbo_invoice = Invoice.from_json({
            'Id': '99003',
            'CustomField': [{
                'DefinitionId': '540344',
                'Name': 'Salesman',
                'Type': 'StringType',
                'StringValue': 'John',
            }],
        })
        client = MagicMock()

        wizard = self.env['quickbooks.custom.field.fetch.wizard'].create({
            'qi_id': self.qi.id,
            'map_type': 'invoice',
            'qbo_transaction_id': '99003',
        })

        with patch.object(
            type(self.qi),
            'get_quickbooks_api_client',
            return_value=client,
        ), patch.object(
            type(self.env['qbo.map.account.move']),
            '_fetch_qbo_by_query',
            return_value=[qbo_invoice],
        ) as fetch_mock:
            action = wizard.action_process()

        fetch_mock.assert_called_once()
        self.assertEqual(fetch_mock.call_args[0][0], 'invoice')
        self.assertEqual(action['tag'], 'display_notification')
        self.assertTrue(obsolete.exists())
        self.assertFalse(self.qi.qbo_custom_field_mapping_line_ids)

        rows = self.qi.qbo_custom_field_definition_ids
        self.assertEqual(len(rows), 2)
        salesman = rows.filtered(lambda r: r.qbo_field_definition_id == '540344')
        self.assertEqual(salesman.qbo_field_name, 'Salesman')

    def test_custom_field_fetch_wizard_process_bill(self):
        """Wizard bill fetch adds definitions and leaves existing mapping lines in place."""
        from quickbooks.objects.bill import Bill

        invoice_line = self._create_custom_field_line(
            qbo_field_definition_id='111111',
            qbo_field_name='Invoice Keep',
            odoo_field_name='ref',
            map_type='invoice',
        )

        qbo_bill = Bill.from_json({
            'Id': '99004',
            'CustomField': [{
                'DefinitionId': '540344',
                'Name': 'Salesman',
                'Type': 'StringType',
                'StringValue': 'John',
            }],
        })
        client = MagicMock()

        wizard = self.env['quickbooks.custom.field.fetch.wizard'].create({
            'qi_id': self.qi.id,
            'map_type': 'bill',
            'qbo_transaction_id': '99004',
        })

        with patch.object(
            type(self.qi),
            'get_quickbooks_api_client',
            return_value=client,
        ), patch.object(
            type(self.env['qbo.map.account.move']),
            '_fetch_qbo_by_query',
            return_value=[qbo_bill],
        ) as fetch_mock:
            wizard.action_process()

        self.assertEqual(fetch_mock.call_args[0][0], 'bill')
        self.assertTrue(invoice_line.exists())
        self.assertEqual(invoice_line.map_type, 'invoice')
        salesman = self.qi.qbo_custom_field_definition_ids.filtered(
            lambda r: r.qbo_field_definition_id == '540344'
        )
        self.assertTrue(salesman)
        self.assertFalse(salesman.line_ids)

    def test_custom_field_fetch_wizard_process_vendorcredit(self):
        """Wizard accepts Vendor Refund as a transaction type and fills the catalog only."""
        from quickbooks.objects.vendorcredit import VendorCredit

        qbo_vendorcredit = VendorCredit.from_json({
            'Id': '99006',
            'CustomField': [{
                'DefinitionId': '540344',
                'Name': 'Salesman',
                'Type': 'StringType',
                'StringValue': 'John',
            }],
        })
        client = MagicMock()

        wizard = self.env['quickbooks.custom.field.fetch.wizard'].create({
            'qi_id': self.qi.id,
            'map_type': 'vendorcredit',
            'qbo_transaction_id': '99006',
        })

        with patch.object(
            type(self.qi),
            'get_quickbooks_api_client',
            return_value=client,
        ), patch.object(
            type(self.env['qbo.map.account.move']),
            '_fetch_qbo_by_query',
            return_value=[qbo_vendorcredit],
        ) as fetch_mock:
            action = wizard.action_process()

        self.assertEqual(fetch_mock.call_args[0][0], 'vendorcredit')
        self.assertEqual(action['tag'], 'display_notification')
        self.assertFalse(self.qi.qbo_custom_field_mapping_line_ids)
        salesman = self.qi.qbo_custom_field_definition_ids.filtered(
            lambda r: r.qbo_field_definition_id == '540344'
        )
        self.assertTrue(salesman)

    @mute_logger('odoo.sql_db')
    def test_custom_field_line_unique_definition_per_map_type(self):
        definition = self._create_custom_field_definition()
        self._create_custom_field_line(definition, map_type='invoice', odoo_field_name='ref')
        # models.Constraint is plain SQL: tests bypass service.model.retrying(),
        # so the IntegrityError is never converted to ValidationError. The
        # savepoint keeps the aborted transaction from breaking teardown.
        with self.assertRaises(UniqueViolation), self.cr.savepoint():
            self._create_custom_field_line(
                definition, map_type='invoice', odoo_field_name='payment_reference',
            )
            self.env.flush_all()

    @mute_logger('odoo.sql_db')
    def test_custom_field_line_unique_odoo_field_per_map_type(self):
        first = self._create_custom_field_definition(
            qbo_field_definition_id='540344',
            qbo_field_name='Salesman',
        )
        second = self._create_custom_field_definition(
            qbo_field_definition_id='540355',
            qbo_field_name='Region',
        )
        self._create_custom_field_line(first, map_type='invoice', odoo_field_name='ref')
        # quickbooks_integration_id is a stored related field, recomputed on the
        # next flush — without the explicit flush the violation would surface
        # outside this block.
        with self.assertRaises(UniqueViolation), self.cr.savepoint():
            self._create_custom_field_line(second, map_type='invoice', odoo_field_name='ref')
            self.env.flush_all()

    def test_custom_field_line_same_odoo_field_allowed_on_invoice_and_bill(self):
        definition = self._create_custom_field_definition()
        invoice_line = self._create_custom_field_line(
            definition, map_type='invoice', odoo_field_name='ref',
        )
        bill_line = self._create_custom_field_line(
            definition, map_type='bill', odoo_field_name='ref',
        )
        self.assertTrue(invoice_line.exists())
        self.assertTrue(bill_line.exists())
        self.assertEqual(invoice_line.odoo_field_name, bill_line.odoo_field_name)

    def test_custom_field_line_same_odoo_field_allowed_on_creditmemo_and_vendorcredit(self):
        definition = self._create_custom_field_definition()
        creditmemo_line = self._create_custom_field_line(
            definition, map_type='creditmemo', odoo_field_name='ref',
        )
        vendorcredit_line = self._create_custom_field_line(
            definition, map_type='vendorcredit', odoo_field_name='ref',
        )
        self.assertTrue(creditmemo_line.exists())
        self.assertTrue(vendorcredit_line.exists())
        self.assertEqual(creditmemo_line.odoo_field_name, vendorcredit_line.odoo_field_name)

    def test_custom_field_line_rejects_non_text_odoo_field(self):
        """Dynamic Selection is not enforced by the ORM — the constraint is."""
        definition = self._create_custom_field_definition()
        self.assertNotIn(
            'narration',
            dict(self.env['qbo.custom.field.definition.line']._selection_odoo_field_name()),
        )
        with self.assertRaises(ValidationError):
            self._create_custom_field_line(
                definition, map_type='invoice', odoo_field_name='narration',
            )

    def test_custom_field_definition_name_create_is_forbidden(self):
        with self.assertRaises(UserError):
            self.env['qbo.custom.field.definition'].name_create('001wewef')
