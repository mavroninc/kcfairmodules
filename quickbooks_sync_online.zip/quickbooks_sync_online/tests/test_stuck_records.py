# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo import fields
from odoo.tests import tagged, TransactionCase


@tagged('-at_install', 'post_install', 'qbo_stuck_records')
class TestStuckRecords(TransactionCase):
    """A document the connector cannot export must not hold up the batch."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'Stuck Records Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Stuck records connection',
            'company_id': cls.company.id,
        })
        cls.connection.write({
            'allow_out_invoice_export': True,
            'auto_export_cut_off_date': fields.Date.today(),
        })

        # The batch is searched per connection, so the company needs documents
        # of its own and nothing else's. A company created here has no chart of
        # accounts, hence the journal and the two accounts an invoice needs to
        # post: the journal's income account for the line, and a receivable one
        # on the partner for this company.
        cls.income_account = cls.env['account.account'].create({
            'name': 'Stuck Records Income',
            'code': 'SR400000',
            'account_type': 'income',
            'company_ids': [(6, 0, cls.company.ids)],
        })
        cls.receivable_account = cls.env['account.account'].create({
            'name': 'Stuck Records Receivable',
            'code': 'SR121000',
            'account_type': 'asset_receivable',
            'reconcile': True,
            'company_ids': [(6, 0, cls.company.ids)],
        })
        cls.journal = cls.env['account.journal'].create({
            'name': 'Stuck Records Sales',
            'code': 'SRSAL',
            'type': 'sale',
            'company_id': cls.company.id,
            'default_account_id': cls.income_account.id,
        })

        cls.partner = cls.env['res.partner'].create({'name': 'Stuck records partner'})
        cls.partner.with_company(cls.company).property_account_receivable_id = \
            cls.receivable_account.id

    def _invoice(self, reference):
        invoice = self.env['account.move'].with_company(self.company).create({
            'move_type': 'out_invoice',
            'partner_id': self.partner.id,
            'company_id': self.company.id,
            'invoice_date': fields.Date.today(),
            'ref': reference,
            'journal_id': self.journal.id,
            'invoice_line_ids': [(0, 0, {'name': reference, 'quantity': 1, 'price_unit': 50.0})],
        })
        invoice.action_post()

        return invoice

    def _failed_job_for(self, record):
        """A job in the state an export leaves behind when it cannot succeed."""
        Job = self.env['queue.job']

        return Job.with_context(_job_edit_sentinel=Job.EDIT_SENTINEL).create({
            'uuid': 'stuck-%s' % record.id,
            'state': 'failed',
            'model_name': record._name,
            'method_name': 'export_qbo_one',
            'identity_key': 'qbo_export_invoice-%s-%s' % (self.company.id, record),
            'records': record,
        })

    def test_a_document_whose_job_failed_is_left_out_of_the_batch(self):
        stuck = self._invoice('STUCK')
        self._failed_job_for(stuck)
        fresh = self._invoice('FRESH')

        batch = self.connection._search_to_qbo_invoices(limit=10)

        self.assertNotIn(stuck, batch)
        self.assertIn(fresh, batch)

    def test_the_batch_is_not_used_up_by_documents_that_cannot_export(self):
        """The point of it: with a small batch, the stuck ones used to be all
        of it and nothing else ever went out."""
        for index in range(3):
            self._failed_job_for(self._invoice('STUCK-%s' % index))

        expected = [self._invoice('FRESH-%s' % index) for index in range(2)]

        batch = self.connection._search_to_qbo_invoices(limit=3)

        self.assertEqual(set(batch.ids), {x.id for x in expected})

    def test_the_document_comes_back_once_the_job_is_dealt_with(self):
        stuck = self._invoice('STUCK')
        job = self._failed_job_for(stuck)

        self.assertNotIn(stuck, self.connection._search_to_qbo_invoices(limit=10))

        Job = self.env['queue.job']
        job.with_context(_job_edit_sentinel=Job.EDIT_SENTINEL).write({'state': 'pending'})

        self.assertIn(stuck, self.connection._search_to_qbo_invoices(limit=10))
