# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import json

from odoo.exceptions import ValidationError
from odoo.tests import tagged, TransactionCase


@tagged('-at_install', 'post_install', 'qbo_currency_cards')
class TestCurrencyCards(TransactionCase):
    """A contact holds one QuickBooks card per currency, and an update has to
    reach every one of them under the currency that names it."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'Currency Cards Connection Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Currency cards connection',
            'company_id': cls.company.id,
        })
        cls.partner = cls.env['res.partner'].create({'name': 'Currency Cards Co'})

    def _card(self, qbo_id, currency_name):
        return self.env['qbo.map.partner'].create({
            'qbo_id': qbo_id,
            'qbo_name': 'Currency Cards Co (customer)',
            'qbo_lib_type': 'customer',
            'quickbooks_integration_id': self.connection.id,
            'partner_id': self.partner.id,
            'qbo_object': json.dumps({
                'Id': qbo_id,
                'DisplayName': 'Currency Cards Co (customer)',
                'CurrencyRef': {'value': currency_name},
            }),
        })

    def test_an_update_reaches_every_card(self):
        company_currency = self.company.currency_id.name
        base = self._card('1001', company_currency)
        foreign = self._card('1002', 'JPY')

        reachable = self.partner._qbo_mappings_of_type(self.connection.id, 'customer')

        self.assertEqual(reachable, base | foreign)

    def test_the_export_still_picks_the_card_of_its_currency(self):
        """`_get_qbo_mapping` stays narrowed: an export has a document whose
        currency says which card it means."""
        base = self._card('1001', self.company.currency_id.name)
        self._card('1002', 'JPY')

        self.assertEqual(self.partner._get_qbo_mapping(self.connection.id, 'customer'), base)

    def test_a_contact_with_only_a_foreign_card_is_not_skipped(self):
        foreign = self._card('1002', 'JPY')

        self.assertFalse(self.partner._get_qbo_mapping(self.connection.id, 'customer'))
        self.assertEqual(
            self.partner._qbo_mappings_of_type(self.connection.id, 'customer'), foreign)

    def test_each_card_gets_a_job_of_its_own(self):
        base = self._card('1001', self.company.currency_id.name)
        foreign = self._card('1002', 'JPY')

        keys = {
            self.partner._job_kwargs_qbo_transaction(
                map_type='customer', update=True, mapping=card)['identity_key']
            for card in (base, foreign)
        }

        self.assertEqual(len(keys), 2)

    def test_without_a_card_the_job_key_is_unchanged(self):
        """Models holding a single card keep the key they had."""
        key = self.partner._job_kwargs_qbo_transaction(map_type='customer', update=True)

        self.assertNotIn('-False', key['identity_key'])
        self.assertTrue(key['identity_key'].endswith(str(self.partner)))

    def test_an_update_names_the_card_by_its_own_currency(self):
        foreign = self._card('1002', 'JPY')

        named = foreign.with_context(
            with_currency_name=foreign._extract_currency_name(),
        ).partner_id._prepare_qbo_name(self.connection.id, 'customer')

        self.assertTrue(named.endswith('[JPY]'))

    def test_more_than_one_card_at_once_is_reported_in_words(self):
        """The base method has an answer for this; the currency hook must not
        pre-empt it with a bare singleton error."""
        cards = self._card('1001', self.company.currency_id.name) | self._card('1002', 'JPY')

        with self.assertRaises(ValidationError):
            cards.update_qbo_one()

    def test_a_card_carries_its_currency_into_the_update(self):
        foreign = self._card('1002', 'JPY')

        self.assertEqual(foreign._qbo_update_context(), {'with_currency_name': 'JPY'})

    def test_a_mapping_of_another_model_carries_nothing(self):
        """The hook is empty everywhere but on contacts."""
        product = self.env['product.product'].create({'name': 'Currency Cards Widget'})
        mapping = self.env['qbo.map.product'].create({
            'qbo_id': '2001',
            'qbo_name': 'Currency Cards Widget',
            'qbo_lib_type': 'item',
            'quickbooks_integration_id': self.connection.id,
            'product_id': product.id,
        })

        self.assertEqual(mapping._qbo_update_context(), {})

    def test_two_cards_of_one_currency_are_left_alone(self):
        """Two cards the export cannot tell apart are mapped ambiguously: an
        update would write the same name to both."""
        base = self.company.currency_id.name
        self._card('1001', base)
        self._card('1003', base)

        self.assertEqual(self.partner._action_update_to_quickbooks(self.connection.id, 'customer'), 0)

    def test_cards_of_different_currencies_are_each_updated(self):
        self._card('1001', self.company.currency_id.name)
        self._card('1002', 'JPY')

        self.assertEqual(self.partner._action_update_to_quickbooks(self.connection.id, 'customer'), 2)


@tagged('-at_install', 'post_install', 'qbo_sync_label')
class TestQboSyncLabel(TransactionCase):
    """`is_qbo_sync_done` says a contact is synced; the label says as what."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'Sync Label Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Sync label connection',
            'company_id': cls.company.id,
        })
        # `is_qbo_sync_done` and the label both read the company's *active*
        # connection, which is what res.company.quickbooks_integration answers.
        cls.connection.state = 'active'

        # Both read it off `self.env.company` rather than off the contact, so
        # the environment has to stand in the company that owns the connection
        # above. Without this the label would answer about whatever connection
        # the test database happens to have, which is what this suite is meant
        # not to depend on.
        cls.env.user.company_ids = [(4, cls.company.id)]
        cls.env = cls.env(context=dict(
            cls.env.context, allowed_company_ids=[cls.company.id],
        ))

    def _partner_with(self, *types):
        partner = self.env['res.partner'].create({'name': 'Sync Label Co'})

        for number, map_type in enumerate(types, start=1):
            self.env['qbo.map.partner'].create({
                'qbo_id': f'770{number}',
                'qbo_name': f'Sync Label Co ({map_type})',
                'qbo_lib_type': map_type,
                'quickbooks_integration_id': self.connection.id,
                'partner_id': partner.id,
            })

        return partner

    def test_a_contact_synced_as_a_customer_says_so(self):
        self.assertEqual(self._partner_with('customer').qbo_sync_label, 'Customer')

    def test_a_contact_synced_as_a_vendor_says_so(self):
        partner = self._partner_with('vendor')

        self.assertTrue(partner.is_qbo_sync_done)
        self.assertEqual(partner.qbo_sync_label, 'Vendor')

    def test_a_contact_synced_as_both_names_both(self):
        partner = self._partner_with('customer', 'vendor')

        self.assertEqual(partner.qbo_sync_label, 'Customer, Vendor')

    def test_a_contact_that_was_never_exported_has_no_label(self):
        partner = self.env['res.partner'].create({'name': 'Sync Label Co'})

        self.assertFalse(partner.is_qbo_sync_done)
        self.assertFalse(partner.qbo_sync_label)

    def test_the_label_reads_the_selection_rather_than_the_key(self):
        """The stored value is `customer`; the badge should not show that."""
        partner = self._partner_with('customer')

        self.assertNotIn('customer', partner.qbo_sync_label)


@tagged('-at_install', 'post_install', 'qbo_currency_cards')
class TestCurrencyOnImport(TransactionCase):
    """The card's currency belongs to the card, not to the contact."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'Currency On Import Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Currency on import connection',
            'company_id': cls.company.id,
        })

    def _card(self, display_name, currency_name):
        return self.env['qbo.map.partner'].create({
            'qbo_id': '1100',
            'qbo_name': display_name,
            'qbo_lib_type': 'customer',
            'quickbooks_integration_id': self.connection.id,
            'qbo_object': json.dumps({
                'Id': '1100',
                'DisplayName': display_name,
                'CurrencyRef': {'value': currency_name},
            }),
        })

    def test_the_contact_is_not_given_a_currency(self):
        """`res.partner.currency_id` is computed from the company, is not stored
        and has no inverse, so handing it to create() only looked like it worked."""
        card = self._card('Euro Co (customer) [JPY]', 'JPY')

        self.assertNotIn('currency_id', card._prepare_odoo_values())

    def test_the_currency_stays_on_the_card(self):
        card = self._card('Euro Co (customer) [JPY]', 'JPY')

        self.assertEqual(card._extract_currency_name(), 'JPY')
        self.assertEqual(card._qbo_update_context(), {'with_currency_name': 'JPY'})

    def test_the_name_is_still_read_without_its_currency_suffix(self):
        """The currency is read to strip the suffix, then dropped."""
        card = self._card('Euro Co (customer) [JPY]', 'JPY')

        self.assertEqual(card._prepare_odoo_values()['name'], 'Euro Co')
