# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import psycopg2

from odoo.exceptions import ValidationError
from odoo.tests import tagged, TransactionCase
from odoo.tools import mute_logger


@tagged('-at_install', 'post_install', 'qbo_mapping_identity')
class TestMappingIdentity(TransactionCase):
    """One QuickBooks object is one mapping per connection."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'Mapping Identity Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Mapping identity connection',
            'company_id': cls.company.id,
        })
        cls.values = {
            'qbo_id': '4242',
            'qbo_name': 'Mapped product',
            'qbo_lib_type': 'item',
            'quickbooks_integration_id': cls.connection.id,
        }

    def test_the_same_object_cannot_be_mapped_twice(self):
        self.env['qbo.map.product'].create(self.values)

        with self.assertRaises(psycopg2.IntegrityError), mute_logger('odoo.sql_db'):
            self.env['qbo.map.product'].create(self.values)
            self.env.flush_all()

    def test_another_connection_maps_the_same_object_on_its_own(self):
        other_company = self.env['res.company'].create({'name': 'Mapping Identity Co 2'})
        other = self.env['quickbooks.integration'].create({
            'name': 'Second connection',
            'company_id': other_company.id,
        })

        self.env['qbo.map.product'].create(self.values)
        twin = self.env['qbo.map.product'].create(
            dict(self.values, quickbooks_integration_id=other.id))

        self.assertTrue(twin.id)

    def test_a_payment_maps_once_per_settled_document(self):
        """One QuickBooks payment settles several documents, and the mapping
        keeps a row for each of them."""
        documents = self.env['qbo.map.account.move'].create([
            {'qbo_id': '10', 'qbo_name': 'INV-10', 'qbo_lib_type': 'invoice',
             'quickbooks_integration_id': self.connection.id},
            {'qbo_id': '11', 'qbo_name': 'INV-11', 'qbo_lib_type': 'invoice',
             'quickbooks_integration_id': self.connection.id},
        ])
        payment = {
            'qbo_id': '99',
            'qbo_name': 'PAY-99',
            'qbo_lib_type': 'payment',
            'quickbooks_integration_id': self.connection.id,
        }

        rows = self.env['qbo.map.payment'].create([
            dict(payment, txn_id=documents[0].id),
            dict(payment, txn_id=documents[1].id),
        ])
        self.env.flush_all()
        self.assertEqual(len(rows), 2)

        with self.assertRaises(psycopg2.IntegrityError), mute_logger('odoo.sql_db'):
            self.env['qbo.map.payment'].create(dict(payment, txn_id=documents[0].id))
            self.env.flush_all()

    def test_a_mapping_does_not_move_to_another_record(self):
        """The duplicate-name recovery finds a QuickBooks object by its name and
        binds whatever it finds, so a second record of the same name would take
        over the object the first one is already exporting to."""
        product = self.env['product.product'].create({'name': 'Mapped product'})
        twin = self.env['product.product'].create({'name': 'Mapped product'})

        mapping = self.env['qbo.map.product'].create(self.values)
        mapping.bind_odoo(product.id)
        self.assertEqual(mapping.product_id, product)

        with self.assertRaises(ValidationError):
            mapping.bind_odoo(twin.id)

        self.assertEqual(mapping.product_id, product)
        self.assertFalse(twin.qbo_mapping_ids)

    def test_a_mapping_is_bound_to_the_same_record_again_without_complaint(self):
        product = self.env['product.product'].create({'name': 'Mapped product'})

        mapping = self.env['qbo.map.product'].create(self.values)
        mapping.bind_odoo(product.id)
        mapping.bind_odoo(product.id)

        self.assertEqual(mapping.product_id, product)

    def test_an_unbound_mapping_still_takes_a_record(self):
        product = self.env['product.product'].create({'name': 'Mapped product'})

        mapping = self.env['qbo.map.product'].create(self.values)
        self.assertFalse(mapping.product_id)

        mapping.bind_odoo(product.id)

        self.assertEqual(mapping.product_id, product)

    def test_the_message_tells_the_two_records_apart(self):
        """Both records carry the same name -- that is what sent the export down
        this path -- so the ids have to be in the message."""
        product = self.env['product.product'].create({'name': 'Mapped product'})
        twin = self.env['product.product'].create({'name': 'Mapped product'})

        mapping = self.env['qbo.map.product'].create(self.values)
        mapping.bind_odoo(product.id)

        with self.assertRaises(ValidationError) as caught:
            mapping.bind_odoo(twin.id)

        message = str(caught.exception)
        self.assertIn(str(product.id), message)
        self.assertIn(str(twin.id), message)
        self.assertIn('4242', message)

    def test_binding_takes_one_mapping_at_a_time(self):
        product = self.env['product.product'].create({'name': 'Mapped product'})

        pair = self.env['qbo.map.product'].create([
            self.values,
            dict(self.values, qbo_id='4243'),
        ])

        with self.assertRaises(ValueError):
            pair.bind_odoo(product.id)
