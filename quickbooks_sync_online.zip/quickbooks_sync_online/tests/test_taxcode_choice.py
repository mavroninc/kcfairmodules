# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo.tests import tagged, TransactionCase

from ..models.account_tax import qbo_id_sort_key


@tagged('-at_install', 'post_install', 'qbo_taxcode_choice')
class TestTaxcodeChoice(TransactionCase):
    """Which QuickBooks tax code a line is exported under.

    A QuickBooks tax rate belongs to as many tax codes as the company builds on
    it, so a line can fit several. The export takes the first of them, which
    means the order has to be the same on every run and in every process.
    """

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.country = cls.env.ref('base.ca')
        cls.company = cls.env['res.company'].create({
            'name': 'Taxcode Choice Co',
            'country_id': cls.country.id,
        })
        cls.qi = cls.env['quickbooks.integration'].create({
            'name': 'Taxcode Choice Connection',
            'company_id': cls.company.id,
            'state': 'active',
            'qb_company_id': '123',
        })

        # A company made here carries no chart of accounts, and account.tax
        # cannot be stored without a group.
        cls.tax_group = cls.env['account.tax.group'].create({
            'name': 'Taxcode Choice Group',
            'company_id': cls.company.id,
        })

        cls.gst = cls._tax('GST 5%', 5.0)
        cls.pst = cls._tax('PST 7%', 7.0)

        cls.gst_rate = cls._rate('4', 'GST', cls.gst)
        cls.pst_rate = cls._rate('9', 'PST', cls.pst)

    @classmethod
    def _tax(cls, name, amount):
        return cls.env['account.tax'].create({
            'name': name,
            'amount': amount,
            'amount_type': 'percent',
            'type_tax_use': 'sale',
            'company_id': cls.company.id,
            'country_id': cls.country.id,
            'tax_group_id': cls.tax_group.id,
        })

    @classmethod
    def _rate(cls, qbo_id, name, tax):
        return cls.env['qbo.map.tax'].create({
            'qbo_id': qbo_id,
            'qbo_lib_type': 'taxrate',
            'qbo_name': name,
            'quickbooks_integration_id': cls.qi.id,
            'tax_id': tax.id,
        })

    def _taxcode(self, qbo_id, name, sales_rates=(), purchase_rates=()):
        return self.env['qbo.map.taxcode'].create({
            'qbo_id': qbo_id,
            'qbo_lib_type': 'taxcode',
            'qbo_name': name,
            'quickbooks_integration_id': self.qi.id,
            'sales_tax_rate_ids': [(6, 0, [r.id for r in sales_rates])],
            'purchase_tax_rate_ids': [(6, 0, [r.id for r in purchase_rates])],
        })

    def test_one_tax_code_is_answered_as_itself(self):
        self._taxcode('7', 'GST only', sales_rates=[self.gst_rate])

        self.assertEqual(self.gst.find_qbo_taxcodes(self.qi.id, 'customer'), ['7'])

    def test_a_tax_in_several_codes_is_answered_in_a_stable_order(self):
        """The whole point: the same taxes must not go out under two codes.

        The order used to come out of a set, whose iteration order for strings
        differs from one process to the next, so two queue workers exporting the
        same line sent QuickBooks two different tax codes.
        """
        self._taxcode('31', 'GST + PST BC', sales_rates=[self.gst_rate, self.pst_rate])
        self._taxcode('7', 'GST only', sales_rates=[self.gst_rate])
        self._taxcode('112', 'GST + something else', sales_rates=[self.gst_rate])

        answers = {
            tuple(self.gst.find_qbo_taxcodes(self.qi.id, 'customer'))
            for _ in range(5)
        }

        self.assertEqual(answers, {('7', '31', '112')})

    def test_the_order_is_numeric_not_alphabetic(self):
        """QuickBooks ids are numbers written as text: "112" is after "31"."""
        self.assertEqual(
            sorted(['112', '31', '7'], key=qbo_id_sort_key),
            ['7', '31', '112'],
        )

    def test_an_id_that_is_not_a_number_sorts_last_instead_of_raising(self):
        self.assertEqual(
            sorted(['x', '31', '7'], key=qbo_id_sort_key),
            ['7', '31', 'x'],
        )

    def test_only_the_codes_carrying_every_tax_are_answered(self):
        """A line with GST and PST fits the combined code, not the GST-only one."""
        self._taxcode('7', 'GST only', sales_rates=[self.gst_rate])
        self._taxcode('31', 'GST + PST BC', sales_rates=[self.gst_rate, self.pst_rate])

        both = self.gst | self.pst

        self.assertEqual(both.find_qbo_taxcodes(self.qi.id, 'customer'), ['31'])

    def test_the_sales_and_purchase_sides_are_kept_apart(self):
        self._taxcode('7', 'Sales GST', sales_rates=[self.gst_rate])
        self._taxcode('8', 'Purchase GST', purchase_rates=[self.gst_rate])

        self.assertEqual(self.gst.find_qbo_taxcodes(self.qi.id, 'customer'), ['7'])
        self.assertEqual(self.gst.find_qbo_taxcodes(self.qi.id, 'vendor'), ['8'])

    def test_no_taxes_is_no_tax_codes(self):
        self.assertEqual(
            self.env['account.tax'].find_qbo_taxcodes(self.qi.id, 'customer'),
            [],
        )
