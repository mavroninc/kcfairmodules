# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import json

from unittest.mock import patch

from odoo.tests import tagged, TransactionCase
from odoo.exceptions import ValidationError

from .config.intuit_case import IntuitCred, QuickbooksInit, request_client
from ..quickbooks_api import QuickBooksClient, AuthClient
from ..models.res_partner import QBO_DISPLAY_NAME_MAX_LENGTH, QBO_NAME_MAX_LENGTH


@tagged('-at_install', '-standard', 'post_install', 'qbo_test_connection')
class TestQuickbooksIntegration(QuickbooksInit):

    def setUp(self):
        super(TestQuickbooksIntegration, self).setUp()

    def test_qi_get_qbo_env(self):
        env = self.qi.get_qbo_env()
        self.assertEqual(env, 'sandbox')

    def test_qi_redirect_uri(self):
        su = self.env['ir.config_parameter'].sudo()
        redirect_uri_ = su.get_str('web.base.url') + '/qbo/callback'
        self.assertEqual(self.qi.get_redirect_uri(), redirect_uri_)

    def test_qi_cron_nex_call(self):
        self.qi._compute_automation_points()
        cron = self.env.ref(
            'quickbooks_sync_online.trigget_send_invoices_to_qb_cron',
            raise_if_not_found=False,
        )
        if cron:
            self.assertEqual(self.qi.auto_export_next_call_point, cron.nextcall)

    def test_qi_auth_client(self):
        client = self.qi._get_qbo_auth_client()
        self.assertIsInstance(client, AuthClient)

    @patch(request_client)
    def test_qi_get_qbo_client(self, *args):
        with self.assertRaises(ValidationError):
            self.qi.get_quickbooks_api_client()

        self.qi.write({
            'qb_refresh_token': IntuitCred.qb_refresh_token,
        })
        qbo_object = self.qi.get_quickbooks_api_client()
        self.assertIsInstance(qbo_object, QuickBooksClient)

    def test_qi_intuit_company_info(self):
        self._set_up_connection()
        self.assertTrue(self.qi.qb_is_us_company)


@tagged('-at_install', 'post_install')
class TestQboPartnerAddressFormat(TransactionCase):

    def test_format_to_qbo_country_code_converts_alpha2_to_alpha3(self):
        partner_us = self.env['res.partner'].create({
            'name': 'US Partner',
            'country_id': self.env.ref('base.us').id,
        })
        partner_gb = self.env['res.partner'].create({
            'name': 'GB Partner',
            'country_id': self.env.ref('base.uk').id,
        })
        partner_fr = self.env['res.partner'].create({
            'name': 'FR Partner',
            'country_id': self.env.ref('base.fr').id,
        })

        self.assertEqual(partner_us.country_id.code, 'US')
        self.assertEqual(partner_us._format_to_qbo_country_code(), 'USA')
        self.assertEqual(partner_gb.country_id.code, 'GB')
        self.assertEqual(partner_gb._format_to_qbo_country_code(), 'GBR')
        self.assertEqual(partner_fr.country_id.code, 'FR')
        self.assertEqual(partner_fr._format_to_qbo_country_code(), 'FRA')

    def test_format_to_qbo_country_code_without_country(self):
        partner = self.env['res.partner'].create({
            'name': 'Partner Without Country',
        })
        self.assertFalse(partner.country_id)
        self.assertEqual(partner._format_to_qbo_country_code(), '')

    def test_format_to_qbo_country_code_unknown_code_fallback(self):
        partner = self.env['res.partner'].create({
            'name': 'Partner With Unknown Country',
            'country_id': self.env.ref('base.us').id,
        })
        with patch(
            'odoo.addons.quickbooks_sync_online.models.res_partner.pycountry.countries.get',
            return_value=None,
        ):
            self.assertEqual(partner._format_to_qbo_country_code(), 'US')

    def test_format_to_qbo_address_uses_alpha3_country(self):
        state = self.env.ref('base.state_us_5')
        partner = self.env['res.partner'].create({
            'name': 'Address Partner',
            'country_id': self.env.ref('base.us').id,
            'state_id': state.id,
            'city': 'San Francisco',
            'street': '1 Market St',
            'street2': 'Suite 100',
            'zip': '94105',
        })

        self.assertEqual(partner._format_to_qbo_address(), {
            'City': 'San Francisco',
            'Country': 'USA',
            'CountrySubDivisionCode': state.name,
            'Line1': '1 Market St',
            'Line2': 'Suite 100',
            'PostalCode': '94105',
        })

    def _address_lines(self, partner):
        values = partner._format_to_export_qbo_address()
        return [v for k, v in sorted(values.items()) if k.startswith('Line')]

    def test_a_document_address_names_the_company_above_the_contact(self):
        company = self.env['res.partner'].create({
            'name': 'Gemini Furniture',
            'is_company': True,
            'street': 'G People Road',
            'street2': '24',
            'city': 'Los Angeles',
        })
        contact = self.env['res.partner'].create({
            'name': 'Edwin Hanson',
            'parent_id': company.id,
            'type': 'contact',
        })

        self.assertEqual(
            self._address_lines(contact),
            ['Gemini Furniture', 'Edwin Hanson', 'G People Road', '24'],
        )

    def test_a_company_is_not_printed_twice(self):
        company = self.env['res.partner'].create({
            'name': 'Gemini Furniture',
            'is_company': True,
            'street': 'G People Road',
            'street2': '24',
        })

        self.assertEqual(
            self._address_lines(company),
            ['Gemini Furniture', 'G People Road', '24'],
        )

    def test_a_contact_of_nobody_is_not_its_own_company(self):
        """Odoo 19 kept a typed-in company on `res.partner.company_name`, and this
        printed it above the contact. Odoo 20 removed that field:
        `commercial_company_name` is the commercial partner's name, and a contact
        of nobody is its own -- so the only thing it could print above itself is
        its own name, which the equality check skips.
        """
        partner = self.env['res.partner'].create({
            'name': 'Edwin Hanson',
            'street': 'G People Road',
        })

        self.assertEqual(
            self._address_lines(partner),
            ['Edwin Hanson', 'G People Road'],
        )

    def test_an_address_without_a_street_leaves_no_gap(self):
        company = self.env['res.partner'].create({
            'name': 'Timber Inc',
            'is_company': True,
        })
        contact = self.env['res.partner'].create({
            'name': 'Edwin Hanson',
            'parent_id': company.id,
            'type': 'contact',
            'city': 'Los Angeles',
        })

        values = contact._format_to_export_qbo_address()

        self.assertEqual(self._address_lines(contact), ['Timber Inc', 'Edwin Hanson'])
        self.assertNotIn('Line3', values)
        self.assertEqual(values['City'], 'Los Angeles')

    def test_the_billing_address_is_the_invoice_card(self):
        """Odoo's address types are contact / invoice / delivery / other. Asking
        `address_get` for a `billing` type it does not know gets the contact back,
        which is how the invoice card came to be ignored."""
        company = self.env['res.partner'].create({
            'name': 'Acme Corp',
            'is_company': True,
            'street': '1 HQ Way',
            'city': 'Dallas',
        })
        billing = self.env['res.partner'].create({
            'name': 'Billing Dept',
            'parent_id': company.id,
            'type': 'invoice',
            'street': '5 Billing Blvd',
            'city': 'Austin',
        })

        self.assertEqual(company.get_billing_for_qb(), billing)
        self.assertEqual(company.address_get(['billing'])['billing'], company.id)

    def test_a_partner_without_an_invoice_card_bills_at_its_own_address(self):
        partner = self.env['res.partner'].create({
            'name': 'Acme Corp',
            'is_company': True,
            'street': '1 HQ Way',
        })

        self.assertEqual(partner.get_billing_for_qb(), partner)

    def test_the_shipping_address_is_the_delivery_card(self):
        company = self.env['res.partner'].create({'name': 'Acme Corp', 'is_company': True})
        delivery = self.env['res.partner'].create({
            'name': 'Warehouse',
            'parent_id': company.id,
            'type': 'delivery',
            'street': '9 Dock Rd',
        })

        self.assertEqual(company.get_shipping_for_qb(), delivery)

    def test_a_contact_child_cannot_hold_an_address_of_its_own(self):
        """The reason a sub-customer's BillWithParent cannot be derived: Odoo
        pushes any address written on a contact child back up to the parent."""
        company = self.env['res.partner'].create({
            'name': 'Acme Corp',
            'is_company': True,
            'street': '1 HQ Way',
            'city': 'Dallas',
        })
        child = self.env['res.partner'].create({
            'name': 'Acme Branch',
            'parent_id': company.id,
            'type': 'contact',
        })
        self.assertEqual(child.street, company.street)

        child.write({'street': '77 Separate St', 'city': 'El Paso'})

        self.assertEqual(company.street, '77 Separate St')
        self.assertEqual(company.city, 'El Paso')
        self.assertEqual(child.get_billing_for_qb()._format_to_qbo_address(),
                         company.get_billing_for_qb()._format_to_qbo_address())


@tagged('-at_install', 'post_install')
class TestQboPartnerNameLimits(TransactionCase):
    """QuickBooks refuses some names outright, and only says so after the export."""

    def _partner(self, name):
        return self.env['res.partner'].create({'name': name})

    def test_a_colon_is_refused_with_the_reason(self):
        partner = self._partner('Acme: Division')

        with self.assertRaises(ValidationError) as caught:
            partner._check_name_qbo()

        message = str(caught.exception)
        self.assertIn('a colon', message)
        self.assertIn('sub-customers', message)

    def test_a_tab_and_a_line_break_are_refused(self):
        for name, label in [('Acme\tDivision', 'a tab'), ('Acme\nDivision', 'a line break')]:
            with self.assertRaises(ValidationError) as caught:
                self._partner(name)._check_name_qbo()

            message = str(caught.exception)
            self.assertIn(label, message)
            # Only the colon carries the sub-customer explanation.
            self.assertNotIn('sub-customers', message)

    def test_a_name_that_fits_the_budget_passes(self):
        partner = self._partner('A' * QBO_NAME_MAX_LENGTH)

        self.assertTrue(partner._check_name_qbo())

    def test_a_longer_name_is_refused_with_its_length(self):
        length = QBO_NAME_MAX_LENGTH + 1
        partner = self._partner('A' * length)

        with self.assertRaises(ValidationError) as caught:
            partner._check_name_qbo()

        message = str(caught.exception)
        self.assertIn(str(length), message)
        self.assertIn(str(QBO_NAME_MAX_LENGTH), message)

    def test_the_budget_leaves_room_for_the_suffixes(self):
        """The name travels as DisplayName with a type suffix and, in a foreign
        currency, a currency one. Both have to fit inside the 500 QuickBooks allows."""
        longest = QBO_NAME_MAX_LENGTH + len(' (customer)') + len(' [EUR]')

        self.assertLessEqual(longest, QBO_DISPLAY_NAME_MAX_LENGTH)

    def test_an_ordinary_name_passes(self):
        self.assertTrue(self._partner('Gemini Furniture')._check_name_qbo())

    def test_the_export_checks_the_name(self):
        """The check hangs off _check_qbo_requirements, which both the export and
        the update call before they reach the API."""
        partner = self._partner('Acme: Division')

        with self.assertRaises(ValidationError):
            partner._check_qbo_requirements()


@tagged('-at_install', 'post_install')
class TestQboContactPerson(TransactionCase):
    """GivenName and FamilyName are the person behind the card, not the card."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        # `quickbooks.integration` carries a unique constraint on company_id,
        # which is why the connection gets a company of its own rather than
        # the one the test database happens to run under: reusing that one
        # would tie the test to whatever connection, documents and mappings
        # already live there.
        cls.company = cls.env['res.company'].create({'name': 'Contact Person Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Contact person connection',
            'company_id': cls.company.id,
        })

    def _company_name_for(self, partner):
        payload = partner \
            .with_context(with_qbo_lib_type='customer') \
            ._prepare_qbo_api_lib_instance(self.connection.id)

        return payload.CompanyName

    def test_the_payload_leaves_the_contact_person_alone(self):
        # A Tax ID is what makes `is_company` true in Odoo 20 -- it is computed,
        # and passing the flag to `create()` is discarded without a word.
        partner = self.env['res.partner'].create({
            'name': 'Cool Cars',
            'vat': 'US123456789',
        })
        self.assertTrue(partner.is_company)

        payload = partner \
            .with_context(with_qbo_lib_type='customer') \
            ._prepare_qbo_api_lib_instance(self.connection.id)

        self.assertEqual(payload.DisplayName, 'Cool Cars (customer)')
        self.assertEqual(payload.CompanyName, 'Cool Cars')
        self.assertFalse(payload.GivenName)
        self.assertFalse(payload.FamilyName)

    def test_a_contact_carries_the_company_it_belongs_to(self):
        """QuickBooks puts the parent's company on a sub-customer card -- its own
        "55 Twin Lane" carries "Freeman Sporting Goods"."""
        company = self.env['res.partner'].create({
            'name': 'Freeman Sporting Goods',
            'is_company': True,
        })
        contact = self.env['res.partner'].create({
            'name': 'Amelia',
            'parent_id': company.id,
            'type': 'contact',
        })
        # A sub-customer payload asks for the parent's card to point ParentRef at,
        # and the lookup that finds it narrows by the card's own currency.
        self.env['qbo.map.partner'].create({
            'qbo_id': '881',
            'qbo_name': 'Freeman Sporting Goods (customer)',
            'qbo_lib_type': 'customer',
            'quickbooks_integration_id': self.connection.id,
            'partner_id': company.id,
            'qbo_object': json.dumps({
                'Id': '881',
                'CurrencyRef': {'value': self.env.company.currency_id.name},
            }),
        })

        self.assertEqual(contact.commercial_company_name, 'Freeman Sporting Goods')
        self.assertEqual(self._company_name_for(contact), 'Freeman Sporting Goods')

    def test_a_company_without_a_tax_id_is_read_off_its_card(self):
        """Odoo 20 computes `is_company` from the Tax ID, so a company that
        carries none looks like an individual here. The card QuickBooks already
        holds for it says otherwise, and `is_qbo_company` is that answer kept."""
        partner = self.env['res.partner'].create({'name': 'Cool Cars'})

        self.assertFalse(partner.is_company)
        self.assertEqual(self._company_name_for(partner), '')

        self.env['qbo.map.partner'].create({
            'qbo_id': '882',
            'qbo_name': 'Cool Cars (customer)',
            'qbo_lib_type': 'customer',
            'quickbooks_integration_id': self.connection.id,
            'partner_id': partner.id,
            'qbo_object': json.dumps({
                'Id': '882',
                'DisplayName': 'Cool Cars (customer)',
                'CompanyName': 'Cool Cars',
                'CurrencyRef': {'value': self.env.company.currency_id.name},
            }),
        })

        self.assertEqual(self._company_name_for(partner), 'Cool Cars')

    def test_an_individual_without_a_company_sends_none(self):
        partner = self.env['res.partner'].create({'name': 'Diego Rodriguez'})

        self.assertEqual(self._company_name_for(partner), '')

    def test_an_individual_is_named_by_the_display_name_alone(self):
        partner = self.env['res.partner'].create({'name': 'Diego Rodriguez'})

        payload = partner \
            .with_context(with_qbo_lib_type='customer') \
            ._prepare_qbo_api_lib_instance(self.connection.id)

        # Odoo keeps no first/last split, so guessing one would be worse than
        # leaving the fields for QuickBooks to hold.
        self.assertFalse(payload.GivenName)
        self.assertFalse(payload.CompanyName)
        self.assertEqual(payload.DisplayName, 'Diego Rodriguez (customer)')


@tagged('-at_install', 'post_install')
class TestQboCompanyRoundTrip(TransactionCase):
    """CompanyName has to survive QuickBooks -> Odoo -> QuickBooks."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'Round Trip Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Round trip connection',
            'company_id': cls.company.id,
        })

    def _import(self, display_name, company_name):
        mapping = self.env['qbo.map.partner'].create({
            'qbo_id': '990',
            'qbo_name': display_name,
            'qbo_lib_type': 'customer',
            'quickbooks_integration_id': self.connection.id,
            'qbo_object': json.dumps({
                'Id': '990',
                'DisplayName': display_name,
                'CompanyName': company_name,
                'CurrencyRef': {'value': self.env.company.currency_id.name},
            }),
        })

        return mapping.create_instance_in_odoo()

    def _card(self):
        return self.env['qbo.map.partner'].search([
            ('quickbooks_integration_id', '=', self.connection.id),
            ('qbo_id', '=', '990'),
        ])

    def _export(self, partner):
        payload = partner \
            .with_context(with_qbo_lib_type='customer') \
            ._prepare_qbo_api_lib_instance(self.connection.id)

        return payload.CompanyName

    def test_a_company_card_comes_back_as_a_company(self):
        partner = self._import('Cool Cars', 'Cool Cars')

        # Not `partner.is_company`: Odoo 20 computes that from the Tax ID, and the
        # card carries none. What the card said is kept on the card.
        self.assertTrue(self._card().is_qbo_company)
        self.assertEqual(self._export(partner), 'Cool Cars')

    def test_a_person_at_a_company_keeps_the_company(self):
        """The shape that used to lose it: DisplayName names the person, so
        `bool(CompanyName)` called them a company and their own name then
        shadowed the company on the way back.

        Odoo 19 wrote Acme Inc to `res.partner.company_name`. Odoo 20 has no such
        field, so the card holds it and the export reads it back from there.
        """
        partner = self._import('John Smith', 'Acme Inc')

        self.assertFalse(self._card().is_qbo_company)
        self.assertEqual(self._card().qbo_company_name, 'Acme Inc')
        self.assertEqual(self._export(partner), 'Acme Inc')

    def test_a_person_without_a_company_stays_one(self):
        partner = self._import('Diego Rodriguez', '')

        self.assertFalse(partner.is_company)
        self.assertEqual(self._export(partner), '')

    def test_a_job_under_a_parent_is_not_a_company(self):
        """QuickBooks puts the parent's company on a job card -- "55 Twin Lane"
        of "Freeman Sporting Goods" -- and a job is not a company of its own."""
        mapping = self.env['qbo.map.partner'].browse()

        self.assertFalse(mapping._is_qbo_company('55 Twin Lane', 'Freeman Sporting Goods'))
        self.assertTrue(mapping._is_qbo_company('Cool Cars', 'Cool Cars'))

    def test_surrounding_spaces_do_not_decide_it(self):
        mapping = self.env['qbo.map.partner'].browse()

        self.assertTrue(mapping._is_qbo_company('Cool Cars', ' Cool Cars '))
