# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from types import SimpleNamespace
from unittest.mock import patch

from odoo.tests import tagged, TransactionCase
from odoo.exceptions import ValidationError
from odoo.tools import mute_logger

from ..quickbooks_api import catch_exception, AuthClientError, AuthorizationException


class FakeClient:
    """Stands in for QuickBooksClient: all the retry needs is the token it carries."""

    def __init__(self, token):
        self.token = token
        self.quickbooks_integration_id = 1


API_LOGGER = 'odoo.addons.quickbooks_sync_online.quickbooks_api'


@tagged('-at_install', 'post_install', 'qbo_token_refresh')
class TestApiTokenRefresh(TransactionCase):
    """The retry after an expired access token must use the refreshed token."""

    def setUp(self):
        super().setUp()
        self.tokens_sent = []

    def _api_call(self, fail_times):
        """A decorated API call that refuses `fail_times` calls as unauthorized."""
        @catch_exception
        def call(orm_record, client=None):
            self.tokens_sent.append(client.token)

            if len(self.tokens_sent) <= fail_times:
                raise AuthorizationException('token expired', 3200, '')

            return 'ok'

        return call

    def _patched_integration(self, fresh_client):
        """Refresh the connection without touching the network."""
        model = type(self.env['quickbooks.integration'])

        return (
            patch.object(model, '_refresh_qbo_access_token', autospec=True),
            patch.object(model, 'get_quickbooks_api_client', autospec=True, return_value=fresh_client),
        )

    def test_retry_uses_the_refreshed_token(self):
        stale, fresh = FakeClient('EXPIRED'), FakeClient('REFRESHED')
        refresh_patch, build_patch = self._patched_integration(fresh)

        with refresh_patch as refresh, build_patch:
            result = self._api_call(fail_times=1)(self.env['qbo.map.product'], client=stale)

        self.assertEqual(result, 'ok')
        self.assertEqual(refresh.call_count, 1)
        self.assertEqual(self.tokens_sent, ['EXPIRED', 'REFRESHED'])

    @mute_logger(API_LOGGER)
    def test_a_second_refusal_is_reported(self):
        """One retry only: a connection that stays unauthorized has to be re-authorized."""
        stale, fresh = FakeClient('EXPIRED'), FakeClient('ALSO_EXPIRED')
        refresh_patch, build_patch = self._patched_integration(fresh)

        with refresh_patch as refresh, build_patch:
            with self.assertRaises(ValidationError):
                self._api_call(fail_times=2)(self.env['qbo.map.product'], client=stale)

        self.assertEqual(refresh.call_count, 1)
        self.assertEqual(self.tokens_sent, ['EXPIRED', 'ALSO_EXPIRED'])

    @mute_logger(API_LOGGER)
    def test_a_call_without_a_client_is_reported_not_crashed(self):
        """The client is looked up, not assumed: without it there is nothing to refresh."""
        @catch_exception
        def call(orm_record):
            raise AuthorizationException('token expired', 3200, '')

        with self.assertRaises(ValidationError):
            call(self.env['qbo.map.product'])

    @mute_logger(API_LOGGER)
    def test_a_refused_refresh_is_reported_in_our_own_words(self):
        """A refresh token Intuit no longer honours is an answer, not a stack trace.

        It is refused inside the handler that calls the refresh, past the point
        where the decorator's own `except AuthClientError` could see it, so it
        used to reach the user as intuitlib's HTTP dump.
        """
        stale = FakeClient('EXPIRED')
        model = type(self.env['quickbooks.integration'])
        refusal = AuthClientError(SimpleNamespace(
            status_code=400,
            content=b'{"error":"invalid_grant"}',
            headers={'intuit_tid': 'tid', 'Date': 'now'},
        ))

        with patch.object(model, '_refresh_qbo_access_token', autospec=True, side_effect=refusal):
            with self.assertRaises(ValidationError) as caught:
                self._api_call(fail_times=1)(self.env['qbo.map.product'], client=stale)

        self.assertIn('re-authenticate', str(caught.exception))
        self.assertEqual(self.tokens_sent, ['EXPIRED'])
