# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo import fields
from odoo.tests import tagged, TransactionCase


@tagged('-at_install', 'post_install', 'qbo_payment_batch')
class TestPaymentBatch(TransactionCase):
    """The batch of the export cron is spent on payments it can export."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'Payment Batch Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Payment batch connection',
            'company_id': cls.company.id,
        })

        # Customer payments only, which is what the domain of the cron narrows to.
        cls.connection.write({
            'allow_out_invoice_export': True,
            'allow_in_invoice_export': False,
            'auto_export_cut_off_date': fields.Date.today(),
        })

        # The batch is searched per connection, so the company needs payments of
        # its own and nothing else's. A company created here has no chart of
        # accounts, so everything posting a payment reaches for is built below.
        #
        # The outstanding account is the one that is easy to miss. A payment
        # posts a journal entry when the payment method line names such an
        # account -- and also when the Accounting app is absent, because then
        # `account.payment.create` insists on finding one itself and raises
        # "No outstanding account could be found to make the payment" if it
        # cannot. Naming it here keeps the class off that fork: it posts the
        # same way whether or not the database has the app installed.
        cls.bank_account = cls._account('Bank', 'PB101401', 'asset_cash')
        cls.outstanding_account = cls._account(
            'Outstanding', 'PB101402', 'asset_current', reconcile=True)
        cls.receivable_account = cls._account(
            'Receivable', 'PB121000', 'asset_receivable', reconcile=True)
        cls.payable_account = cls._account(
            'Payable', 'PB211000', 'liability_payable', reconcile=True)

        cls.journal = cls.env['account.journal'].create({
            'name': 'Payment Batch Bank',
            'code': 'PBBNK',
            'type': 'bank',
            'company_id': cls.company.id,
            'default_account_id': cls.bank_account.id,
        })
        payment_method_lines = (
            cls.journal.inbound_payment_method_line_ids
            | cls.journal.outbound_payment_method_line_ids
        )
        payment_method_lines.payment_account_id = cls.outstanding_account.id

        # The other side of the entry is the partner's account, and which one it
        # is depends on the type of the payment, so both are set.
        cls.partner = cls.env['res.partner'].create({'name': 'Payment batch partner'})
        cls.partner.with_company(cls.company).property_account_receivable_id = \
            cls.receivable_account.id
        cls.partner.with_company(cls.company).property_account_payable_id = \
            cls.payable_account.id

    @classmethod
    def _account(cls, name, code, account_type, reconcile=False):
        return cls.env['account.account'].create({
            'name': 'Payment Batch %s' % name,
            'code': code,
            'account_type': account_type,
            'reconcile': reconcile,
            'company_ids': [(6, 0, cls.company.ids)],
        })

    def _payment(self, payment_type, partner_type, amount):
        payment = self.env['account.payment'].with_company(self.company).create({
            'payment_type': payment_type,
            'partner_type': partner_type,
            'partner_id': self.partner.id,
            'amount': amount,
            'journal_id': self.journal.id,
            'company_id': self.company.id,
            'date': fields.Date.today(),
        })
        payment.action_post()

        return payment

    def test_payments_of_another_type_do_not_use_up_the_batch(self):
        """Vendor payments used to be fetched, then dropped, and the customer
        payments behind them never came up."""
        for index in range(5):
            self._payment('outbound', 'supplier', 10 + index)

        expected = [self._payment('inbound', 'customer', 100 + index) for index in range(3)]

        batch = self.connection._search_to_qbo_payments(limit=5)

        self.assertEqual(len(batch), 3)
        self.assertEqual(set(batch.ids), {x.id for x in expected})

    def test_the_limit_still_caps_the_batch(self):
        for index in range(4):
            self._payment('inbound', 'customer', 200 + index)

        self.assertEqual(len(self.connection._search_to_qbo_payments(limit=2)), 2)
