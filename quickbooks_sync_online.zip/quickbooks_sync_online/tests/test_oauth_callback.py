# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from unittest.mock import patch

from werkzeug.exceptions import BadRequest, Forbidden
from werkzeug.utils import redirect

import odoo.http

from odoo.tests import tagged, TransactionCase
from odoo.exceptions import ValidationError

from ..controllers.main import QboCallbackController


class FakeRequest:
    """Stands in for `http.request`: the callback only reads the environment
    and redirects."""

    def __init__(self, env):
        self.env = env

    def redirect(self, location):
        return redirect(location)


class FakeAuthClient:

    access_token = 'ACCESS'
    refresh_token = 'REFRESH'

    def __init__(self):
        self.exchanged = []

    def get_bearer_token(self, code, realm_id=None):
        self.exchanged.append((code, realm_id))


@tagged('-at_install', 'post_install', 'qbo_oauth_callback')
class TestOauthCallback(TransactionCase):
    """Guards of the endpoint that stores the granted QuickBooks credentials."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'OAuth Callback Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Callback connection',
            'company_id': cls.company.id,
        })

        cls.manager = cls.env['res.users'].create({
            'name': 'QuickBooks administrator',
            'login': 'qbo.callback.manager',
            'company_ids': [(4, cls.company.id)],
            'company_id': cls.company.id,
            'group_ids': [(6, 0, [
                cls.env.ref('base.group_user').id,
                cls.env.ref('quickbooks_sync_online.qbo_security_group_manager').id,
            ])],
        })
        cls.employee = cls.env['res.users'].create({
            'name': 'Employee',
            'login': 'qbo.callback.employee',
            'company_ids': [(4, cls.company.id)],
            'company_id': cls.company.id,
            'group_ids': [(6, 0, [cls.env.ref('base.group_user').id])],
        })

        cls.wizard = cls.env['quickbooks.auth.wizard'].create({'qi_id': cls.connection.id})
        cls.state = cls.wizard._update_state_token()

    def _callback(self, user, **params):
        controller = QboCallbackController()

        with patch.object(odoo.http, 'request', FakeRequest(self.env(user=user))):
            return controller.qbo_callback(**params)

    def test_a_call_without_a_state_is_rejected(self):
        with self.assertRaises(BadRequest):
            self._callback(self.manager)

    def test_an_unknown_wizard_is_rejected(self):
        with self.assertRaises(BadRequest):
            self._callback(self.manager, state='token.999999')

    def test_a_forged_state_is_rejected(self):
        """The token is what tells an answer from Intuit apart from a forged call."""
        with self.assertRaises(BadRequest):
            self._callback(self.manager, state='FORGED.%s' % self.wizard.id)

    def test_a_user_without_rights_cannot_authorize(self):
        """The wizard is read with elevated rights, the connection must not be."""
        with self.assertRaises(Forbidden):
            self._callback(self.employee, state=self.state, code='code', realmId='realm')

    def test_a_refused_grant_is_reported(self):
        """Intuit answers a refused grant with an error and no code at all.

        Returning to the form would reopen the wizard as if nothing had
        happened, so the reason is put in front of whoever tried.
        """
        with self.assertRaises(BadRequest) as caught:
            self._callback(self.manager, state=self.state, error='access_denied',
                           error_description='The user did not grant access')

        self.assertIn('access_denied', caught.exception.description)
        self.assertIn('The user did not grant access', caught.exception.description)
        self.assertFalse(self.connection.sudo().qb_company_id)
        self.assertEqual(self.connection.state, 'draft')

    def test_an_answer_without_a_code_is_reported(self):
        with self.assertRaises(BadRequest):
            self._callback(self.manager, state=self.state)

    def test_a_company_that_does_not_match_is_rolled_back(self):
        auth_client = FakeAuthClient()
        model = type(self.env['quickbooks.integration'])

        auth_patch = patch.object(
            model, '_get_qbo_auth_client', autospec=True, return_value=auth_client,
        )
        company_patch = patch.object(
            model, '_validate_intuit_company_info', autospec=True,
            side_effect=ValidationError('Different countries'),
        )

        with auth_patch, company_patch:
            with self.assertRaises(BadRequest):
                self._callback(self.manager, state=self.state, code='code', realmId='realm')

        self.assertEqual(auth_client.exchanged, [('code', 'realm')])
        self.assertFalse(self.connection.sudo().qb_company_id)
        self.assertEqual(self.connection.state, 'draft')
