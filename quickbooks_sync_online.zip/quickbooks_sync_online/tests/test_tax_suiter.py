# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import json
import time

from collections import Counter

from os.path import dirname, join

from odoo.tests import tagged, BaseCase

from ..tools import TaxSuiter


DATA_DIR = join(dirname(__file__), 'data')

PRODUCT_DETAIL_TYPES = ('SalesItemLineDetail', 'DiscountLineDetail')

# Tax codes of the GB sandbox company, as imported into 'qbo.map.taxcode'.
GB_TAXCODE_RATES = {
    '16': ['28'],   # 20.0% S
    '20': ['47'],   # No VAT
    '25': ['41'],   # Exempt
}


def load_fixture(name):
    """Return (product lines, tax lines, apply-taxes-after-discount) of a QBO document."""
    with open(join(DATA_DIR, name)) as fd:
        body = json.load(fd)

    product_lines = [x for x in body['Line'] if x.get('DetailType') in PRODUCT_DETAIL_TYPES]
    tax_lines = body['TxnTaxDetail']['TaxLine']

    return product_lines, tax_lines, body.get('ApplyTaxAfterDiscount', False)


@tagged('-at_install', 'post_install', 'qbo_tax_suiter')
class TestTaxSuiter(BaseCase):
    """Tax attribution on documents captured from the QuickBooks sandbox companies."""

    def _amount_per_rate(self, product_lines, result):
        totals = {}
        for line in product_lines:
            for rate in result[line['LineNum']]:
                totals[rate] = totals.get(rate, 0) + line['Amount']
        return totals

    def _assert_matches_document(self, product_lines, tax_lines, result):
        """Every rate must cover exactly the amount the document says it taxed."""
        totals = self._amount_per_rate(product_lines, result)

        for tax_line in tax_lines:
            rate = TaxSuiter.tax_rate_from_tax_line(tax_line)
            net = TaxSuiter.net_amount_taxable(tax_line)

            self.assertAlmostEqual(
                totals.get(rate, 0), net, places=2,
                msg='rate %s covers %s instead of %s' % (rate, totals.get(rate, 0), net),
            )

    def test_non_us_takes_the_rates_of_the_tax_code(self):
        """Outside the US the tax code of the line is the answer, no matching needed."""
        product_lines, tax_lines, after_discount = load_fixture('qbo_invoice_gb_255.json')

        suiter = TaxSuiter(product_lines, tax_lines, False, after_discount, taxcode_rates=GB_TAXCODE_RATES)
        result = suiter.suite()

        self.assertEqual(result[1], ['28'])     # 235.00, tax code 16 (20.0% S)
        self.assertEqual(result[2], ['47'])     # 331.50, tax code 20 (No VAT)
        self.assertEqual(result[3], ['41'])     # 5.00, tax code 25 (Exempt)
        self._assert_matches_document(product_lines, tax_lines, result)

    def test_a_zero_rate_survives_the_import(self):
        """QuickBooks lists no TaxLine for a zero rate, but "No VAT" is a choice
        made on the line and must not turn into no tax at all."""
        product_lines, tax_lines, after_discount = load_fixture('qbo_invoice_gb_255.json')

        rates_in_document = {TaxSuiter.tax_rate_from_tax_line(x) for x in tax_lines}
        self.assertNotIn('47', rates_in_document)

        result = TaxSuiter(product_lines, tax_lines, False, after_discount,
                           taxcode_rates=GB_TAXCODE_RATES).suite()

        self.assertEqual(result[2], ['47'])

    def test_a_zero_amount_line_keeps_its_own_rate(self):
        """A line worth 0 fits every subset for free, so matching amounts hands it
        every rate of the document. Its tax code does not."""
        product_lines, tax_lines, after_discount = load_fixture('qbo_invoice_gb_255.json')

        zero_line = next(x for x in product_lines if not x['Amount'])
        self.assertEqual(TaxSuiter.tax_code_from_product_line(zero_line), '20')

        result = TaxSuiter(product_lines, tax_lines, False, after_discount,
                           taxcode_rates=GB_TAXCODE_RATES).suite()
        self.assertEqual(result[zero_line['LineNum']], ['47'])

        guessed = TaxSuiter(product_lines, tax_lines, False, after_discount).suite()
        self.assertEqual(sorted(guessed[zero_line['LineNum']]), ['28', '41'])

    def test_non_us_document_of_27_lines(self):
        """Three tax codes over 27 lines: the shape that made the plain subset scan
        run through 126 million combinations."""
        product_lines, tax_lines, after_discount = load_fixture('qbo_invoice_gb_27_lines.json')

        started = time.time()
        result = TaxSuiter(product_lines, tax_lines, False, after_discount,
                           taxcode_rates=GB_TAXCODE_RATES).suite()
        elapsed = time.time() - started

        self.assertEqual(sum(1 for x in result.values() if x), 27)
        self.assertEqual(sorted(Counter(tuple(x) for x in result.values()).values()), [9, 9, 9])
        self._assert_matches_document(product_lines, tax_lines, result)
        self.assertLess(elapsed, 1, 'tax attribution took %.2fs' % elapsed)

    def test_the_fallback_is_bounded(self):
        """Without the tax codes the amounts are matched, and that must still finish."""
        product_lines, tax_lines, after_discount = load_fixture('qbo_invoice_gb_27_lines.json')

        started = time.time()
        TaxSuiter(product_lines, tax_lines, False, after_discount).suite()
        elapsed = time.time() - started

        self.assertLess(elapsed, 5, 'the fallback took %.2fs' % elapsed)

    def test_us_groups_by_tax_classification(self):
        """Automated Sales Tax leaves no rate on the line, but it does leave the
        product tax category it used to pick what to tax."""
        product_lines, tax_lines, after_discount = load_fixture('qbo_invoice_28_lines.json')

        classifications = {TaxSuiter.classification(x) for x in product_lines}
        self.assertEqual(len(classifications), 2)

        result = TaxSuiter(product_lines, tax_lines, True, after_discount).suite()

        self.assertEqual(sum(1 for x in result.values() if x), 26)
        self._assert_matches_document(product_lines, tax_lines, result)

    def test_a_sales_receipt_taxes_only_what_quickbooks_taxed(self):
        """The "Get QuickBooks Taxes" button of a sale order asks QuickBooks to
        price the tax on a throwaway sales receipt and reads the answer back.

        Taken from the sandbox: a receipt holding a service and three goods,
        where Automated Sales Tax charged the goods and left the service alone.
        Matching the whole taxable base found nothing, so the order came back
        with no tax on any line at all.
        """
        product_lines = [
            {'LineNum': 1, 'Amount': 75.0, 'DetailType': 'SalesItemLineDetail',
             'SalesItemLineDetail': {'TaxCodeRef': {'value': 'TAX'},
                                     'TaxClassificationRef': {'value': 'EUC-04030101-V1-00060000'}}},
        ] + [
            {'LineNum': n, 'Amount': amount, 'DetailType': 'SalesItemLineDetail',
             'SalesItemLineDetail': {'TaxCodeRef': {'value': 'TAX'},
                                     'TaxClassificationRef': {'value': 'EUC-09020802-V1-00120000'}}}
            for n, amount in ((2, 30.0), (3, 41.0), (4, 52.0))
        ]
        tax_lines = [
            {'DetailType': 'TaxLineDetail',
             'TaxLineDetail': {'NetAmountTaxable': 123.0, 'TaxRateRef': {'value': rate}}}
            for rate in ('12', '13', '28', '34')
        ]

        result = TaxSuiter(product_lines, tax_lines, True, False).suite()

        self.assertEqual(result[1], [])
        for line_num in (2, 3, 4):
            self.assertEqual(sorted(result[line_num]), ['12', '13', '28', '34'])
        self._assert_matches_document(product_lines, tax_lines, result)

    def test_subset_search_gives_up_instead_of_hanging(self):
        """Above the limit the lines are left without rates, never searched for."""
        lines = [
            {
                'LineNum': i,
                'Amount': 10.0 + i,
                'DetailType': 'SalesItemLineDetail',
                'SalesItemLineDetail': {'TaxCodeRef': {'value': 'TAX'}},
            }
            for i in range(1, TaxSuiter.MAX_SUBSET_SEARCH_LINES + 2)
        ]
        tax_lines = [{
            'DetailType': 'TaxLineDetail',
            'TaxLineDetail': {'NetAmountTaxable': 999999.0, 'TaxRateRef': {'value': '9'}},
        }]

        started = time.time()
        result = TaxSuiter(lines, tax_lines, False, False).suite()
        elapsed = time.time() - started

        self.assertFalse(any(result.values()))
        self.assertLess(elapsed, 1, 'the search took %.2fs' % elapsed)
