# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo.tests import tagged, TransactionCase


@tagged('-at_install', 'post_install', 'qbo_empty_recordsets')
class TestEmptyRecordsets(TransactionCase):
    """Every entry point has to survive being handed nothing.

    The export loops collect the identity keys of the jobs they queued and
    cancel the failed ones once, at the end. A loop that queued nothing has an
    empty collection to offer, which is not the same as offering no argument:
    reading it as "no argument" sends the code looking for the map type of an
    empty recordset. The crons call these entry points on whatever the batch
    happened to hold, including nothing.
    """

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'Empty Recordsets Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Empty recordsets connection',
            'company_id': cls.company.id,
        })

    def test_cancelling_with_no_keys_does_nothing(self):
        self.assertIsNone(
            self.env['account.payment']._mark_qbo_failed_jobs_as_cancel(identity_key=[]))

    def test_cancelling_without_an_argument_on_nothing_does_nothing(self):
        self.assertIsNone(
            self.env['account.payment']._mark_qbo_failed_jobs_as_cancel())

    def test_cancelling_takes_one_key_or_many(self):
        Job = self.env['queue.job']

        self.assertIsNone(Job.cancel_failed_jobs_by_identity_key([]))
        self.assertIsNone(Job.cancel_failed_jobs_by_identity_key([None, '']))
        Job.cancel_failed_jobs_by_identity_key('a-single-key')
        Job.cancel_failed_jobs_by_identity_key(['one', 'two'])

    def test_exporting_nothing_reports_nothing(self):
        """Every export action, handed an empty recordset."""
        for model in ('account.move', 'account.payment', 'product.product',
                      'product.category', 'stock.warehouse'):
            with self.subTest(model=model):
                result = self.env[model].action_export_to_quickbooks()

                self.assertEqual(result['params']['type'], 'warning')

    def test_exporting_no_contacts_reports_nothing(self):
        result = self.env['res.partner'] \
            .with_context(with_qbo_partner_type='customer') \
            .action_export_to_quickbooks()

        self.assertEqual(result['params']['type'], 'warning')

    def test_updating_nothing_queues_nothing(self):
        for model in ('res.partner', 'product.product'):
            with self.subTest(model=model):
                queued = self.env[model]._action_update_to_quickbooks(
                    self.connection.id, 'customer')

                self.assertEqual(queued, 0)

    def test_the_update_cron_helper_takes_an_empty_recordset(self):
        for model in ('res.partner', 'product.product'):
            with self.subTest(model=model):
                self.assertTrue(
                    self.connection._action_update_records_to_quickbooks(self.env[model]))

    def test_splitting_a_payment_over_nothing(self):
        self.assertEqual(
            self.env['account.move']._get_amount_chunks_for_qbo_payments(1, 100.0), [])

    def test_the_batches_take_a_connection_with_no_documents(self):
        self.assertEqual(len(self.connection._search_to_qbo_invoices(limit=5)), 0)
        self.assertEqual(len(self.connection._search_to_qbo_payments(limit=5)), 0)
        self.assertEqual(
            self.connection._records_with_a_failed_export('account.move'), [])
