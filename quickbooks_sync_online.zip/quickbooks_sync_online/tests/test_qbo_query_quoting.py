# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo.tests import tagged, BaseCase
from odoo.exceptions import ValidationError

from ..tools import quote_qbo_query_value, qbo_query_id_list


@tagged('-at_install', 'post_install', 'qbo_query_quoting')
class TestQboQueryQuoting(BaseCase):
    """Values that reach the QuickBooks query language.

    The expectations below were taken from the sandbox: QuickBooks escapes with
    a backslash and answers anything else with "Error parsing query".
    """

    def test_a_plain_value_is_quoted(self):
        self.assertEqual(quote_qbo_query_value('Drawer'), "'Drawer'")

    def test_an_apostrophe_is_escaped_with_a_backslash(self):
        """A name as ordinary as O'Brien used to break the query."""
        self.assertEqual(quote_qbo_query_value("D'Angelo Widget"), r"'D\'Angelo Widget'")

    def test_a_trailing_backslash_cannot_escape_the_closing_quote(self):
        """Without doubling, 'abc\\' ends in an escaped quote and the query breaks."""
        self.assertEqual(quote_qbo_query_value('abc\\'), r"'abc\\'")

    def test_a_value_is_never_left_unquoted(self):
        for value in ("Robert'); DROP--", "' OR '1'='1", 42, 3.5):
            quoted = quote_qbo_query_value(value)

            self.assertTrue(quoted.startswith("'") and quoted.endswith("'"))
            # No apostrophe of the value survives unescaped, so it cannot end the literal.
            self.assertFalse(quoted[1:-1].replace(r"\'", '').replace(r'\\', '').count("'"))

    def test_ids_are_quoted_one_by_one(self):
        self.assertEqual(qbo_query_id_list(['12', 34, ' 56 ']), "'12', '34', '56'")

    def test_an_id_that_is_not_a_number_is_refused(self):
        """The wizard takes them from a form field, so they never reach the query."""
        with self.assertRaises(ValidationError):
            qbo_query_id_list(['12', 'abc'])

        with self.assertRaises(ValidationError):
            qbo_query_id_list(["1') OR Name LIKE '%"])
