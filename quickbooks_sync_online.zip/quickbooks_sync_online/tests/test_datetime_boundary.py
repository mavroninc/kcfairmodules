# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from datetime import datetime

from odoo.tests import tagged, BaseCase

from ..tools import parse_datetime_from_str, convert_utc_datetime_to_str


@tagged('-at_install', 'post_install', 'qbo_datetime_boundary')
class TestDatetimeBoundary(BaseCase):
    """Datetimes crossing between Odoo and QuickBooks.

    Odoo keeps its datetimes in UTC. QuickBooks answers in the time zone of the
    company and reads a value with no offset as being in it, so a value handed
    over or read back without regard for the offset lands hours away from the
    moment it means. All of the expectations below were taken from the sandbox.
    """

    def test_a_datetime_sent_to_quickbooks_carries_its_offset(self):
        moment = datetime(2026, 8, 28, 13, 18, 46)

        self.assertEqual(convert_utc_datetime_to_str(moment), '2026-08-28T13:18:46+00:00')

    def test_a_datetime_read_from_quickbooks_keeps_its_moment(self):
        """The company of the sandbox is at -07:00, so 09:45 there is 16:45 UTC."""
        self.assertEqual(
            parse_datetime_from_str('2026-08-28T09:45:09-07:00'),
            datetime(2026, 8, 28, 16, 45, 9),
        )

    def test_an_offset_ahead_of_utc_is_read_the_same_way(self):
        self.assertEqual(
            parse_datetime_from_str('2026-08-28T23:30:00+02:00'),
            datetime(2026, 8, 28, 21, 30),
        )

    def test_a_value_already_in_utc_is_left_where_it_is(self):
        self.assertEqual(
            parse_datetime_from_str('2026-08-28T12:00:00Z'),
            datetime(2026, 8, 28, 12, 0),
        )

    def test_a_value_without_a_zone_is_taken_as_it_stands(self):
        """A plain date carries no offset and means the day it names."""
        self.assertEqual(parse_datetime_from_str('2026-08-28'), datetime(2026, 8, 28, 0, 0))

    def test_something_that_is_not_a_datetime_is_refused_quietly(self):
        self.assertFalse(parse_datetime_from_str('not a date'))
        self.assertFalse(parse_datetime_from_str(''))
        self.assertFalse(convert_utc_datetime_to_str(None))
