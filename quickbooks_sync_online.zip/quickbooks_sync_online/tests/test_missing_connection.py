# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo.tests import tagged, TransactionCase


@tagged('-at_install', 'post_install', 'qbo_missing_connection')
class TestMissingConnection(TransactionCase):
    """A company whose connection is gone or set back to draft.

    Exporting needs a connection and says so loudly. Asking whether a record
    may be exported is a different question, and its answer is simply no.
    """

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.company = cls.env['res.company'].create({'name': 'Disconnected Co'})
        cls.connection = cls.env['quickbooks.integration'].create({
            'name': 'Disconnected connection',
            'company_id': cls.company.id,
        })
        cls.product = cls.env['product.product'].create({'name': 'Disconnected product'})
        cls.partner = cls.env['res.partner'].create({'name': 'Disconnected partner'})

    def _in_company(self, record):
        return record.with_company(self.company).with_context(
            allowed_company_ids=[self.company.id])

    def test_a_draft_connection_is_not_an_active_one(self):
        self.assertEqual(self.connection.state, 'draft')
        self.assertFalse(self.company.quickbooks_integration)

    def test_the_flag_answers_instead_of_raising(self):
        self.assertFalse(self._in_company(self.product).has_quickbooks_integration)

    def test_asking_for_the_connection_still_raises(self):
        """Everything that exports needs one, so its absence stays an error."""
        with self.assertRaises(ValueError):
            self._in_company(self.product).quickbooks_integration

    def test_exporting_a_product_creates_no_job(self):
        result = self._in_company(self.product).action_export_to_quickbooks()

        self.assertEqual(result['params']['type'], 'warning')
        self.assertFalse(self.product.qbo_mapping_ids)

    def test_exporting_a_partner_creates_no_job(self):
        result = self._in_company(self.partner) \
            .with_context(with_qbo_partner_type='customer') \
            .action_export_to_quickbooks()

        self.assertEqual(result['params']['type'], 'warning')

    def test_a_warehouse_of_the_company_is_skipped(self):
        warehouse = self.env['stock.warehouse'].search([('company_id', '=', self.company.id)], limit=1)

        if not warehouse:
            self.skipTest('no warehouse on the test company')

        result = warehouse.action_export_to_quickbooks()
        self.assertEqual(result['params']['type'], 'warning')
