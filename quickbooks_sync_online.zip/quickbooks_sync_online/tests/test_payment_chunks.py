# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from unittest.mock import patch

from odoo.tests import tagged, TransactionCase
from odoo.exceptions import ValidationError


@tagged('-at_install', 'post_install', 'qbo_payment_chunks')
class TestPaymentChunks(TransactionCase):
    """Amounts a payment is exported with, document by document."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.journal = cls.env['account.journal'].search([('type', '=', 'sale')], limit=1)
        # A stored payment, not a `new()` one: the widget keys the applied
        # amount by database id, and a NewId never matches it.
        cls.bank_journal = cls.env['account.journal'].search([('type', '=', 'bank')], limit=1)
        cls.invoices = cls.env['account.move'].create([
            {'move_type': 'out_invoice', 'journal_id': cls.journal.id},
            {'move_type': 'out_invoice', 'journal_id': cls.journal.id},
            {'move_type': 'out_invoice', 'journal_id': cls.journal.id},
        ])
        cls.payment_id = 4242

    def _chunks(self, applied, total=None):
        """Run the split with `applied` standing in for the payments widget.

        Keys are indexes into `self.invoices`, a missing one is a document the
        widget has no entry of this payment for. `total` is the amount of the
        payment, and defaults to the sum of what was applied.
        """
        total = sum(applied.values()) if total is None else total

        def widget(invoice):
            index = self.invoices.ids.index(invoice.id)
            amount = applied.get(index)

            return [{'account_payment_id': self.payment_id, 'amount': amount}] if amount else []

        with patch.object(type(self.invoices), 'invoice_payments_widget_content',
                          property(widget)):
            return self.invoices._get_amount_chunks_for_qbo_payments(self.payment_id, total)

    def test_each_document_is_sent_what_was_applied_to_it(self):
        chunks = self._chunks({0: 100.0, 1: 50.0, 2: 30.0})

        self.assertEqual(chunks, [
            (self.invoices[0].id, 100.0),
            (self.invoices[1].id, 50.0),
            (self.invoices[2].id, 30.0),
        ])

    def test_the_unapplied_part_goes_to_the_last_document(self):
        """A payment of 200 applied as 100 + 30 is exported as 100 + 100.

        The lines sent to QuickBooks have to total the payment, so the 70 that
        Odoo reconciled against nothing is handed to the last document. This is
        the behaviour shipped since 2.3.0.
        """
        chunks = self._chunks({0: 100.0, 2: 30.0}, total=200.0)

        self.assertEqual([amount for __, amount in chunks], [100.0, 100.0])
        self.assertEqual(sum(amount for __, amount in chunks), 200.0)

    def test_nothing_is_added_when_the_payment_is_fully_applied(self):
        chunks = self._chunks({0: 100.0, 1: 50.0, 2: 30.0}, total=180.0)

        self.assertEqual([amount for __, amount in chunks], [100.0, 50.0, 30.0])

    def test_the_remainder_follows_the_order_of_the_recordset(self):
        """Which document is last is what decides, so the same payment read in
        the other order is exported differently. Kept as it is: changing it
        would move amounts on the invoices of customers already running it."""
        applied = {0: 100.0, 2: 30.0}

        def widget(invoice):
            amount = applied.get(self.invoices.ids.index(invoice.id))

            return [{'account_payment_id': self.payment_id, 'amount': amount}] if amount else []

        backwards = self.invoices.browse(list(reversed(self.invoices.ids)))

        with patch.object(type(self.invoices), 'invoice_payments_widget_content',
                          property(widget)):
            forwards = self.invoices._get_amount_chunks_for_qbo_payments(self.payment_id, 200.0)
            other = backwards._get_amount_chunks_for_qbo_payments(self.payment_id, 200.0)

        self.assertEqual(dict(forwards), {self.invoices[0].id: 100.0, self.invoices[2].id: 100.0})
        self.assertEqual(dict(other), {self.invoices[2].id: 30.0, self.invoices[0].id: 170.0})

    def test_a_document_without_a_matching_entry_is_skipped(self):
        chunks = self._chunks({1: 50.0})

        self.assertEqual(chunks, [(self.invoices[1].id, 50.0)])

    def test_a_payment_quickbooks_did_not_apply_is_refused(self):
        """QuickBooks drops a document that is already settled there and keeps
        the amount as an unapplied credit. The payment must not pass for
        exported while Odoo holds no link to it."""
        payment = self.env['account.payment'].new({'name': 'PAY/TEST'})
        chunks = [(self.invoices[0].id, 100.0), (self.invoices[1].id, 30.0)]

        with self.assertRaises(ValidationError) as caught:
            payment._check_qbo_payment_was_applied(chunks, self.env['qbo.map.payment'])

        self.assertIn('0 of the 2', caught.exception.args[0])

    def test_a_payment_applied_in_full_passes(self):
        payment = self.env['account.payment'].new({'name': 'PAY/TEST'})
        chunks = [(self.invoices[0].id, 100.0)]
        mappings = self.env['qbo.map.payment'].browse()

        with patch.object(type(mappings), '__len__', lambda self: len(chunks)):
            self.assertTrue(payment._check_qbo_payment_was_applied(chunks, mappings))

    def _owes(self, residuals):
        """What each document still owes, keyed by index into `self.invoices`."""
        def residual(invoice):
            return residuals.get(self.invoices.ids.index(invoice.id), 0.0)

        # Nothing may be left to recompute once the field is a property. Up to
        # Odoo 17 registering a payment writes its journal entry through
        # `_inherits`, and the `_compute_amount` queued for it assigns
        # `amount_residual` at the next flush -- onto a property with no setter.
        self.env.flush_all()

        self.patch(type(self.invoices), 'amount_residual', property(residual))

    def _payment(self, applied, amount=130.0, documents=None):
        """A payment whose documents answer the widget with `applied`.

        `qbo_reconciled_ids` is made to answer with `documents`, all three by
        default -- which is what Odoo does the moment a payment is registered
        against them, reconciled or not.
        """
        payment = self.env['account.payment'].create({
            'partner_type': 'customer',
            'amount': amount,
            'journal_id': self.bank_journal.id,
        })
        payment_id = payment.id
        documents = self.invoices if documents is None else documents

        def widget(invoice):
            amount = applied.get(self.invoices.ids.index(invoice.id))

            return [{'account_payment_id': payment_id, 'amount': amount}] if amount else []

        self.patch(type(self.invoices), 'invoice_payments_widget_content', property(widget))
        self.patch(type(payment), 'qbo_reconciled_ids', property(lambda pay: documents))

        return payment

    def test_a_reconciled_payment_applies_to_its_documents(self):
        payment = self._payment({0: 100.0, 2: 30.0})

        self.assertEqual(payment.qbo_applied_documents, [
            (self.invoices[0].id, 100.0),
            (self.invoices[2].id, 30.0),
        ])

    def test_an_unreconciled_payment_is_spread_over_what_its_documents_owe(self):
        """Odoo 18 stopped reconciling a payment at registration.

        Up to 17 `account.payment` carried its journal entry by `_inherits`, so
        the widget was filled from the start and this path never ran. Now a
        registered payment can have nothing reconciled, and the export works the
        amounts out from the documents rather than waiting for a bank statement.
        """
        payment = self._payment({}, amount=130.0)
        self._owes({0: 100.0, 1: 50.0, 2: 0.0})

        self.assertEqual(payment.qbo_applied_documents, [
            (self.invoices[0].id, 100.0),
            (self.invoices[1].id, 30.0),
        ])

    def test_one_unreconciled_document_takes_the_whole_payment(self):
        """Nearly every payment is this one, and it needs no rule at all."""
        payment = self._payment({}, amount=75.0, documents=self.invoices[0])
        self._owes({0: 500.0})

        self.assertEqual(payment.qbo_applied_documents, [(self.invoices[0].id, 75.0)])

    def test_more_than_the_documents_owe_still_totals_the_payment(self):
        """The lines have to add up to the payment QuickBooks is told about."""
        payment = self._payment({}, amount=200.0)
        self._owes({0: 60.0, 1: 40.0})

        chunks = payment.qbo_applied_documents

        self.assertEqual(sum(amount for __, amount in chunks), 200.0)
        self.assertEqual(chunks[-1], (self.invoices[1].id, 140.0))

    def test_a_reconciliation_is_preferred_over_the_estimate(self):
        """Odoo's own answer wins wherever it exists."""
        payment = self._payment({0: 10.0}, amount=10.0)
        self._owes({0: 500.0, 1: 500.0})

        self.assertEqual(payment.qbo_applied_documents, [(self.invoices[0].id, 10.0)])

    def test_documents_owing_nothing_leave_the_payment_applying_nowhere(self):
        """A payment of no lines says nothing, so it is refused in words."""
        payment = self._payment({})
        self._owes({})

        self.assertEqual(payment.qbo_applied_documents, [])

        with self.assertRaises(ValidationError) as caught:
            payment._check_qbo_requirements()

        self.assertIn('applies to nothing', caught.exception.args[0])
        self.assertIn(self.invoices[0].display_name, caught.exception.args[0])
