# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from odoo import fields, models, _
from odoo.exceptions import UserError
from ..tools import quote_qbo_query_value


class QuickbooksCustomFieldFetchWizard(models.TransientModel):
    _name = 'quickbooks.custom.field.fetch.wizard'
    _description = 'Fetch QuickBooks custom field definitions from a test transaction'

    qi_id = fields.Many2one(
        comodel_name='quickbooks.integration',
        string='Connection',
        required=True,
        ondelete='cascade',
    )
    map_type = fields.Selection(
        selection=[
            ('invoice', 'Customer Invoice'),
            ('creditmemo', 'Customer Credit Note'),
            ('bill', 'Vendor Bill'),
            ('vendorcredit', 'Vendor Refund'),
        ],
        string='Transaction Type',
        required=True,
        default='invoice',
    )
    qbo_transaction_id = fields.Char(
        string='QuickBooks Transaction ID',
        help=(
            'Numeric QuickBooks Online transaction Id used as the source of '
            'custom field definitions. Fill every current custom field on that '
            'transaction in QuickBooks Online before running this wizard.'
        ),
    )

    def open_form(self):
        self.ensure_one()

        return {
            'name': _('Import Custom Fields Definitions'),
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
            'context': self.env.context,
        }

    def _map_type_label(self):
        self.ensure_one()

        return dict(self._fields['map_type']._description_selection(self.env))[self.map_type]

    def action_process(self):
        self.ensure_one()
        qbo_transaction_id = (self.qbo_transaction_id or '').strip()
        type_label = self._map_type_label()

        if not qbo_transaction_id:
            raise UserError(_('Enter a QuickBooks transaction ID.'))
        if not qbo_transaction_id.isdigit():
            raise UserError(_('QuickBooks transaction ID must be numeric.'))

        qb = self.qi_id.get_quickbooks_api_client()

        records = self.env['qbo.map.account.move']._fetch_qbo_by_query(
            self.map_type,
            "Id = %s" % quote_qbo_query_value(qbo_transaction_id),
            client=qb,
        )
        if not records:
            raise UserError(_(
                'QuickBooks %s with ID "%s" was not found.'
            ) % (type_label, qbo_transaction_id))

        created, updated = self.qi_id.sync_custom_field_definitions_from_qbo_transaction(
            records[0].to_json(),
        )

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Custom Field Definitions Updated'),
                'message': _(
                    'Created: %(created)s, updated: %(updated)s. '
                    'Add mapping lines by hand for each transaction type.'
                ) % {
                    'created': created,
                    'updated': updated,
                },
                'type': 'success',
                'sticky': False,
                'next': {'type': 'ir.actions.act_window_close'},
            },
        }
