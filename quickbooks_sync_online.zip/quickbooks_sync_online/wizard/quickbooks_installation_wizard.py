# See LICENSE file for full copyright and licensing details.

import os
from urllib.parse import urlparse

import odoo
from odoo import fields, models, _
from odoo.tools.config import DEFAULT_SERVER_WIDE_MODULES


QUEUE_JOB_MODULE = 'integration_queue_job'
REQUIRED_MODULES = DEFAULT_SERVER_WIDE_MODULES.copy()

QUEUE_JOB_SECTION = 'queue_job'
QUEUE_JOB_KEYS = ('channels', 'scheme', 'host', 'port')
QUEUE_JOB_LEGACY_PREFIX = 'queue_job_'


class QuickbooksInstallationWizard(models.TransientModel):
    _name = 'quickbooks.installation.wizard'
    _description = 'QuickBooks Installation Wizard'

    state = fields.Selection(
        selection=[
            ('step_main', 'Main'),
            ('step_success', 'Success'),
            ('step_error', 'Error'),
        ],
        string='State',
        default='step_main',
    )

    errors = fields.Text(
        string='Errors',
        default='No errors',
    )

    config_template = fields.Text(
        string='Configuration Template',
    )

    def _parse_base_url(self):
        """
        Parse the base URL and extract scheme, host, and port.

        Returns:
            tuple: (scheme, base_url, expected_port)
        """
        full_base_url = self.get_base_url()
        parsed_url = urlparse(full_base_url)

        scheme = parsed_url.scheme or 'http'
        base_url = parsed_url.hostname or (parsed_url.netloc.split(':')[0] if parsed_url.netloc else '')

        # Extract port from URL or use protocol defaults
        if parsed_url.port:
            expected_port = parsed_url.port
        elif scheme == 'https':
            expected_port = 443
        else:
            # HTTP default port is 80, not 8069
            # Note: Odoo typically runs on 8069, but if accessed via HTTP without
            # explicit port, it's likely behind a reverse proxy on port 80
            expected_port = 80

        return scheme, base_url, expected_port

    def _is_odoosh_installation(self, base_url):
        """
        Detect if this is an Odoo.sh installation.

        Args:
            base_url (str): The base URL hostname

        Returns:
            bool: True if it's an Odoo.sh installation, False otherwise
        """
        python_path = os.environ.get('PYTHONPATH') or ''
        return '.odoo.com' in base_url or '/odoo.sh' in python_path

    def _read_queue_job_settings(self, rcfile):
        """
        Read queue_job settings from odoo.conf in both supported formats.

        Returns:
            tuple: (legacy_params, section_params)
                Each dict maps short key (channels/scheme/host/port) to a list of values
                found for that key (list length > 1 means duplicates).
        """
        legacy_params = {}
        section_params = {}
        current_section = None

        with open(rcfile, 'r') as file:
            for line in file:
                line = line.strip()
                if not line or line.startswith('#') or line.startswith(';'):
                    continue

                if line.startswith('[') and ']' in line:
                    current_section = line[1:line.index(']')].strip()
                    continue

                if '=' not in line:
                    continue

                raw_key, raw_value = line.split('=', 1)
                key = raw_key.strip()
                value = raw_value.strip()

                if current_section in (None, 'options') and key.startswith(QUEUE_JOB_LEGACY_PREFIX):
                    short_key = key[len(QUEUE_JOB_LEGACY_PREFIX):]
                    if short_key in QUEUE_JOB_KEYS:
                        legacy_params.setdefault(short_key, []).append(value)
                elif current_section == QUEUE_JOB_SECTION and key in QUEUE_JOB_KEYS:
                    section_params.setdefault(key, []).append(value)

        return legacy_params, section_params

    def _param_label(self, key, use_legacy):
        """Return the user-facing parameter name for error messages."""
        if use_legacy:
            return f'{QUEUE_JOB_LEGACY_PREFIX}{key}'
        return key

    def _validate_queue_job_params(self, params, scheme, base_url, expected_port, use_legacy):
        """
        Validate presence and values of queue_job parameters for one format.

        Args:
            params (dict): short key -> list of values
            scheme (str): Expected scheme (http/https)
            base_url (str): Expected hostname
            expected_port (int): Expected port number
            use_legacy (bool): Whether params come from legacy queue_job_* keys

        Returns:
            list: List of error messages
        """
        errors = []

        for key in QUEUE_JOB_KEYS:
            label = self._param_label(key, use_legacy)
            values = params.get(key) or []

            if not values:
                if use_legacy:
                    errors.append(f'The "{label}" parameter is not set in the "odoo.conf"')
                else:
                    errors.append(
                        f'The "{label}" parameter is not set in the "[{QUEUE_JOB_SECTION}]" '
                        f'section of the "odoo.conf"'
                    )
                continue

            if len(values) > 1:
                errors.append(f'Multiple "{label}" parameters found in the "odoo.conf"')

            param_value = values[0]
            if key == 'host':
                if '//' in param_value:
                    errors.append(
                        f'The "{label}" parameter in the "odoo.conf" is not set correctly '
                        f'(should not contain protocol)'
                    )
                elif param_value != base_url:
                    errors.append(
                        f'The "{label}" parameter in the "odoo.conf" is not set correctly '
                        f'(expected: {base_url})'
                    )
            elif key == 'scheme':
                if param_value != scheme:
                    errors.append(
                        f'The "{label}" parameter in the "odoo.conf" is not set correctly '
                        f'(expected: {scheme})'
                    )
            elif key == 'port':
                try:
                    port_value = int(param_value)
                    if port_value != expected_port:
                        errors.append(
                            f'The "{label}" parameter in the "odoo.conf" is not set correctly '
                            f'(expected: {expected_port})'
                        )
                except ValueError:
                    errors.append(
                        f'The "{label}" parameter in the "odoo.conf" is not set correctly '
                        f'(must be a number)'
                    )

        return errors

    def _check_queue_job_config(self, scheme, base_url, expected_port):
        """
        Check queue_job configuration parameters in odoo.conf.

        Accepts either a complete legacy layout (queue_job_* under [options]) or a
        complete [queue_job] section. Mixed formats are rejected. On failure the
        caller shows the new-style [queue_job] template.

        Args:
            scheme (str): Expected scheme (http/https)
            base_url (str): Expected hostname
            expected_port (int): Expected port number

        Returns:
            list: List of error messages
        """
        config_path = odoo.tools.config['config']

        if not config_path or not os.path.isfile(config_path):
            return []

        legacy_params, section_params = self._read_queue_job_settings(config_path)

        if legacy_params and section_params:
            return [
                'Mixed queue_job configuration formats found in the "odoo.conf". '
                'Use either the legacy queue_job_* parameters under [options], '
                f'or the [{QUEUE_JOB_SECTION}] section — not both.'
            ]

        if section_params:
            return self._validate_queue_job_params(
                section_params, scheme, base_url, expected_port, use_legacy=False,
            )

        if legacy_params:
            return self._validate_queue_job_params(
                legacy_params, scheme, base_url, expected_port, use_legacy=True,
            )

        # Nothing configured: report missing new-style keys (template uses that format)
        return [
            f'The "{key}" parameter is not set in the "[{QUEUE_JOB_SECTION}]" '
            f'section of the "odoo.conf"'
            for key in QUEUE_JOB_KEYS
        ]

    def _check_server_wide_modules(self):
        """
        Check server-wide modules configuration and build ordered modules string.

        Returns:
            tuple: (errors, modules_str)
                - errors: List of error messages
                - modules_str: Comma-separated string of modules in correct order
        """
        errors = []
        config = odoo.tools.config

        server_wide_modules = config.options.get('server_wide_modules') or []

        # Report errors for missing modules
        if QUEUE_JOB_MODULE not in server_wide_modules:
            errors.append('The necessary module is not set as a server-wide module in the "odoo.conf"')

        modules_list = [m for m in server_wide_modules if m not in REQUIRED_MODULES]

        if QUEUE_JOB_MODULE not in modules_list:
            modules_list.insert(0, QUEUE_JOB_MODULE)

        modules_str = ','.join([*REQUIRED_MODULES, *modules_list])
        return errors, modules_str

    def _build_config_template(self, scheme, base_url, expected_port, is_odoosh, modules_str):
        """
        Build the configuration template for odoo.conf using the [queue_job] section.

        Args:
            scheme (str): URL scheme (http/https)
            base_url (str): Hostname
            expected_port (int): Port number
            is_odoosh (bool): Whether this is an Odoo.sh installation
            modules_str (str): Comma-separated modules string
        """
        server_wide_modules_str = 'server_wide_modules = ' + modules_str + '\n'

        config_lines = [
            server_wide_modules_str,
        ]

        # Add workers line only for custom/on-premise servers (not for Odoo.sh)
        if not is_odoosh:
            config_lines.append('workers = 2 ; set here amount of workers higher than 1\n')

        # Prefer the [queue_job] section; keep it at the end of odoo.conf
        config_lines.extend([
            f'\n; Keep the [{QUEUE_JOB_SECTION}] section at the end of the file\n',
            f'[{QUEUE_JOB_SECTION}]\n',
            'channels = root:1\n',
            f'scheme = {scheme}\n',
            f'host = {base_url}\n',
            f'port = {expected_port}\n',
        ])

        self.config_template = ''.join(config_lines)

    def check_odoo_setup_for_quickbooks(self):
        """
        Check if the Odoo setup is compatible with the integration.

        This method checks if the Odoo configuration file (odoo.conf) contains a valid
        queue_job configuration: either legacy queue_job_* keys under [options], or a
        [queue_job] section (channels, scheme, host, port). Values must match the base
        URL of the Odoo instance. Valid legacy config is accepted without suggesting
        migration; any failure shows the new-style [queue_job] template. It also checks
        that integration_queue_job is installed as a server-wide module.

        Returns:
            dict: Action dictionary to open the wizard window.
        """
        # Parse base URL
        scheme, base_url, expected_port = self._parse_base_url()

        # Detect installation type
        is_odoosh = self._is_odoosh_installation(base_url)

        # Check queue_job configuration
        errors = self._check_queue_job_config(scheme, base_url, expected_port)

        # Check server-wide modules
        module_errors, modules_str = self._check_server_wide_modules()
        errors.extend(module_errors)

        # Build configuration template and set state
        if errors:
            self._build_config_template(scheme, base_url, expected_port, is_odoosh, modules_str)
            self.errors = ''.join([f'- {e}\n' for e in set(errors)])
            self.state = 'step_error'
        else:
            self.state = 'step_success'

        return {
            'type': 'ir.actions.act_window',
            'name': _('Let\'s ensure a seamless setup!'),
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
        }

    def close_wizard(self):
        return {
            'type': 'ir.actions.act_url',
            'url': '/odoo/qi-connection',
            'target': 'self',
        }
