# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

import re
from datetime import timedelta

from odoo import fields, models, _
from odoo.exceptions import UserError

from ..quickbooks_api import QBO_MAX_RESULTS
from ..tools import convert_utc_datetime_to_str, qbo_query_id_list, quote_qbo_query_value


# A date range is walked page by page while the user waits for the form, so it
# has to end well before the request does.
MAX_FETCHED_DOCUMENTS = 1000


class QuickbooksInvoiceImport(models.TransientModel):
    _name = 'quickbooks.invoice.import'
    _description = 'Import invoices or bills from QuickBooks by ID'

    qi_id = fields.Many2one(
        comodel_name='quickbooks.integration',
        string='Connection',
        required=True,
    )

    fetch_method = fields.Selection(
        selection=[
            ('by_dates', 'By Date Range'),
            ('by_ids', 'By IDs'),
        ],
        string='Fetch Method',
        default='by_dates',
        required=True,
    )

    ttype = fields.Selection(
        selection=[
            ('invoice', 'Customer Invoice'),
            ('creditmemo', 'Customer Credit Note'),
        ],
        string='Type',
        default='invoice',
        required=True,
    )

    external_ids = fields.Char(
        string='IDs',
        help='QuickBooks numeric document IDs separated by commas.',
    )

    datetime_start = fields.Datetime(
        string='Start',
        default=lambda self: fields.Datetime.now() - timedelta(days=1),
    )

    datetime_end = fields.Datetime(
        string='End',
        default=fields.Datetime.now,
    )

    mapping_ids = fields.Many2many(
        comodel_name='qbo.map.account.move',
        string='Mappings',
    )

    @property
    def is_fetch_by_ids(self):
        return self.fetch_method == 'by_ids'

    def action_process_in_odoo(self):
        self.ensure_one()

        for mapping in self.mapping_ids:
            mapping.process_in_odoo_with_delay()

        return self.action_display_notification_and_open_form_view()

    def action_fetch(self):
        self.ensure_one()

        if self.is_fetch_by_ids:
            record_list = self._fetch_records_by_ids()
        else:
            record_list = self._fetch_records_by_date_range()

        mappings = []

        qi_id = self.qi_id.id
        MapInvoice = self.env['qbo.map.account.move']

        for qbo_lib_class in record_list:
            mapping = MapInvoice \
                .with_context(default_is_imported=True) \
                .get_or_create_qbo_mapping_from_response(qbo_lib_class, qi_id, odoo_id=None)

            mappings.append(mapping.id)

        self.mapping_ids = [(6, 0, mappings)]

        return self.open_form_view()

    def unlink_fetched_mappings(self):
        self.mapping_ids.filtered(lambda x: not x.invoice_id).unlink()
        return self.open_form_view()

    def _fetch_records_by_ids(self):
        ids = self._parse_external_id_list()

        if not ids:
            raise UserError(_('Enter at least one QuickBooks external ID.'))

        qb = self.qi_id.get_quickbooks_api_client()

        condition = 'Id IN (%s)' % qbo_query_id_list(ids)
        result = self.env['qbo.map.account.move']._fetch_qbo_by_query(
            self.ttype,
            condition,
            client=qb,
        )

        return result

    def _fetch_records_by_date_range(self):
        start_date = self.datetime_start
        if not start_date:
            raise UserError(_('Please set start datetime point.'))

        end_date = self.datetime_end
        if not end_date:
            end_date = fields.Datetime.now()

        if start_date > end_date:
            raise UserError(_('The start datetime point must be before the end datetime point.'))

        start_qb = convert_utc_datetime_to_str(start_date)

        end_qb = convert_utc_datetime_to_str(end_date)

        if not start_qb:
            raise UserError(_('Could not format start datetime point for QuickBooks.'))
        if not end_qb:
            raise UserError(_('Could not format end datetime point for QuickBooks.'))

        result, position = [], 1

        qb = self.qi_id.get_quickbooks_api_client()

        while True:
            condition = (
                'MetaData.LastUpdatedTime >= %s AND MetaData.LastUpdatedTime <= %s '
                'ORDERBY MetaData.LastUpdatedTime ASC '
                'MAXRESULTS %s STARTPOSITION %s' % (
                    quote_qbo_query_value(start_qb),
                    quote_qbo_query_value(end_qb),
                    QBO_MAX_RESULTS,
                    position,
                )
            )
            batch = self.env['qbo.map.account.move']._fetch_qbo_by_query(
                self.ttype,
                condition,
                client=qb,
            )

            if not batch:
                break

            result.extend(batch)

            if len(result) >= MAX_FETCHED_DOCUMENTS:
                raise UserError(_(
                    'This date range holds more than %s documents. '
                    'QuickBooks hands them over a hundred at a time and the whole walk '
                    'happens while you wait, so pick a narrower range.'
                ) % MAX_FETCHED_DOCUMENTS)

            if len(batch) < QBO_MAX_RESULTS:
                break

            position += len(batch)

        return result

    def _parse_external_id_list(self):
        value = self.external_ids
        if not value:
            return []

        # Allow inputs like "(123, 124)", "[34534, 4353]".
        value = re.sub(r'[\[\]\(\)\{\}]', '', value)

        ids = []
        for line in value.strip().split(','):
            ids.extend(
                line.strip().split(' ')
            )

        return list(filter(None, ids))

    def open_form_view(self):
        self.ensure_one()
        view = self.env.ref('quickbooks_sync_online.quickbooks_invoice_import_form_view')

        return {
            'type': 'ir.actions.act_window',
            'name': _('QuickBooks Invoices: manual import'),
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'views': [(view.id, 'form')],
            'target': 'new',
        }

    def action_display_notification_and_open_form_view(self, name: str = ''):
        if name:
            message = _('Create in Odoo Job was created for %s') % name
        else:
            message = _('Create in Odoo Jobs were created')

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'message': message,
                'type': 'success',
                'sticky': False,
                'next': self.open_form_view(),
            }
        }
