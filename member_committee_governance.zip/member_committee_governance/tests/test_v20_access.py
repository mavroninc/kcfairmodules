# -*- coding: utf-8 -*-
"""v20 access check: every access row of the 19 ir.model.access.csv must still
hold after the move to ir.access. Each row is checked with a real user that
holds the row's group (no sudo), through has_access, and the expected answer
is the union of the 19 rows of every group that user really holds, so a lost
row (False instead of True) and a widened one (True instead of False) both
fail. A plain internal user is checked against the same table."""
from odoo.tests.common import TransactionCase, new_test_user, tagged

# (19 xml id, model, group, operations among c/r/u/d)
ROWS_19 = [
    ('access_member_committee_user', 'member.committee', 'member_committee_governance.group_governance_user', 'r'),
    ('access_member_committee_manager', 'member.committee', 'member_committee_governance.group_governance_manager', 'crud'),
    ('access_member_committee_seat_user', 'member.committee.seat', 'member_committee_governance.group_governance_user', 'r'),
    ('access_member_committee_seat_manager', 'member.committee.seat', 'member_committee_governance.group_governance_manager', 'crud'),
    ('access_member_election_user', 'member.election', 'member_committee_governance.group_governance_user', 'r'),
    ('access_member_election_manager', 'member.election', 'member_committee_governance.group_governance_manager', 'crud'),
    ('access_member_election_candidate_user', 'member.election.candidate', 'member_committee_governance.group_governance_user', 'r'),
    ('access_member_election_candidate_manager', 'member.election.candidate', 'member_committee_governance.group_governance_manager', 'crud'),
    ('access_member_election_ballot_user', 'member.election.ballot', 'member_committee_governance.group_governance_user', 'cru'),
    ('access_member_election_ballot_manager', 'member.election.ballot', 'member_committee_governance.group_governance_manager', 'crud'),
    ('access_member_motion_user', 'member.motion', 'member_committee_governance.group_governance_user', 'r'),
    ('access_member_motion_manager', 'member.motion', 'member_committee_governance.group_governance_manager', 'crud'),
    ('access_member_meeting_minutes_user', 'member.meeting.minutes', 'member_committee_governance.group_governance_user', 'r'),
    ('access_member_meeting_minutes_manager', 'member.meeting.minutes', 'member_committee_governance.group_governance_manager', 'crud'),
    ('access_member_officer_succession_user', 'member.officer.succession', 'member_committee_governance.group_governance_user', 'r'),
    ('access_member_officer_succession_manager', 'member.officer.succession', 'member_committee_governance.group_governance_manager', 'crud')
]
OPERATIONS = (("read", "r"), ("write", "u"), ("create", "c"), ("unlink", "d"))


@tagged("post_install", "-at_install")
class TestV20Access(TransactionCase):

    def _user_for(self, group):
        login = "v20acc_" + group.replace(".", "_")
        groups = group if group == "base.group_portal" else "base.group_user," + group
        return new_test_user(self.env, login=login, groups=groups)

    def _expected(self, user, model):
        ops = set()
        for _xid, row_model, row_group, row_ops in ROWS_19:
            if row_model == model and user.has_group(row_group):
                ops |= set(row_ops)
        return ops

    def _assert_user(self, user):
        for model in sorted({row[1] for row in ROWS_19}):
            expected = self._expected(user, model)
            for operation, letter in OPERATIONS:
                self.assertEqual(
                    self.env[model].with_user(user).has_access(operation), letter in expected,
                    "%s %s %s" % (user.login, model, operation))

    def test_every_19_row_holds_for_its_group(self):
        for group in sorted({row[2] for row in ROWS_19}):
            with self.subTest(group=group):
                self._assert_user(self._user_for(group))

    def test_plain_internal_user(self):
        self._assert_user(new_test_user(self.env, login="v20acc_plain", groups="base.group_user"))
