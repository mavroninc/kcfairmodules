from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError, ValidationError


class TestMotion(TransactionCase):
    """Motion register: mover/seconder attendance rules, quorum-first
    outcome logic and ordinary vs. special-resolution thresholds."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.Committee = cls.env["member.committee"]
        cls.Minutes = cls.env["member.meeting.minutes"]
        cls.Motion = cls.env["member.motion"]
        cls.Partner = cls.env["res.partner"]

        cls.committee = cls.Committee.create({
            "name": "Motion Test Board", "max_seats": 6,
            "term_length_months": 24, "quorum_percent": 50.0,
        })

        def make_partner(name):
            return cls.Partner.create({
                "name": name, "is_governance_member": True,
                "member_in_good_standing": True,
            })

        cls.chair = make_partner("Motion Chair")
        cls.member_a = make_partner("Motion Member A")
        cls.member_b = make_partner("Motion Member B")
        cls.outsider = make_partner("Non-Attendee")

    def _meeting_with_quorum(self, quorum_met=True):
        """A meeting whose (fixed, un-frozen) quorum_met flag comes out as
        requested: 4 active seats total; 3 attendees for quorum, 1 for not."""
        for i, partner in enumerate((self.chair, self.member_a, self.member_b)):
            self.env["member.committee.seat"].create({
                "committee_id": self.committee.id,
                "partner_id": partner.id,
                "role": "member" if i else "chair",
                "term_start": "2026-01-01", "term_end": "2028-01-01",
            })
        attendees = (
            (self.chair | self.member_a | self.member_b)
            if quorum_met else self.chair
        )
        return self.Minutes.create({
            "committee_id": self.committee.id,
            "meeting_date": "2026-06-01",
            "attendee_ids": [(6, 0, attendees.ids)],
        })

    def test_motion_carried_simple_majority(self):
        meeting = self._meeting_with_quorum(True)
        motion = self.Motion.create({
            "meeting_id": meeting.id, "name": "Adopt Budget",
            "mover_id": self.chair.id, "seconder_id": self.member_a.id,
        })
        outcome = motion.action_record_vote(6, 4, 0)
        self.assertEqual(outcome, "carried")
        self.assertEqual(motion.outcome, "carried")
        self.assertEqual(motion.state, "voted")
        self.assertEqual(motion.total_votes_cast, 10)

    def test_motion_defeated_simple_majority(self):
        meeting = self._meeting_with_quorum(True)
        motion = self.Motion.create({
            "meeting_id": meeting.id, "name": "Reject Proposal",
            "mover_id": self.chair.id, "seconder_id": self.member_a.id,
        })
        outcome = motion.action_record_vote(3, 7, 0)
        self.assertEqual(outcome, "defeated")

    def test_special_resolution_needs_supermajority(self):
        meeting = self._meeting_with_quorum(True)
        motion = self.Motion.create({
            "meeting_id": meeting.id, "name": "Amend Bylaws",
            "mover_id": self.chair.id, "seconder_id": self.member_a.id,
            "motion_type": "special", "approval_threshold_percent": 66.67,
        })
        # 60% for: passes an ordinary vote but not a two-thirds resolution.
        outcome = motion.action_record_vote(6, 4, 0)
        self.assertEqual(outcome, "defeated")

    def test_no_quorum_defeats_regardless_of_votes(self):
        meeting = self._meeting_with_quorum(False)
        self.assertFalse(meeting.quorum_met)
        motion = self.Motion.create({
            "meeting_id": meeting.id, "name": "Emergency Motion",
            "mover_id": self.chair.id,
        })
        outcome = motion.action_record_vote(10, 0, 0)
        self.assertEqual(outcome, "no_quorum")

    def test_mover_and_seconder_must_be_distinct(self):
        meeting = self._meeting_with_quorum(True)
        with self.assertRaises(ValidationError):
            self.Motion.create({
                "meeting_id": meeting.id, "name": "Self-Seconded",
                "mover_id": self.chair.id, "seconder_id": self.chair.id,
            })

    def test_mover_must_have_attended(self):
        meeting = self._meeting_with_quorum(True)
        with self.assertRaises(ValidationError):
            self.Motion.create({
                "meeting_id": meeting.id, "name": "Outsider Motion",
                "mover_id": self.outsider.id,
            })

    def test_withdrawn_motion_cannot_be_voted(self):
        meeting = self._meeting_with_quorum(True)
        motion = self.Motion.create({
            "meeting_id": meeting.id, "name": "Tabled Then Withdrawn",
            "mover_id": self.chair.id,
        })
        motion.action_table()
        self.assertEqual(motion.state, "tabled")
        motion.action_withdraw()
        self.assertEqual(motion.state, "withdrawn")
        with self.assertRaises(UserError):
            motion.action_record_vote(5, 0, 0)
