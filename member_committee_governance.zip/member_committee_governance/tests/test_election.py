from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError, ValidationError


class TestElection(TransactionCase):
    """Nomination -> voting -> tally workflow: eligibility gating,
    quorum, exact-tie handling and seat creation from winners."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.Committee = cls.env["member.committee"]
        cls.Election = cls.env["member.election"]
        cls.Candidate = cls.env["member.election.candidate"]
        cls.Ballot = cls.env["member.election.ballot"]
        cls.Partner = cls.env["res.partner"]

        cls.committee = cls.Committee.create({
            "name": "Election Test Board", "max_seats": 5,
            "term_length_months": 24, "max_consecutive_terms": 2,
            "quorum_percent": 50.0,
        })

        def make_voter(name):
            return cls.Partner.create({
                "name": name, "is_governance_member": True,
                "member_in_good_standing": True,
            })

        cls.voters = cls.Partner
        cls.names = ["V1", "V2", "V3", "V4", "V5", "V6"]
        for n in cls.names:
            setattr(cls, n.lower(), make_voter(f"Voter {n}"))
            cls.voters |= getattr(cls, n.lower())

    def _new_election(self, seats=1, quorum=50.0):
        return self.Election.create({
            "name": "Test Election", "committee_id": self.committee.id,
            "role": "member", "seats_available": seats,
            "quorum_percent": quorum,
            "nomination_start": "2026-05-01", "nomination_end": "2026-05-15",
            "voting_start": "2026-05-16", "voting_end": "2026-05-30",
        })

    def test_full_workflow_produces_winner_and_seat(self):
        election = self._new_election(seats=1)
        cand_v5 = self.Candidate.create({
            "election_id": election.id, "partner_id": self.v5.id,
        })
        cand_v6 = self.Candidate.create({
            "election_id": election.id, "partner_id": self.v6.id,
        })
        election.action_open_nominations()
        election.action_start_voting()
        self.assertEqual(election.electorate_count, 6)

        # 4 votes for v5, 2 for v6.
        for voter in (self.v1, self.v2, self.v3, self.v6):
            self.Ballot.create({
                "election_id": election.id, "voter_id": voter.id,
                "candidate_ids": [(6, 0, [cand_v5.id])],
            })
        for voter in (self.v4, self.v5):
            self.Ballot.create({
                "election_id": election.id, "voter_id": voter.id,
                "candidate_ids": [(6, 0, [cand_v6.id])],
            })
        election.action_close_voting()
        self.assertTrue(election.quorum_met)
        self.assertEqual(election.ballot_count, 6)
        self.assertAlmostEqual(election.turnout_percent, 100.0)
        self.assertEqual(election.winner_ids, self.v5)
        self.assertFalse(election.needs_manual_tiebreak)
        self.assertEqual(cand_v5.vote_count, 4)
        self.assertEqual(cand_v6.vote_count, 2)

        seats = election.action_create_seats_from_winners()
        self.assertEqual(len(seats), 1)
        self.assertEqual(seats.partner_id, self.v5)
        self.assertEqual(seats.role, "member")
        self.assertEqual(str(seats.term_start), "2026-05-30")

    def test_quorum_failure_blocks_seat_creation(self):
        election = self._new_election(seats=1, quorum=80.0)
        cand = self.Candidate.create({
            "election_id": election.id, "partner_id": self.v1.id,
        })
        election.action_open_nominations()
        election.action_start_voting()
        # Only 1 of 6 electors votes: 16.7% turnout, below the 80% quorum.
        self.Ballot.create({
            "election_id": election.id, "voter_id": self.v2.id,
            "candidate_ids": [(6, 0, [cand.id])],
        })
        election.action_close_voting()
        self.assertFalse(election.quorum_met)
        self.assertFalse(election.winner_ids)
        with self.assertRaises(UserError):
            election.action_create_seats_from_winners()

    def test_exact_tie_is_flagged_not_guessed(self):
        # A low but valid (>0) quorum so a 4-of-6 turnout easily clears it.
        election = self._new_election(seats=1, quorum=1.0)
        cand_a = self.Candidate.create({
            "election_id": election.id, "partner_id": self.v1.id,
        })
        cand_b = self.Candidate.create({
            "election_id": election.id, "partner_id": self.v2.id,
        })
        election.action_open_nominations()
        election.action_start_voting()
        for voter in (self.v3, self.v5):
            self.Ballot.create({
                "election_id": election.id, "voter_id": voter.id,
                "candidate_ids": [(6, 0, [cand_a.id])],
            })
        for voter in (self.v4, self.v6):
            self.Ballot.create({
                "election_id": election.id, "voter_id": voter.id,
                "candidate_ids": [(6, 0, [cand_b.id])],
            })
        election.action_close_voting()
        self.assertTrue(election.quorum_met)
        self.assertTrue(election.needs_manual_tiebreak)
        self.assertFalse(election.winner_ids)
        self.assertEqual(len(election.tie_candidate_ids), 2)
        with self.assertRaises(UserError):
            election.action_create_seats_from_winners()

    def test_not_enough_standing_candidates_blocks_voting(self):
        election = self._new_election(seats=2)
        self.Candidate.create({
            "election_id": election.id, "partner_id": self.v1.id,
        })
        election.action_open_nominations()
        with self.assertRaises(UserError):
            election.action_start_voting()

    def test_duplicate_candidacy_blocked(self):
        election = self._new_election(seats=1)
        self.Candidate.create({
            "election_id": election.id, "partner_id": self.v1.id,
        })
        with self.assertRaises(ValidationError):
            self.Candidate.create({
                "election_id": election.id, "partner_id": self.v1.id,
            })

    def test_ballot_requires_voting_state(self):
        election = self._new_election(seats=1)
        cand = self.Candidate.create({
            "election_id": election.id, "partner_id": self.v1.id,
        })
        # Still in 'draft': casting a ballot must fail.
        with self.assertRaises(UserError):
            self.Ballot.create({
                "election_id": election.id, "voter_id": self.v2.id,
                "candidate_ids": [(6, 0, [cand.id])],
            })

    def test_one_ballot_per_voter(self):
        election = self._new_election(seats=1)
        cand_a = self.Candidate.create({
            "election_id": election.id, "partner_id": self.v1.id,
        })
        cand_b = self.Candidate.create({
            "election_id": election.id, "partner_id": self.v2.id,
        })
        election.action_open_nominations()
        election.action_start_voting()
        self.Ballot.create({
            "election_id": election.id, "voter_id": self.v3.id,
            "candidate_ids": [(6, 0, [cand_a.id])],
        })
        with self.assertRaises(ValidationError):
            self.Ballot.create({
                "election_id": election.id, "voter_id": self.v3.id,
                "candidate_ids": [(6, 0, [cand_b.id])],
            })
