# -*- coding: utf-8 -*-
"""GT 2026-10 regression tests: contact form for users outside the module,
group wiring, the term-expiry scheduled action, per-person term limits on
multi-seat roles and frozen meeting minutes."""
from lxml import etree

from odoo.exceptions import ValidationError
from odoo.tests.common import TransactionCase, new_test_user, tagged


@tagged("post_install", "-at_install")
class TestGovernanceGt202610(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.Seat = cls.env["member.committee.seat"]
        cls.committee = cls.env["member.committee"].create({
            "name": "GT Board",
            "max_seats": 7,
            "term_length_months": 24,
            "max_consecutive_terms": 2,
            "quorum_percent": 50.0,
        })

        def member(name):
            return cls.env["res.partner"].create({
                "name": name, "is_governance_member": True, "member_in_good_standing": True,
            })

        cls.a = member("GT Member A")
        cls.b = member("GT Member B")
        cls.c = member("GT Member C")

    def _seat(self, partner, start, end, role="member"):
        return self.Seat.create({
            "committee_id": self.committee.id, "partner_id": partner.id,
            "role": role, "term_start": start, "term_end": end,
        })

    # ------------------------------------------------------------------
    # Access
    # ------------------------------------------------------------------
    def test_user_without_governance_role_opens_a_contact(self):
        plain = new_test_user(self.env, login="gt_gov_plain", groups="base.group_user")
        self._seat(self.a, "2030-01-01", "2031-12-31")
        views = self.env["res.partner"].with_user(plain).get_views([(False, "form")])
        # The fields the web client reads come from the arch served to this
        # user (filtered by groups), not from the unfiltered ``models`` list.
        arch = etree.fromstring(views["views"]["form"]["arch"])
        served = {node.get("name") for node in arch.xpath("//field[not(ancestor::field)]")}
        # Only the fields this module adds to the contact: other installed
        # apps (fleet on Odoo 20) bring their own group-less counters.
        ours = {
            "is_governance_member", "member_in_good_standing", "membership_join_date",
            "member_number", "committee_seat_ids", "committee_seat_count",
            "election_candidacy_ids", "election_candidacy_count", "ballot_ids", "ballot_count",
        }
        fnames = sorted(served & ours) + ["name"]
        self.assertIn("is_governance_member", fnames)
        # Reading every field of ours that the form asks for must not raise.
        values = self.a.with_user(plain).read(fnames)
        self.assertEqual(values[0]["name"], "GT Member A")

    def test_admin_holds_governance_administrator(self):
        admin = self.env.ref("base.user_admin")
        self.assertTrue(admin.has_group("member_committee_governance.group_governance_manager"))
        menu = self.env.ref("member_committee_governance.menu_governance_committee")
        self.assertIn(menu.id, self.env["ir.ui.menu"].with_user(admin)._visible_menu_ids())

    def test_officer_still_sees_the_seat_counter(self):
        # Counter-case: the governance group keeps the contact smart button.
        officer = new_test_user(self.env, login="gt_gov_officer",
                                groups="base.group_user,member_committee_governance.group_governance_user")
        self._seat(self.a, "2030-01-01", "2031-12-31")
        self.assertEqual(self.a.with_user(officer).committee_seat_count, 1)

    # ------------------------------------------------------------------
    # Term expiry runs on its own
    # ------------------------------------------------------------------
    def test_term_expiry_is_scheduled(self):
        cron = self.env.ref("member_committee_governance.ir_cron_expire_terms")
        self.assertTrue(cron.active)
        self.assertIn("cron_expire_terms", cron.code)
        seat = self._seat(self.a, "2020-01-01", "2021-12-31")
        self.Seat.cron_expire_terms()
        self.assertEqual(seat.status, "term_ended")

    # ------------------------------------------------------------------
    # Term limit per person on a multi-seat role
    # ------------------------------------------------------------------
    def test_member_term_limit_counts_the_same_person(self):
        self._seat(self.a, "2020-01-01", "2021-12-31")
        self._seat(self.b, "2020-06-01", "2022-05-31")
        second = self._seat(self.a, "2022-01-01", "2023-12-31")
        self.assertEqual(second.term_number, 2)
        with self.assertRaises(ValidationError):
            self._seat(self.a, "2024-01-01", "2025-12-31")

    def test_member_after_a_real_gap_starts_again(self):
        # Counter-case: a break longer than the gap allowance resets the count.
        self._seat(self.a, "2016-01-01", "2017-12-31")
        self._seat(self.a, "2018-01-01", "2019-12-31")
        third = self._seat(self.a, "2021-01-01", "2022-12-31")
        self.assertEqual(third.term_number, 1)

    # ------------------------------------------------------------------
    # Confirmed minutes are history
    # ------------------------------------------------------------------
    def test_confirmed_minutes_keep_quorum_and_officers(self):
        chair = self._seat(self.a, "2030-01-01", "2031-12-31", role="chair")
        seat_b = self._seat(self.b, "2030-01-01", "2031-12-31")
        self._seat(self.c, "2030-01-01", "2031-12-31")
        minutes = self.env["member.meeting.minutes"].create({
            "committee_id": self.committee.id,
            "meeting_date": "2030-03-01",
            "attendee_ids": [(6, 0, [self.a.id, self.b.id])],
        })
        self.assertTrue(minutes.quorum_met)
        minutes.action_confirm()
        chair.action_resign()
        seat_b.action_resign()
        self.assertTrue(minutes.quorum_met)
        self.assertEqual(minutes.voting_attendee_count, 2)
        self.assertEqual(minutes.chair_id, self.a)

    def test_draft_minutes_follow_the_current_seats(self):
        # Counter-case: an unconfirmed meeting still reflects today's seats.
        self._seat(self.a, "2030-01-01", "2031-12-31")
        seat_b = self._seat(self.b, "2030-01-01", "2031-12-31")
        self._seat(self.c, "2030-01-01", "2031-12-31")
        minutes = self.env["member.meeting.minutes"].create({
            "committee_id": self.committee.id,
            "meeting_date": "2030-03-01",
            "attendee_ids": [(6, 0, [self.b.id])],
        })
        self.assertFalse(minutes.quorum_met)
        seat_b.action_resign()
        self.assertEqual(minutes.voting_attendee_count, 0)
