from odoo.tests.common import TransactionCase
from odoo.exceptions import ValidationError


class TestCommitteeSeat(TransactionCase):
    """Seat cap, singular-role, consecutive-term-limit and succession
    bookkeeping, all exercised against a fresh, demo-free committee."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.Committee = cls.env["member.committee"]
        cls.Seat = cls.env["member.committee.seat"]
        cls.Succession = cls.env["member.officer.succession"]
        cls.Partner = cls.env["res.partner"]

        cls.committee = cls.Committee.create({
            "name": "Test Board",
            "max_seats": 3,
            "term_length_months": 24,
            "max_consecutive_terms": 2,
            "quorum_percent": 50.0,
        })

        def make_partner(name):
            return cls.Partner.create({
                "name": name, "is_governance_member": True,
                "member_in_good_standing": True,
            })

        cls.p1 = make_partner("Term Test One")
        cls.p2 = make_partner("Term Test Two")
        cls.p3 = make_partner("Term Test Three")
        cls.p4 = make_partner("Term Test Four")
        cls.ineligible = cls.Partner.create({
            "name": "Lapsed Member", "is_governance_member": True,
            "member_in_good_standing": False,
        })

    def test_term_end_must_be_after_start(self):
        with self.assertRaises(ValidationError):
            self.Seat.create({
                "committee_id": self.committee.id,
                "partner_id": self.p1.id,
                "role": "member",
                "term_start": "2026-01-01",
                "term_end": "2025-01-01",
            })

    def test_seat_cap_enforced(self):
        for partner in (self.p1, self.p2, self.p3):
            self.Seat.create({
                "committee_id": self.committee.id,
                "partner_id": partner.id,
                "role": "member",
                "term_start": "2026-01-01",
                "term_end": "2028-01-01",
            })
        self.assertEqual(self.committee.active_seat_count, 3)
        with self.assertRaises(ValidationError):
            self.Seat.create({
                "committee_id": self.committee.id,
                "partner_id": self.p4.id,
                "role": "member",
                "term_start": "2026-01-01",
                "term_end": "2028-01-01",
            })

    def test_singular_role_conflict(self):
        self.Seat.create({
            "committee_id": self.committee.id,
            "partner_id": self.p1.id,
            "role": "chair",
            "term_start": "2026-01-01",
            "term_end": "2028-01-01",
        })
        with self.assertRaises(ValidationError):
            self.Seat.create({
                "committee_id": self.committee.id,
                "partner_id": self.p2.id,
                "role": "chair",
                "term_start": "2026-01-01",
                "term_end": "2028-01-01",
            })

    def test_ineligible_partner_blocked(self):
        with self.assertRaises(ValidationError):
            self.Seat.create({
                "committee_id": self.committee.id,
                "partner_id": self.ineligible.id,
                "role": "member",
                "term_start": "2026-01-01",
                "term_end": "2028-01-01",
            })

    def test_consecutive_term_counting_and_limit(self):
        seat_a = self.Seat.create({
            "committee_id": self.committee.id,
            "partner_id": self.p1.id,
            "role": "vice_chair",
            "term_start": "2020-01-01",
            "term_end": "2022-01-01",
        })
        self.assertEqual(seat_a.term_number, 1)
        seat_a.action_end_term()
        self.assertEqual(seat_a.status, "term_ended")

        # Back-to-back (within the 45-day grace window): consecutive term 2.
        seat_b = self.Seat.create({
            "committee_id": self.committee.id,
            "partner_id": self.p1.id,
            "role": "vice_chair",
            "term_start": "2022-02-01",
            "term_end": "2024-02-01",
        })
        self.assertEqual(seat_b.term_number, 2)
        seat_b.action_end_term()

        # A third consecutive term exceeds max_consecutive_terms=2.
        with self.assertRaises(ValidationError):
            self.Seat.create({
                "committee_id": self.committee.id,
                "partner_id": self.p1.id,
                "role": "vice_chair",
                "term_start": "2024-03-01",
                "term_end": "2026-03-01",
            })

    def test_consecutive_term_resets_after_another_officeholder(self):
        seat_a = self.Seat.create({
            "committee_id": self.committee.id,
            "partner_id": self.p1.id,
            "role": "treasurer",
            "term_start": "2020-01-01",
            "term_end": "2022-01-01",
        })
        seat_a.action_end_term()
        # p2 takes over: chain now belongs to p2, term_number 1.
        seat_b = self.Seat.create({
            "committee_id": self.committee.id,
            "partner_id": self.p2.id,
            "role": "treasurer",
            "term_start": "2022-02-01",
            "term_end": "2024-02-01",
        })
        self.assertEqual(seat_b.term_number, 1)
        seat_b.action_end_term()
        # p1 returns after p2's term: chain resets to term_number 1, not 3.
        seat_c = self.Seat.create({
            "committee_id": self.committee.id,
            "partner_id": self.p1.id,
            "role": "treasurer",
            "term_start": "2024-03-01",
            "term_end": "2026-03-01",
        })
        self.assertEqual(seat_c.term_number, 1)

    def test_gap_over_grace_window_resets_count(self):
        seat_a = self.Seat.create({
            "committee_id": self.committee.id,
            "partner_id": self.p1.id,
            "role": "secretary",
            "term_start": "2020-01-01",
            "term_end": "2022-01-01",
        })
        seat_a.action_end_term()
        # Gap of 6 months: not "consecutive", counter resets to 1.
        seat_b = self.Seat.create({
            "committee_id": self.committee.id,
            "partner_id": self.p1.id,
            "role": "secretary",
            "term_start": "2022-07-01",
            "term_end": "2024-07-01",
        })
        self.assertEqual(seat_b.term_number, 1)

    def test_resign_creates_vacancy_succession(self):
        seat = self.Seat.create({
            "committee_id": self.committee.id,
            "partner_id": self.p1.id,
            "role": "chair",
            "term_start": "2026-01-01",
            "term_end": "2028-01-01",
        })
        seat.action_resign()
        self.assertEqual(seat.status, "resigned")
        self.assertEqual(seat.end_reason, "resignation")
        succession = self.Succession.search([
            ("committee_id", "=", self.committee.id), ("role", "=", "chair"),
        ])
        self.assertEqual(len(succession), 1)
        self.assertEqual(succession.from_partner_id, self.p1)
        self.assertFalse(succession.to_partner_id)
        self.assertTrue(succession.is_vacancy)

    def test_new_seat_fills_pending_vacancy(self):
        seat = self.Seat.create({
            "committee_id": self.committee.id,
            "partner_id": self.p1.id,
            "role": "chair",
            "term_start": "2026-01-01",
            "term_end": "2028-01-01",
        })
        seat.action_resign()
        new_seat = self.Seat.create({
            "committee_id": self.committee.id,
            "partner_id": self.p2.id,
            "role": "chair",
            "term_start": "2026-02-01",
            "term_end": "2028-02-01",
        })
        successions = self.Succession.search([
            ("committee_id", "=", self.committee.id), ("role", "=", "chair"),
        ])
        # The resignation's vacancy record is filled in place, not duplicated.
        self.assertEqual(len(successions), 1)
        self.assertEqual(successions.from_partner_id, self.p1)
        self.assertEqual(successions.to_partner_id, self.p2)
        self.assertEqual(successions.to_seat_id, new_seat)

    def test_cron_expire_terms(self):
        seat = self.Seat.create({
            "committee_id": self.committee.id,
            "partner_id": self.p1.id,
            "role": "member",
            "term_start": "2018-01-01",
            "term_end": "2020-01-01",
        })
        expired_count = self.Seat.cron_expire_terms()
        self.assertGreaterEqual(expired_count, 1)
        self.assertEqual(seat.status, "term_ended")
        self.assertEqual(seat.end_reason, "term_expiry")
