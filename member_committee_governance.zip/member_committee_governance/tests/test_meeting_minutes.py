from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError


class TestMeetingMinutes(TransactionCase):
    """Quorum computation, officer lookup and the confirm/reopen guard
    rails on meeting minutes."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.Committee = cls.env["member.committee"]
        cls.Seat = cls.env["member.committee.seat"]
        cls.Minutes = cls.env["member.meeting.minutes"]
        cls.Motion = cls.env["member.motion"]
        cls.Partner = cls.env["res.partner"]

        cls.committee = cls.Committee.create({
            "name": "Minutes Test Board", "max_seats": 6,
            "term_length_months": 24, "quorum_percent": 50.0,
        })

        def make_partner(name):
            return cls.Partner.create({
                "name": name, "is_governance_member": True,
                "member_in_good_standing": True,
            })

        cls.chair = make_partner("Minutes Chair")
        cls.secretary = make_partner("Minutes Secretary")
        cls.member_a = make_partner("Minutes Member A")
        cls.member_b = make_partner("Minutes Member B")
        for partner, role in (
            (cls.chair, "chair"), (cls.secretary, "secretary"),
            (cls.member_a, "member"), (cls.member_b, "member"),
        ):
            cls.Seat.create({
                "committee_id": cls.committee.id, "partner_id": partner.id,
                "role": role, "term_start": "2026-01-01",
                "term_end": "2028-01-01",
            })

    def test_sequence_name_assigned(self):
        minutes = self.Minutes.create({
            "committee_id": self.committee.id, "meeting_date": "2026-06-01",
        })
        self.assertTrue(minutes.name.startswith("MIN/"))

    def test_quorum_met_with_majority_present(self):
        # 3 of 4 active seat holders present: 75% >= 50%.
        minutes = self.Minutes.create({
            "committee_id": self.committee.id, "meeting_date": "2026-06-01",
            "attendee_ids": [(6, 0, [
                self.chair.id, self.secretary.id, self.member_a.id])],
        })
        self.assertEqual(minutes.attendee_count, 3)
        self.assertEqual(minutes.voting_attendee_count, 3)
        self.assertTrue(minutes.quorum_met)

    def test_quorum_not_met_with_minority_present(self):
        # 1 of 4 active seat holders present: 25% < 50%.
        minutes = self.Minutes.create({
            "committee_id": self.committee.id, "meeting_date": "2026-06-01",
            "attendee_ids": [(6, 0, [self.chair.id])],
        })
        self.assertFalse(minutes.quorum_met)

    def test_officers_computed_from_active_seats(self):
        minutes = self.Minutes.create({
            "committee_id": self.committee.id, "meeting_date": "2026-06-01",
        })
        self.assertEqual(minutes.chair_id, self.chair)
        self.assertEqual(minutes.secretary_id, self.secretary)

    def test_confirm_requires_attendees(self):
        minutes = self.Minutes.create({
            "committee_id": self.committee.id, "meeting_date": "2026-06-01",
        })
        with self.assertRaises(UserError):
            minutes.action_confirm()

    def test_reopen_blocked_after_voted_motion(self):
        minutes = self.Minutes.create({
            "committee_id": self.committee.id, "meeting_date": "2026-06-01",
            "attendee_ids": [(6, 0, [
                self.chair.id, self.secretary.id, self.member_a.id])],
        })
        minutes.action_confirm()
        motion = self.Motion.create({
            "meeting_id": minutes.id, "name": "Adopt Minutes Motion",
            "mover_id": self.chair.id, "seconder_id": self.secretary.id,
        })
        motion.action_record_vote(3, 0, 0)
        with self.assertRaises(UserError):
            minutes.action_reset_to_draft()
