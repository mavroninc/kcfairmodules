# -*- coding: utf-8 -*-
"""Upgrade to frozen meeting minutes (GT 2026-10).

Confirmed minutes now keep the seat holders, chair and secretary of the
meeting day. For minutes confirmed before this version the meeting-day
seats were never recorded; today's active seats are the best record
available, and freezing them stops further drift from now on.
"""
from odoo import SUPERUSER_ID, api


def migrate(cr, version):
    if not version:
        return
    env = api.Environment(cr, SUPERUSER_ID, {})
    env["member.meeting.minutes"].search(
        [("state", "=", "confirmed"), ("is_frozen", "=", False)])._freeze_seats()
