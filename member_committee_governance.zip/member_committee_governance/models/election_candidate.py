from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class MemberElectionCandidate(models.Model):
    """One nomination for one election. Eligibility (good standing plus a
    projected term-limit check against the target role) is recomputed live
    so the election screen always shows why a candidate can or cannot
    stand, without blocking the nomination itself."""

    _name = "member.election.candidate"
    _description = "Election Candidate"
    _order = "election_id, id"

    election_id = fields.Many2one(
        "member.election", string="Election", required=True,
        ondelete="cascade", index=True)
    committee_id = fields.Many2one(
        related="election_id.committee_id", string="Committee", store=True)
    partner_id = fields.Many2one(
        "res.partner", string="Candidate", required=True, ondelete="restrict")
    nominated_by_id = fields.Many2one(
        "res.partner", string="Nominated / Seconded By")
    nomination_date = fields.Date(
        string="Nomination Date", default=fields.Date.context_today,
        required=True)
    status = fields.Selection(
        selection=[("nominated", "Standing"), ("withdrawn", "Withdrawn")],
        string="Status", default="nominated", required=True, copy=False)

    is_eligible = fields.Boolean(
        string="Eligible", compute="_compute_eligibility", store=True)
    ineligibility_reason = fields.Char(
        string="Ineligibility Reason", compute="_compute_eligibility",
        store=True)
    vote_count = fields.Integer(
        string="Votes", compute="_compute_vote_count")

    @api.depends(
        "partner_id", "partner_id.is_governance_member",
        "partner_id.member_in_good_standing", "election_id.committee_id",
        "election_id.role", "election_id.voting_end", "nomination_date")
    def _compute_eligibility(self):
        Seat = self.env["member.committee.seat"]
        for candidate in self:
            reasons = []
            if not candidate.partner_id._governance_check_eligible():
                reasons.append(_("not a voting member in good standing"))
            committee = candidate.election_id.committee_id
            role = candidate.election_id.role
            if committee and role and candidate.partner_id:
                as_of = (
                    candidate.election_id.voting_end
                    or candidate.nomination_date
                    or fields.Date.context_today(self))
                projected = Seat._projected_term_number(
                    committee, role, candidate.partner_id, as_of)
                limit = committee.max_consecutive_terms
                if limit and projected > limit:
                    reasons.append(_(
                        "would start a %(nth)s consecutive term as %(role)s, "
                        "over the %(limit)s-term limit",
                        nth=projected, role=role, limit=limit))
            candidate.ineligibility_reason = "; ".join(reasons) if reasons else False
            candidate.is_eligible = not reasons

    def _compute_vote_count(self):
        for candidate in self:
            candidate.vote_count = self.env["member.election.ballot"].search_count(
                [("candidate_ids", "in", candidate.id)])

    @api.constrains("election_id", "partner_id")
    def _check_unique_candidacy(self):
        for candidate in self:
            duplicate = self.search([
                ("election_id", "=", candidate.election_id.id),
                ("partner_id", "=", candidate.partner_id.id),
                ("id", "!=", candidate.id),
            ], limit=1)
            if duplicate:
                raise ValidationError(_(
                    "%s has already been nominated in this election.",
                    candidate.partner_id.name))

    def action_withdraw(self):
        for candidate in self:
            if candidate.election_id.state == "closed":
                raise UserError(_(
                    "Cannot withdraw from a closed election."))
            candidate.status = "withdrawn"
