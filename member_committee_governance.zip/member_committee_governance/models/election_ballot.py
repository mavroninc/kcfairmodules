from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class MemberElectionBallot(models.Model):
    """A single cast ballot: one voter, one election, one or more selected
    candidates (up to the number of seats available). Ballots are anonymous
    in effect (no vote weighting) but the voter identity is kept to enforce
    one-ballot-per-voter and electorate eligibility."""

    _name = "member.election.ballot"
    _description = "Election Ballot"
    _order = "id"

    election_id = fields.Many2one(
        "member.election", string="Election", required=True,
        ondelete="cascade", index=True)
    voter_id = fields.Many2one(
        "res.partner", string="Voter", required=True, ondelete="restrict",
        index=True)
    candidate_ids = fields.Many2many(
        "member.election.candidate", "member_election_ballot_candidate_rel",
        "ballot_id", "candidate_id", string="Selected Candidate(s)",
        required=True)
    cast_date = fields.Datetime(
        string="Cast On", default=fields.Datetime.now, required=True)

    @api.model_create_multi
    def create(self, vals_list):
        ballots = super().create(vals_list)
        ballots._check_ballot_validity()
        return ballots

    def write(self, vals):
        res = super().write(vals)
        if {"election_id", "voter_id", "candidate_ids"} & set(vals.keys()):
            self._check_ballot_validity()
        return res

    def _check_ballot_validity(self):
        for ballot in self:
            election = ballot.election_id
            if election.state != "voting":
                raise UserError(_(
                    "Ballots can only be cast while the election is in the "
                    "Voting Open state."))
            if ballot.voter_id not in election.electorate_ids:
                raise ValidationError(_(
                    "%s is not part of the electorate frozen for this "
                    "election and cannot vote.", ballot.voter_id.name))
            invalid_candidates = ballot.candidate_ids.filtered(
                lambda c: c.election_id != election
                or c.status != "nominated" or not c.is_eligible)
            if invalid_candidates:
                raise ValidationError(_(
                    "One or more selected candidates are not standing and "
                    "eligible in this election."))
            if not (1 <= len(ballot.candidate_ids) <= election.seats_available):
                raise ValidationError(_(
                    "A ballot must select between 1 and %s candidate(s) "
                    "for this election.", election.seats_available))

    @api.constrains("election_id", "voter_id")
    def _check_one_ballot_per_voter(self):
        for ballot in self:
            duplicate = self.search([
                ("election_id", "=", ballot.election_id.id),
                ("voter_id", "=", ballot.voter_id.id),
                ("id", "!=", ballot.id),
            ], limit=1)
            if duplicate:
                raise ValidationError(_(
                    "%s has already cast a ballot in this election.",
                    ballot.voter_id.name))
