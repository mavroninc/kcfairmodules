from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

from .committee_seat import ROLE_SELECTION, END_REASON_SELECTION


class MemberOfficerSuccession(models.Model):
    """Append-only log of who followed whom in a given committee role.
    Rows are created automatically by member.committee.seat (on vacancy and
    on fill) rather than by hand, so the audit trail cannot be forgotten."""

    _name = "member.officer.succession"
    _description = "Officer Succession Record"
    _order = "effective_date desc, id desc"

    committee_id = fields.Many2one(
        "member.committee", string="Committee", required=True,
        ondelete="cascade", index=True)
    role = fields.Selection(
        selection=ROLE_SELECTION, string="Role", required=True)
    from_partner_id = fields.Many2one(
        "res.partner", string="Outgoing Officer",
        help="Empty if this is the first holder of the seat.")
    from_seat_id = fields.Many2one(
        "member.committee.seat", string="Outgoing Seat", ondelete="set null")
    to_partner_id = fields.Many2one(
        "res.partner", string="Incoming Officer",
        help="Empty while the seat is a still-unfilled vacancy.")
    to_seat_id = fields.Many2one(
        "member.committee.seat", string="Incoming Seat", ondelete="set null")
    effective_date = fields.Date(string="Effective Date", required=True)
    reason = fields.Selection(
        selection=END_REASON_SELECTION, string="Reason", required=True)
    is_vacancy = fields.Boolean(
        string="Currently Vacant", compute="_compute_is_vacancy", store=True)

    @api.depends("to_partner_id")
    def _compute_is_vacancy(self):
        for record in self:
            record.is_vacancy = not bool(record.to_partner_id)

    def _compute_display_name(self):
        for record in self:
            outgoing = record.from_partner_id.name or _("Vacant")
            incoming = record.to_partner_id.name or _("Vacant")
            role_label = dict(ROLE_SELECTION).get(record.role, record.role)
            record.display_name = _(
                "%(role)s: %(outgoing)s -> %(incoming)s",
                role=role_label, outgoing=outgoing, incoming=incoming)

    @api.constrains("from_partner_id", "to_partner_id")
    def _check_not_self_succession(self):
        for record in self:
            if (record.from_partner_id and record.to_partner_id
                    and record.from_partner_id == record.to_partner_id):
                raise ValidationError(_(
                    "A succession record cannot have the same officer as "
                    "both the outgoing and incoming holder."))
