from dateutil.relativedelta import relativedelta

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError

from .committee_seat import ROLE_SELECTION


class MemberElection(models.Model):
    """A nomination -> voting -> tally workflow for one committee role.
    Freezes the electorate at the start of voting, tallies ballots at
    closing, applies the quorum rule and flags true ties instead of
    silently guessing a winner."""

    _name = "member.election"
    _description = "Committee Election"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "id desc"

    name = fields.Char(string="Election", required=True, tracking=True)
    committee_id = fields.Many2one(
        "member.committee", string="Committee", required=True,
        ondelete="cascade", index=True)
    role = fields.Selection(
        selection=ROLE_SELECTION, string="Seat / Role", required=True,
        default="member",
        help="The committee role being contested.")
    seats_available = fields.Integer(
        string="Seats Available", default=1, required=True)

    state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("nomination", "Nominations Open"),
            ("voting", "Voting Open"),
            ("closed", "Closed"),
            ("cancelled", "Cancelled"),
        ],
        string="Status", default="draft", required=True, tracking=True)

    nomination_start = fields.Date(string="Nominations Open On")
    nomination_end = fields.Date(string="Nominations Close On")
    voting_start = fields.Date(string="Voting Opens On")
    voting_end = fields.Date(string="Voting Closes On")

    quorum_percent = fields.Float(
        string="Quorum %", default=50.0, required=True,
        help="Minimum turnout, as a percentage of the frozen electorate, "
             "for the result to be declared valid.")
    electorate_ids = fields.Many2many(
        "res.partner", "member_election_electorate_rel", "election_id",
        "partner_id", string="Electorate", copy=False,
        help="Voters eligible at the moment voting opened. Frozen so that "
             "membership changes mid-vote cannot change who could vote.")
    electorate_count = fields.Integer(
        string="Electorate Size", compute="_compute_ballot_stats", store=True)

    candidate_ids = fields.One2many(
        "member.election.candidate", "election_id", string="Candidates")
    ballot_ids = fields.One2many(
        "member.election.ballot", "election_id", string="Ballots")
    ballot_count = fields.Integer(
        string="Ballots Cast", compute="_compute_ballot_stats", store=True)
    turnout_percent = fields.Float(
        string="Turnout %", compute="_compute_ballot_stats", store=True)

    quorum_met = fields.Boolean(
        string="Quorum Met", copy=False, tracking=True)
    winner_ids = fields.Many2many(
        "res.partner", "member_election_winner_rel", "election_id",
        "partner_id", string="Winner(s)", copy=False, tracking=True)
    tie_candidate_ids = fields.Many2many(
        "member.election.candidate", "member_election_tie_rel",
        "election_id", "candidate_id", string="Tied Candidates", copy=False,
        help="Candidates tied for the last available seat(s); requires a "
             "manual tie-break before seats can be created.")
    needs_manual_tiebreak = fields.Boolean(
        string="Needs Manual Tie-Break", copy=False)

    @api.depends("ballot_ids", "electorate_ids")
    def _compute_ballot_stats(self):
        for election in self:
            election.electorate_count = len(election.electorate_ids)
            election.ballot_count = len(election.ballot_ids)
            election.turnout_percent = (
                100.0 * election.ballot_count / election.electorate_count
                if election.electorate_count else 0.0)

    @api.constrains("seats_available")
    def _check_seats_available(self):
        for election in self:
            if election.seats_available <= 0:
                raise ValidationError(
                    _("Seats Available must be a strictly positive number."))

    @api.constrains("quorum_percent")
    def _check_quorum_percent(self):
        for election in self:
            if not (0.0 < election.quorum_percent <= 100.0):
                raise ValidationError(_("Quorum %% must be between 0 and 100."))

    def action_open_nominations(self):
        for election in self:
            if election.state != "draft":
                raise UserError(_("Only a draft election can open nominations."))
            election.state = "nomination"

    def action_start_voting(self):
        for election in self:
            if election.state != "nomination":
                raise UserError(
                    _("Nominations must be open before voting can start."))
            standing = election.candidate_ids.filtered(
                lambda c: c.status == "nominated")
            if any(not c.is_eligible for c in standing):
                raise UserError(_(
                    "One or more standing candidates are flagged "
                    "ineligible (see the ineligibility reason on the "
                    "candidate). Withdraw them before opening voting."))
            if len(standing) < election.seats_available:
                raise UserError(_(
                    "At least %(needed)s eligible standing candidate(s) are "
                    "required to fill %(needed)s seat(s); only %(have)s "
                    "remain nominated.",
                    needed=election.seats_available, have=len(standing)))
            electorate = self.env["res.partner"].search([
                ("is_governance_member", "=", True),
                ("member_in_good_standing", "=", True),
            ])
            election.write({
                "state": "voting",
                "electorate_ids": [(6, 0, electorate.ids)],
            })

    def action_close_voting(self):
        for election in self:
            if election.state != "voting":
                raise UserError(_("Only an open vote can be closed."))
            election._tally()
            election.state = "closed"

    def _tally(self):
        """Count ballots per standing candidate, apply the quorum rule and
        decide the winner set. Ties for the last seat(s) are flagged rather
        than resolved arbitrarily."""
        self.ensure_one()
        self.quorum_met = self.turnout_percent >= self.quorum_percent
        self.winner_ids = [(5, 0, 0)]
        self.tie_candidate_ids = [(5, 0, 0)]
        self.needs_manual_tiebreak = False
        if not self.quorum_met:
            return
        standing = self.candidate_ids.filtered(
            lambda c: c.status == "nominated")
        ranked = sorted(
            standing, key=lambda c: c.vote_count, reverse=True)
        seats = self.seats_available
        if len(ranked) <= seats:
            self.winner_ids = [(6, 0, [c.partner_id.id for c in ranked])]
            return
        cutoff_votes = ranked[seats - 1].vote_count
        above_cutoff = [c for c in ranked if c.vote_count > cutoff_votes]
        at_cutoff = [c for c in ranked if c.vote_count == cutoff_votes]
        remaining_slots = seats - len(above_cutoff)
        if len(at_cutoff) > remaining_slots:
            # Genuine tie for the last seat(s): declare the unambiguous
            # winners above the cutoff and flag the tied group.
            self.winner_ids = [(6, 0, [c.partner_id.id for c in above_cutoff])]
            self.tie_candidate_ids = [(6, 0, [c.id for c in at_cutoff])]
            self.needs_manual_tiebreak = True
        else:
            winners = above_cutoff + at_cutoff[:remaining_slots]
            self.winner_ids = [(6, 0, [c.partner_id.id for c in winners])]

    def action_cancel(self):
        for election in self:
            if election.state == "closed":
                raise UserError(_("A closed election cannot be cancelled."))
            election.state = "cancelled"

    def action_create_seats_from_winners(self):
        """Turn winners into actual member.committee.seat records, going
        through the normal seat model so seat-cap and term-limit checks
        apply exactly as they would for a manual appointment."""
        Seat = self.env["member.committee.seat"]
        created = self.env["member.committee.seat"]
        for election in self:
            if election.state != "closed":
                raise UserError(_("Only a closed election can create seats."))
            if not election.quorum_met:
                raise UserError(_(
                    "Quorum was not met; this election has no valid winner."))
            if election.needs_manual_tiebreak:
                raise UserError(_(
                    "This election has an unresolved tie for the last "
                    "seat(s); resolve it before creating seats."))
            term_start = election.voting_end or fields.Date.context_today(self)
            term_end = term_start + relativedelta(
                months=election.committee_id.term_length_months or 24)
            for partner in election.winner_ids:
                created |= Seat.create({
                    "committee_id": election.committee_id.id,
                    "partner_id": partner.id,
                    "role": election.role,
                    "term_start": term_start,
                    "term_end": term_end,
                })
        return created
