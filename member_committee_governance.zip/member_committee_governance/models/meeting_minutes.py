from odoo import api, fields, models, _
from odoo.exceptions import UserError


class MemberMeetingMinutes(models.Model):
    """Minutes of one committee meeting: who attended, whether quorum
    (share of active seat holders present) was met, and the motions
    debated/resolved during the meeting. Motions look at
    meeting_id.quorum_met to decide their own outcome, so quorum is
    computed once here."""

    _name = "member.meeting.minutes"
    _description = "Meeting Minutes"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "meeting_date desc, id desc"

    name = fields.Char(
        string="Reference", required=True, copy=False, readonly=True,
        default=lambda self: _("New"))
    committee_id = fields.Many2one(
        "member.committee", string="Committee", required=True,
        ondelete="cascade", index=True)
    meeting_date = fields.Date(
        string="Meeting Date", required=True, default=fields.Date.context_today,
        tracking=True)
    location = fields.Char(string="Location")

    attendee_ids = fields.Many2many(
        "res.partner", "member_meeting_attendee_rel", "meeting_id",
        "partner_id", string="Attendees")
    attendee_count = fields.Integer(
        string="Attendee Count", compute="_compute_quorum", store=True)
    voting_attendee_count = fields.Integer(
        string="Seat Holders Present", compute="_compute_quorum", store=True,
        help="Attendees who also hold an active seat on this committee.")
    quorum_percent = fields.Float(
        string="Quorum % Required", required=True,
        help="Defaults from the committee but can be overridden per meeting.")
    quorum_met = fields.Boolean(
        string="Quorum Met", compute="_compute_quorum", store=True,
        tracking=True)

    chair_id = fields.Many2one(
        "res.partner", string="Chair", compute="_compute_officers")
    secretary_id = fields.Many2one(
        "res.partner", string="Secretary", compute="_compute_officers")

    # Snapshot taken when the minutes are confirmed: a confirmed meeting is a
    # record of who held a seat that day, not of who holds one today.
    is_frozen = fields.Boolean(string="Seats Frozen", copy=False, readonly=True)
    frozen_seat_holder_ids = fields.Many2many(
        "res.partner", "member_meeting_frozen_holder_rel", "meeting_id",
        "partner_id", string="Seat Holders On Meeting Day", copy=False, readonly=True)
    frozen_chair_id = fields.Many2one(
        "res.partner", string="Chair On Meeting Day", copy=False, readonly=True)
    frozen_secretary_id = fields.Many2one(
        "res.partner", string="Secretary On Meeting Day", copy=False, readonly=True)

    state = fields.Selection(
        selection=[("draft", "Draft"), ("confirmed", "Confirmed")],
        string="Status", default="draft", required=True, tracking=True)

    motion_ids = fields.One2many(
        "member.motion", "meeting_id", string="Motions")
    motion_count = fields.Integer(
        string="Motion Count", compute="_compute_motion_stats")
    carried_motion_count = fields.Integer(
        string="Carried", compute="_compute_motion_stats")

    @api.onchange("committee_id")
    def _onchange_committee_default_quorum(self):
        for minutes in self:
            if minutes.committee_id and not minutes.quorum_percent:
                minutes.quorum_percent = minutes.committee_id.quorum_percent

    def _live_officers(self):
        """(seat holders, chair, secretary) from the committee's active seats."""
        self.ensure_one()
        active_seats = self.committee_id.seat_ids.filtered(
            lambda s: s.status == "active")
        chair = active_seats.filtered(lambda s: s.role == "chair")[:1]
        secretary = active_seats.filtered(lambda s: s.role == "secretary")[:1]
        return active_seats.mapped("partner_id"), chair.partner_id, secretary.partner_id

    @api.depends(
        "attendee_ids", "quorum_percent", "is_frozen", "frozen_seat_holder_ids",
        "committee_id.seat_ids.status", "committee_id.seat_ids.partner_id")
    def _compute_quorum(self):
        for minutes in self:
            if minutes.is_frozen:
                seat_holders = minutes.frozen_seat_holder_ids
            else:
                seat_holders = minutes._live_officers()[0]
            minutes.attendee_count = len(minutes.attendee_ids)
            minutes.voting_attendee_count = len(
                minutes.attendee_ids & seat_holders)
            active_seat_count = len(seat_holders)
            if active_seat_count and minutes.quorum_percent:
                share = 100.0 * minutes.voting_attendee_count / active_seat_count
                minutes.quorum_met = share >= minutes.quorum_percent
            else:
                minutes.quorum_met = False

    @api.depends(
        "is_frozen", "frozen_chair_id", "frozen_secretary_id",
        "committee_id.seat_ids.status", "committee_id.seat_ids.role",
        "committee_id.seat_ids.partner_id")
    def _compute_officers(self):
        for minutes in self:
            if minutes.is_frozen:
                minutes.chair_id = minutes.frozen_chair_id
                minutes.secretary_id = minutes.frozen_secretary_id
                continue
            _holders, chair, secretary = minutes._live_officers()
            minutes.chair_id = chair
            minutes.secretary_id = secretary

    def _freeze_seats(self):
        for minutes in self:
            holders, chair, secretary = minutes._live_officers()
            minutes.write({
                "is_frozen": True,
                "frozen_seat_holder_ids": [(6, 0, holders.ids)],
                "frozen_chair_id": chair.id,
                "frozen_secretary_id": secretary.id,
            })

    @api.depends("motion_ids.outcome")
    def _compute_motion_stats(self):
        for minutes in self:
            minutes.motion_count = len(minutes.motion_ids)
            minutes.carried_motion_count = len(
                minutes.motion_ids.filtered(lambda m: m.outcome == "carried"))

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", _("New")) == _("New"):
                vals["name"] = self.env["ir.sequence"].next_by_code(
                    "member.meeting.minutes") or _("New")
            if not vals.get("quorum_percent") and vals.get("committee_id"):
                committee = self.env["member.committee"].browse(
                    vals["committee_id"])
                vals["quorum_percent"] = committee.quorum_percent
        return super().create(vals_list)

    def action_confirm(self):
        for minutes in self:
            if minutes.state != "draft":
                raise UserError(_("Only a draft meeting can be confirmed."))
            if not minutes.attendee_ids:
                raise UserError(
                    _("Record at least one attendee before confirming minutes."))
            minutes._freeze_seats()
            minutes.state = "confirmed"

    def action_reset_to_draft(self):
        for minutes in self:
            if minutes.motion_ids.filtered(lambda m: m.state == "voted"):
                raise UserError(_(
                    "Cannot reopen minutes that already carry a voted motion."))
            minutes.write({"state": "draft", "is_frozen": False})
