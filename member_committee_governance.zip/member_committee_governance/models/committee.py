from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class MemberCommittee(models.Model):
    """A board or committee: the container for seats, elections, motions and
    minutes. Carries the governance rules (seat cap, term length, term
    limit, quorum) that every other model in the module enforces."""

    _name = "member.committee"
    _description = "Committee / Board"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "name"

    name = fields.Char(string="Committee", required=True, tracking=True)
    code = fields.Char(string="Code", copy=False)
    description = fields.Text(string="Charter / Description")
    active = fields.Boolean(default=True)
    company_id = fields.Many2one(
        "res.company", string="Company", default=lambda self: self.env.company)

    max_seats = fields.Integer(
        string="Seat Cap", default=7, required=True, tracking=True,
        help="Maximum number of concurrently active seats.")
    term_length_months = fields.Integer(
        string="Term Length (months)", default=24, required=True,
        help="Default length of a single term, used to propose a term end "
             "date when a new seat is created.")
    max_consecutive_terms = fields.Integer(
        string="Max Consecutive Terms", default=2,
        help="Maximum number of consecutive terms a person may serve in the "
             "same role on this committee before a mandatory gap. Zero "
             "means unlimited.")
    quorum_percent = fields.Float(
        string="Meeting Quorum %", default=50.0, required=True,
        help="Minimum percentage of active seat holders that must attend a "
             "meeting for its motions to be valid.")

    seat_ids = fields.One2many(
        "member.committee.seat", "committee_id", string="Seats")
    active_seat_ids = fields.One2many(
        "member.committee.seat", "committee_id", string="Active Seats",
        domain=[("status", "=", "active")])
    active_seat_count = fields.Integer(
        string="Active Seats", compute="_compute_seat_stats", store=True)
    vacant_seat_count = fields.Integer(
        string="Vacant Seats", compute="_compute_seat_stats", store=True)
    chair_id = fields.Many2one(
        "res.partner", string="Current Chair", compute="_compute_seat_stats",
        store=True)

    election_ids = fields.One2many(
        "member.election", "committee_id", string="Elections")
    election_count = fields.Integer(
        string="Election Count", compute="_compute_related_counts")
    meeting_ids = fields.One2many(
        "member.meeting.minutes", "committee_id", string="Meetings")
    meeting_count = fields.Integer(
        string="Meeting Count", compute="_compute_related_counts")
    succession_ids = fields.One2many(
        "member.officer.succession", "committee_id", string="Successions")

    @api.depends(
        "seat_ids.status", "seat_ids.role", "seat_ids.partner_id", "max_seats")
    def _compute_seat_stats(self):
        for committee in self:
            active_seats = committee.seat_ids.filtered(
                lambda s: s.status == "active")
            committee.active_seat_count = len(active_seats)
            committee.vacant_seat_count = max(
                committee.max_seats - len(active_seats), 0)
            chair_seat = active_seats.filtered(
                lambda s: s.role == "chair")[:1]
            committee.chair_id = chair_seat.partner_id if chair_seat else False

    @api.depends("election_ids", "meeting_ids")
    def _compute_related_counts(self):
        for committee in self:
            committee.election_count = len(committee.election_ids)
            committee.meeting_count = len(committee.meeting_ids)

    @api.constrains("max_seats")
    def _check_max_seats(self):
        for committee in self:
            if committee.max_seats <= 0:
                raise ValidationError(
                    _("Seat Cap must be a strictly positive number of seats."))

    @api.constrains("term_length_months")
    def _check_term_length(self):
        for committee in self:
            if committee.term_length_months <= 0:
                raise ValidationError(
                    _("Term Length must be a strictly positive number of months."))

    @api.constrains("quorum_percent")
    def _check_quorum_percent(self):
        for committee in self:
            if not (0.0 < committee.quorum_percent <= 100.0):
                raise ValidationError(
                    _("Meeting Quorum %% must be between 0 and 100."))

    def action_view_seats(self):
        self.ensure_one()
        action = self.env["ir.actions.act_window"]._for_xml_id(
            "member_committee_governance.action_member_committee_seat")
        action["domain"] = [("committee_id", "=", self.id)]
        action["context"] = {"default_committee_id": self.id}
        return action

    def action_view_elections(self):
        self.ensure_one()
        action = self.env["ir.actions.act_window"]._for_xml_id(
            "member_committee_governance.action_member_election")
        action["domain"] = [("committee_id", "=", self.id)]
        action["context"] = {"default_committee_id": self.id}
        return action

    def action_view_meetings(self):
        self.ensure_one()
        action = self.env["ir.actions.act_window"]._for_xml_id(
            "member_committee_governance.action_member_meeting_minutes")
        action["domain"] = [("committee_id", "=", self.id)]
        action["context"] = {"default_committee_id": self.id}
        return action
