from odoo import api, fields, models, _


class ResPartner(models.Model):
    """Adds the minimal membership-eligibility flags the governance engine
    needs (good standing, join date) plus reverse links to seats, election
    candidacies and cast ballots so a member's governance record is visible
    directly from their contact card."""

    _inherit = "res.partner"

    is_governance_member = fields.Boolean(
        string="Voting Member", tracking=True,
        help="Only voting members can hold a committee seat, stand as a "
             "candidate or cast a ballot.")
    member_in_good_standing = fields.Boolean(
        string="In Good Standing", default=True, tracking=True,
        help="Members not in good standing (e.g. lapsed dues) are not "
             "eligible to be nominated or to vote, even if flagged as a "
             "voting member.")
    membership_join_date = fields.Date(string="Member Since")
    member_number = fields.Char(string="Member No.", copy=False)

    committee_seat_ids = fields.One2many(
        "member.committee.seat", "partner_id", string="Committee Seats",
        groups="member_committee_governance.group_governance_user")
    committee_seat_count = fields.Integer(
        string="Seat Count", compute="_compute_governance_counts",
        groups="member_committee_governance.group_governance_user")
    election_candidacy_ids = fields.One2many(
        "member.election.candidate", "partner_id", string="Candidacies",
        groups="member_committee_governance.group_governance_user")
    election_candidacy_count = fields.Integer(
        string="Candidacy Count", compute="_compute_governance_counts",
        groups="member_committee_governance.group_governance_user")
    ballot_ids = fields.One2many(
        "member.election.ballot", "voter_id", string="Ballots Cast",
        groups="member_committee_governance.group_governance_user")
    ballot_count = fields.Integer(
        string="Ballots Cast", compute="_compute_governance_counts",
        groups="member_committee_governance.group_governance_user")

    @api.depends(
        "committee_seat_ids", "election_candidacy_ids", "ballot_ids")
    def _compute_governance_counts(self):
        for partner in self:
            partner.committee_seat_count = len(partner.committee_seat_ids)
            partner.election_candidacy_count = len(
                partner.election_candidacy_ids)
            partner.ballot_count = len(partner.ballot_ids)

    def _governance_check_eligible(self):
        """Raise nothing, just return True/False: shared eligibility test
        reused by seats, candidacies and ballots so the rule lives in a
        single place."""
        self.ensure_one()
        return bool(self.is_governance_member and self.member_in_good_standing)
