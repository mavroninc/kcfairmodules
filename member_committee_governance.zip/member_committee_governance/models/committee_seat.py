from datetime import timedelta

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from dateutil.relativedelta import relativedelta

# A gap of this many days or fewer between the end of one term and the start
# of the next, for the *same officer in the same role*, is still considered
# an uninterrupted, consecutive term for the purpose of term-limit counting.
CONSECUTIVE_GAP_DAYS = 45

ROLE_SELECTION = [
    ("chair", "Chair"),
    ("vice_chair", "Vice-Chair"),
    ("secretary", "Secretary"),
    ("treasurer", "Treasurer"),
    ("member", "Member"),
]

# Roles that are unique seats: only one person may hold them concurrently.
SINGULAR_ROLES = {"chair", "vice_chair", "secretary", "treasurer"}

STATUS_SELECTION = [
    ("active", "Active"),
    ("term_ended", "Term Ended"),
    ("resigned", "Resigned"),
    ("removed", "Removed"),
]

END_REASON_SELECTION = [
    ("election", "Election Result"),
    ("resignation", "Resignation"),
    ("removal", "Removal"),
    ("term_expiry", "Term Expiry"),
    ("appointment", "Appointment Ended"),
]


class MemberCommitteeSeat(models.Model):
    """One person's occupancy of one seat/role on a committee for one term.
    Enforces the seat cap, the one-officer-per-role rule and consecutive
    term limits, and records officer successions when a seat is vacated or
    (re)filled."""

    _name = "member.committee.seat"
    _description = "Committee Seat"
    _order = "committee_id, term_start desc"

    committee_id = fields.Many2one(
        "member.committee", string="Committee", required=True,
        ondelete="cascade", index=True)
    partner_id = fields.Many2one(
        "res.partner", string="Officer", required=True, ondelete="restrict",
        index=True)
    role = fields.Selection(
        selection=ROLE_SELECTION, string="Role", default="member",
        required=True)
    term_start = fields.Date(
        string="Term Start", required=True, default=fields.Date.context_today)
    term_end = fields.Date(string="Term End", required=True)
    term_number = fields.Integer(
        string="Consecutive Term #", default=1, copy=False, readonly=True,
        help="How many consecutive terms this person has held this same "
             "role on this committee, counting this one.")
    status = fields.Selection(
        selection=STATUS_SELECTION, string="Status", default="active",
        required=True, copy=False)
    end_reason = fields.Selection(
        selection=END_REASON_SELECTION, string="End Reason", copy=False)
    end_date = fields.Date(string="Actual End Date", copy=False)
    notes = fields.Text(string="Notes")

    @api.onchange("committee_id", "term_start")
    def _onchange_propose_term_end(self):
        for seat in self:
            if seat.committee_id and seat.term_start and not seat.term_end:
                seat.term_end = seat.term_start + relativedelta(
                    months=seat.committee_id.term_length_months or 24)

    @api.constrains("term_start", "term_end")
    def _check_term_dates(self):
        for seat in self:
            if seat.term_end <= seat.term_start:
                raise ValidationError(
                    _("Term End must be strictly after Term Start."))

    @api.constrains("committee_id", "role", "status")
    def _check_singular_role(self):
        for seat in self:
            if seat.status != "active" or seat.role not in SINGULAR_ROLES:
                continue
            other = self.search([
                ("committee_id", "=", seat.committee_id.id),
                ("role", "=", seat.role),
                ("status", "=", "active"),
                ("id", "!=", seat.id),
            ], limit=1)
            if other:
                raise ValidationError(_(
                    "%(committee)s already has an active %(role)s (%(who)s). "
                    "End that seat before appointing a new one.",
                    committee=seat.committee_id.name,
                    role=dict(ROLE_SELECTION).get(seat.role, seat.role),
                    who=other.partner_id.name,
                ))

    @api.constrains("committee_id", "status")
    def _check_seat_cap(self):
        for committee in self.mapped("committee_id"):
            active_count = self.search_count([
                ("committee_id", "=", committee.id),
                ("status", "=", "active"),
            ])
            if active_count > committee.max_seats:
                raise ValidationError(_(
                    "%(committee)s allows at most %(cap)s active seats "
                    "(currently %(count)s).",
                    committee=committee.name, cap=committee.max_seats,
                    count=active_count,
                ))

    @api.constrains("partner_id")
    def _check_partner_eligible(self):
        for seat in self:
            if seat.status == "active" and not seat.partner_id._governance_check_eligible():
                raise ValidationError(_(
                    "%s is not an eligible voting member in good standing "
                    "and cannot hold a committee seat.", seat.partner_id.name))

    def _find_prior_seat(self):
        """Latest seat (any partner) for the same committee/role that
        started strictly before this one, used both to compute consecutive
        term counts and to seed officer-succession records."""
        self.ensure_one()
        return self.search([
            ("committee_id", "=", self.committee_id.id),
            ("role", "=", self.role),
            ("id", "!=", self.id),
            ("term_start", "<", self.term_start),
        ], order="term_start desc", limit=1)

    def _find_prior_term(self):
        """Latest earlier seat of the SAME person in the same committee/role.
        Term limits count one person's consecutive terms; on a multi-seat
        role (plain members) the role's latest seat usually belongs to
        someone else, so the role-wide predecessor cannot be used here."""
        self.ensure_one()
        return self.search([
            ("committee_id", "=", self.committee_id.id),
            ("role", "=", self.role),
            ("partner_id", "=", self.partner_id.id),
            ("id", "!=", self.id),
            ("term_start", "<", self.term_start),
        ], order="term_start desc", limit=1)

    def _compute_term_number(self):
        """Recompute (and store) the consecutive-term counter for the given
        seats. Not decorated with @api.depends because the recursion runs
        across sibling records via search(), not through field
        dependencies."""
        for seat in self:
            prior = seat._find_prior_term()
            is_continuation = (
                prior
                and prior.partner_id == seat.partner_id
                and prior.term_end
                and seat.term_start <= prior.term_end + timedelta(days=CONSECUTIVE_GAP_DAYS)
            )
            seat.term_number = (prior.term_number + 1) if is_continuation else 1

    def _check_term_limit(self):
        for seat in self:
            limit = seat.committee_id.max_consecutive_terms
            if limit and seat.term_number > limit:
                raise ValidationError(_(
                    "%(who)s would be serving a %(nth)s consecutive term as "
                    "%(role)s on %(committee)s, exceeding the limit of "
                    "%(limit)s consecutive terms.",
                    who=seat.partner_id.name, nth=seat.term_number,
                    role=dict(ROLE_SELECTION).get(seat.role, seat.role),
                    committee=seat.committee_id.name, limit=limit,
                ))

    def _record_succession_fill(self):
        """When a new active seat is created, close out the most recent
        pending vacancy (a succession record for the same committee/role
        still missing a successor) or open a fresh succession record. Only
        tracked for the singular officer roles: plain 'member' seats can be
        held concurrently by several people, so there is no one-to-one
        successor relationship to log.

        Two special cases are handled so the log only ever records real
        hand-offs between two different people:
        - If the officer renewing the seat is the very same person who just
          vacated it (a consecutive-term renewal), the open vacancy was
          never a genuine vacancy, so it is dropped instead of being
          "filled" with a self-succession (which the model forbids anyway).
        - The very first seat ever held for a given committee/role has no
          predecessor and no open vacancy to close, so nothing is logged
          for it; the succession trail starts at the first hand-off."""
        Succession = self.env["member.officer.succession"]
        for seat in self:
            if seat.status != "active" or seat.role not in SINGULAR_ROLES:
                continue
            pending = Succession.search([
                ("committee_id", "=", seat.committee_id.id),
                ("role", "=", seat.role),
                ("to_partner_id", "=", False),
            ], order="effective_date desc", limit=1)
            if pending:
                if pending.from_partner_id == seat.partner_id:
                    # Same officer renewing their own role: no real
                    # succession happened, so drop the stale placeholder.
                    pending.unlink()
                else:
                    pending.write({
                        "to_partner_id": seat.partner_id.id,
                        "to_seat_id": seat.id,
                    })
            else:
                prior = seat._find_prior_seat()
                if prior:
                    Succession.create({
                        "committee_id": seat.committee_id.id,
                        "role": seat.role,
                        "from_partner_id": prior.partner_id.id,
                        "from_seat_id": prior.id,
                        "to_partner_id": seat.partner_id.id,
                        "to_seat_id": seat.id,
                        "effective_date": seat.term_start,
                        "reason": "appointment",
                    })
                # else: first-ever holder of this seat/role, nothing to log.

    @api.model_create_multi
    def create(self, vals_list):
        seats = super().create(vals_list)
        seats._compute_term_number()
        seats._check_term_limit()
        seats._record_succession_fill()
        return seats

    def write(self, vals):
        recompute_keys = {"committee_id", "role", "partner_id", "term_start"}
        need_recompute = bool(recompute_keys & set(vals.keys()))
        res = super().write(vals)
        if need_recompute:
            self._compute_term_number()
            self._check_term_limit()
        return res

    def _end_seat(self, reason):
        self.ensure_one()
        if self.status != "active":
            raise UserError(_("Only an active seat can be ended."))
        status = "term_ended" if reason == "term_expiry" else (
            "resigned" if reason == "resignation" else "removed")
        self.write({
            "status": status,
            "end_reason": reason,
            "end_date": fields.Date.context_today(self),
        })
        if self.role in SINGULAR_ROLES:
            self.env["member.officer.succession"].create({
                "committee_id": self.committee_id.id,
                "role": self.role,
                "from_partner_id": self.partner_id.id,
                "from_seat_id": self.id,
                "to_partner_id": False,
                "effective_date": fields.Date.context_today(self),
                "reason": reason,
            })

    def action_resign(self):
        for seat in self:
            seat._end_seat("resignation")

    def action_remove(self):
        for seat in self:
            seat._end_seat("removal")

    def action_end_term(self):
        for seat in self:
            seat._end_seat("term_expiry")

    @api.model
    def _projected_term_number(self, committee, role, partner, term_start):
        """Non-recordset helper: what consecutive-term number would
        `partner` be starting if a seat for `role` on `committee` began on
        `term_start`. Used by election candidacies to flag term-limit
        ineligibility *before* a seat actually exists."""
        prior = self.search([
            ("committee_id", "=", committee.id),
            ("role", "=", role),
            ("partner_id", "=", partner.id),
            ("term_start", "<", term_start),
        ], order="term_start desc", limit=1)
        if (prior and prior.term_end
                and term_start <= prior.term_end + timedelta(days=CONSECUTIVE_GAP_DAYS)):
            return prior.term_number + 1
        return 1

    @api.model
    def cron_expire_terms(self):
        """Scheduled-action entry point: any active seat whose term has
        passed is automatically ended with reason 'term_expiry'. Returns the
        number of seats expired (used by tests)."""
        today = fields.Date.context_today(self)
        expiring = self.search([
            ("status", "=", "active"), ("term_end", "<", today),
        ])
        for seat in expiring:
            seat._end_seat("term_expiry")
        return len(expiring)
