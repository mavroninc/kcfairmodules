from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError

MOTION_TYPE_THRESHOLD = {
    "ordinary": 50.0,
    "special": 66.67,
}


class MemberMotion(models.Model):
    """A motion put to a committee meeting: mover, seconder, recorded vote
    tally and an outcome derived from the meeting's quorum plus the
    motion's approval threshold (simple majority for ordinary motions,
    two-thirds for special resolutions by default, both overridable)."""

    _name = "member.motion"
    _description = "Motion"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "id desc"

    name = fields.Char(string="Motion", required=True, tracking=True)
    description = fields.Text(string="Full Text")
    meeting_id = fields.Many2one(
        "member.meeting.minutes", string="Meeting", required=True,
        ondelete="cascade", index=True)
    committee_id = fields.Many2one(
        related="meeting_id.committee_id", string="Committee", store=True)

    motion_type = fields.Selection(
        selection=[("ordinary", "Ordinary Motion"),
                   ("special", "Special Resolution")],
        string="Type", default="ordinary", required=True, tracking=True)
    approval_threshold_percent = fields.Float(
        string="Approval Threshold %", default=50.0, required=True,
        help="Minimum share of for/against votes (abstentions excluded) "
             "required for the motion to carry.")

    mover_id = fields.Many2one(
        "res.partner", string="Moved By", required=True, tracking=True)
    seconder_id = fields.Many2one(
        "res.partner", string="Seconded By", tracking=True)

    state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("tabled", "Tabled"),
            ("voted", "Voted"),
            ("withdrawn", "Withdrawn"),
        ],
        string="Status", default="draft", required=True, tracking=True)

    votes_for = fields.Integer(string="Votes For", copy=False)
    votes_against = fields.Integer(string="Votes Against", copy=False)
    votes_abstain = fields.Integer(string="Abstentions", copy=False)
    total_votes_cast = fields.Integer(
        string="Total Cast", compute="_compute_total_votes", store=True)
    outcome = fields.Selection(
        selection=[
            ("pending", "Pending"),
            ("carried", "Carried"),
            ("defeated", "Defeated"),
            ("no_quorum", "Failed Quorum"),
        ],
        string="Outcome", default="pending", copy=False, tracking=True)

    @api.depends("votes_for", "votes_against", "votes_abstain")
    def _compute_total_votes(self):
        for motion in self:
            motion.total_votes_cast = (
                motion.votes_for + motion.votes_against + motion.votes_abstain)

    @api.onchange("motion_type")
    def _onchange_motion_type(self):
        for motion in self:
            motion.approval_threshold_percent = MOTION_TYPE_THRESHOLD.get(
                motion.motion_type, 50.0)

    @api.constrains("mover_id", "seconder_id")
    def _check_mover_seconder_distinct(self):
        for motion in self:
            if motion.seconder_id and motion.mover_id == motion.seconder_id:
                raise ValidationError(
                    _("The mover and seconder of a motion must be different people."))

    @api.constrains("mover_id", "seconder_id", "meeting_id")
    def _check_mover_seconder_attended(self):
        for motion in self:
            attendees = motion.meeting_id.attendee_ids
            if not attendees:
                continue
            if motion.mover_id and motion.mover_id not in attendees:
                raise ValidationError(_(
                    "%s is not recorded as an attendee of this meeting and "
                    "cannot move a motion.", motion.mover_id.name))
            if motion.seconder_id and motion.seconder_id not in attendees:
                raise ValidationError(_(
                    "%s is not recorded as an attendee of this meeting and "
                    "cannot second a motion.", motion.seconder_id.name))

    @api.constrains("approval_threshold_percent")
    def _check_threshold(self):
        for motion in self:
            if not (0.0 < motion.approval_threshold_percent <= 100.0):
                raise ValidationError(
                    _("Approval Threshold %% must be between 0 and 100."))

    def action_table(self):
        for motion in self:
            if motion.state != "draft":
                raise UserError(_("Only a draft motion can be tabled."))
            motion.state = "tabled"

    def action_withdraw(self):
        for motion in self:
            if motion.state not in ("draft", "tabled"):
                raise UserError(
                    _("A motion can only be withdrawn before it is voted."))
            motion.state = "withdrawn"

    def action_record_vote(self, votes_for, votes_against, votes_abstain=0):
        """Record a roll-call/show-of-hands result and derive the outcome.
        Returns the computed outcome key (used directly by tests)."""
        self.ensure_one()
        if self.state not in ("draft", "tabled"):
            raise UserError(_("This motion has already been voted or withdrawn."))
        if min(votes_for, votes_against, votes_abstain) < 0:
            raise ValidationError(_("Vote counts cannot be negative."))
        self.votes_for = votes_for
        self.votes_against = votes_against
        self.votes_abstain = votes_abstain
        self.state = "voted"
        if not self.meeting_id.quorum_met:
            self.outcome = "no_quorum"
        else:
            decisive = votes_for + votes_against
            share = (100.0 * votes_for / decisive) if decisive else 0.0
            self.outcome = (
                "carried" if share >= self.approval_threshold_percent
                else "defeated")
        return self.outcome

    def action_confirm_vote(self):
        """UI entry point: tally whatever is already keyed into the
        votes_for/against/abstain fields on the form."""
        for motion in self:
            motion.action_record_vote(
                motion.votes_for, motion.votes_against, motion.votes_abstain)
