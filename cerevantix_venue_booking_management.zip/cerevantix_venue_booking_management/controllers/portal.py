from odoo import http
from odoo.http import request
from odoo.exceptions import AccessError, MissingError
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager


class VenuePortal(CustomerPortal):

    def _prepare_portal_counter_values(self, counter):
        if counter == 'booking_count':
            partner = request.env.user.partner_id
            return 'venue.booking', [('partner_id', '=', partner.id)], 'read'
        return super()._prepare_portal_counter_values(counter)

    @http.route(['/my/bookings', '/my/bookings/page/<int:page>'],
                type='http', auth='user', website=True)
    def portal_my_bookings(self, page=1, sortby=None, **kw):
        Booking = request.env['venue.booking']
        partner = request.env.user.partner_id
        domain = [('partner_id', '=', partner.id)]

        searchbar_sortings = {
            'date': {'label': 'Start Date', 'order': 'start_datetime desc'},
            'name': {'label': 'Reference', 'order': 'name desc'},
            'state': {'label': 'Status', 'order': 'state'},
        }
        if not sortby:
            sortby = 'date'
        order = searchbar_sortings[sortby]['order']

        total = Booking.search_count(domain)
        pager = portal_pager(
            url='/my/bookings',
            url_args={'sortby': sortby},
            total=total, page=page, step=self._items_per_page)
        bookings = Booking.search(
            domain, order=order, limit=self._items_per_page, offset=pager['offset'])
        values = {
            'bookings': bookings,
            'page_name': 'booking',
            'pager': pager,
            'default_url': '/my/bookings',
            'sortby': sortby,
            'searchbar_sortings': searchbar_sortings,
        }
        return request.render(
            'cerevantix_venue_booking_management.portal_my_bookings', values)

    @http.route(['/my/bookings/<int:booking_id>'], type='http', auth='public',
                website=True)
    def portal_booking_detail(self, booking_id, access_token=None, **kw):
        try:
            booking_sudo = self._document_check_access(
                'venue.booking', booking_id, access_token)
        except (AccessError, MissingError):
            return request.redirect('/my')
        values = {
            'booking': booking_sudo,
            'page_name': 'booking',
        }
        return request.render(
            'cerevantix_venue_booking_management.portal_booking_detail', values)
