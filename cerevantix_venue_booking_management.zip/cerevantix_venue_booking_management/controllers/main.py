from odoo import http
from odoo.http import request


class VenueWebsite(http.Controller):

    @http.route('/venues', type='http', auth='public', website=True, sitemap=True)
    def venue_list(self, **kw):
        Venue = request.env['venue.venue'].sudo()
        domain = [('website_published', '=', True)]
        search = kw.get('search')
        if search:
            domain.append(('name', 'ilike', search))
        venue_type = kw.get('venue_type')
        if venue_type:
            domain.append(('venue_type', '=', venue_type))
        amenity = kw.get('amenity')
        if amenity:
            try:
                domain.append(('amenity_ids', 'in', [int(amenity)]))
            except (ValueError, TypeError):
                pass
        venues = Venue.search(domain)
        guests = kw.get('guests')
        if guests:
            try:
                guests_i = int(guests)
                venues = venues.filtered(
                    lambda v: any(s.capacity >= guests_i for s in v.space_ids))
            except (ValueError, TypeError):
                pass
        values = {
            'venues': venues,
            'amenities': request.env['venue.amenity'].sudo().search([]),
            'venue_types': request.env['venue.venue']._fields['venue_type'].selection,
            'search': search or '',
            'current_venue_type': venue_type or '',
            'current_amenity': amenity or '',
            'current_guests': guests or '',
        }
        return request.render(
            'cerevantix_venue_booking_management.venues_list', values)

    @http.route('/venue/<model("venue.venue"):venue>', type='http', auth='public',
                website=True, sitemap=True)
    def venue_detail(self, venue, **kw):
        if not venue.sudo().website_published:
            return request.not_found()
        venue = venue.sudo()
        ICP = request.env['ir.config_parameter'].sudo()
        values = {
            'venue': venue,
            'spaces': venue.space_ids.filtered(lambda s: s.active),
            'amenities': venue.amenity_ids,
            'reviews': venue.review_ids.filtered(lambda r: r.state == 'published'),
            'response_time_hours': ICP.get_int(
                'cerevantix_venue_booking_management.response_time_hours', 24),
            'quote_validity_days': ICP.get_int(
                'cerevantix_venue_booking_management.quote_validity_days', 14),
            'default_deposit_percent': ICP.get_float(
                'cerevantix_venue_booking_management.default_deposit_percent', 30.0),
            'error': kw.get('error'),
        }
        return request.render(
            'cerevantix_venue_booking_management.venue_detail', values)

    @http.route('/venue/quote', type='http', auth='public', methods=['POST'],
                website=True, csrf=True)
    def venue_quote(self, **post):
        Space = request.env['venue.space'].sudo()
        Booking = request.env['venue.booking'].sudo()
        Partner = request.env['res.partner'].sudo()

        space = Space.browse(int(post.get('space_id'))) if post.get('space_id') else Space
        if not space.exists():
            return request.not_found()
        venue = space.venue_id

        start = post.get('start_datetime')
        stop = post.get('stop_datetime')
        guest_count = int(post.get('guest_count') or 1)
        note = post.get('note')
        email = post.get('email')
        name = post.get('name') or email
        phone = post.get('phone')

        # availability pre-check against confirmed/done bookings
        if start and stop:
            conflicts = Booking._get_conflicting_bookings(space, start, stop)
            if conflicts:
                return request.redirect(
                    '/venue/%s?error=%s' % (
                        venue.id, "Those dates are no longer available."))

        partner = Partner.search([('email', '=', email)], limit=1) if email else Partner
        if not partner and email:
            partner = Partner.create({
                'name': name, 'email': email, 'phone': phone,
            })

        service_ids = request.httprequest.form.getlist('service_ids')
        line_cmds = []
        for sid in service_ids:
            try:
                service = request.env['venue.service'].sudo().browse(int(sid))
                if service.exists():
                    line_cmds.append((0, 0, {
                        'service_id': service.id,
                        'name': service.name,
                        'quantity': 1.0,
                        'price_unit': service.price,
                    }))
            except (ValueError, TypeError):
                continue

        booking = Booking.create({
            'partner_id': partner.id,
            'space_id': space.id,
            'start_datetime': start,
            'stop_datetime': stop,
            'guest_count': guest_count,
            'contact_email': email,
            'contact_phone': phone,
            'note': note,
            'booking_source': 'website',
            'state': 'quotation',
            'line_ids': line_cmds,
        })
        booking._portal_ensure_token()

        inquiry = request.env.ref(
            'cerevantix_venue_booking_management.mail_template_venue_inquiry',
            raise_if_not_found=False)
        if inquiry:
            inquiry.sudo().send_mail(booking.id, force_send=False)
        quotation = request.env.ref(
            'cerevantix_venue_booking_management.mail_template_venue_quotation',
            raise_if_not_found=False)
        if quotation:
            quotation.sudo().send_mail(booking.id, force_send=False)

        return request.render(
            'cerevantix_venue_booking_management.quote_thanks', {
                'booking': booking,
                'response_time_hours': request.env['ir.config_parameter'].sudo().get_int(
                    'cerevantix_venue_booking_management.response_time_hours', 24),
            })
