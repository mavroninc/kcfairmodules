{
    "name": "Venue Booking Management",
    "version": "20.0.1.0.0",
    "category": "Services/Venue",
    "summary": (
        "Manage venue and event bookings from inquiry to invoice, with multi-space "
        "hierarchies, dynamic pricing, amenities and real double-booking prevention. "
        "Collect deposits, invoice through Odoo Accounting, and offer a website "
        "booking funnel with a self-service customer portal."
        " Raumbuchung, Saalvermietung, Eventmanagement, Buchungssystem, "
        "Veranstaltungsort buchen, réservation de salle, gestion événementielle, "
        "location de salle, logiciel de réservation, réservation en ligne, reserva de "
        "salas, gestión de eventos, alquiler de espacios, software de reservas, "
        "gestión de salones, prenotazione sale, gestione eventi, noleggio spazi, "
        "software prenotazioni, gestione location, gestão de eventos, aluguer de "
        "espaços, gestão de salões, zaalverhuur, boekingssysteem, evenementenbeheer, "
        "ruimte reserveren, locatie boeken, lokalbokning, evenemangshantering, "
        "bokningssystem, lokaluthyrning, eventbokning, lokalbooking, "
        "arrangementshåndtering, bookingsystem, lokalutleie, eventbooking, tilavaraus, "
        "tapahtumanhallinta, varausjärjestelmä, tilan vuokraus, tapahtumavaraus, "
        "rezerwacja sal, zarządzanie wydarzeniami, wynajem sal, system rezerwacji, "
        "rezerwacja miejsc, rezervare sală, gestionare evenimente, închiriere spații, "
        "sistem de rezervări, rezervare locație, резервация на зали, управление на "
        "събития, наем на зали, система за резервации, резервация на място, "
        "rezervacija dvorana, upravljanje događajima, najam prostora, sustav "
        "rezervacija, rezervacija prostora, salės rezervacija, renginių valdymas, "
        "patalpų nuoma, rezervacijų sistema, erdvės rezervavimas, ruumi broneerimine, "
        "ürituste haldus, saali rentimine, broneerimissüsteem, ürituse broneerimine, "
        "бронювання залу, управління подіями, оренда приміщень, система бронювання, "
        "бронювання місця, бронирование зала, управление мероприятиями, аренда "
        "помещений, система бронирования, бронирование площадки, salon rezervasyonu, "
        "etkinlik yönetimi, mekan kiralama, rezervasyon sistemi, etkinlik "
        "rezervasyonu, reserva de salões, aluguel de espaços, sistema de reservas, "
        "locação de espaços, reserva de salones, renta de espacios, alquiler de "
        "salones, حجز قاعات, إدارة الفعاليات, تأجير قاعات, نظام الحجوزات, حجز مكان, "
        "会場予約, イベント管理, 予約システム, 会場レンタル, 貸し会議室"
    ),
    "description": """
Venue Booking Management
========================
End-to-end management of bookable venues and spaces:

* Hierarchical venues and spaces (hall / floor / room) with dynamic pricing tiers
  (per hour / day / person / flat event rate).
* Double-booking prevention engine honouring parent/child spaces and turnover buffers.
* Website venue catalog with search, detail pages and a progressive quote form.
* Customer portal to track bookings and download quotations.
* Deposits, invoicing (via Accounting) and optional stock auto-deduction of
  consumable add-on services.
* Reviews, analytics dashboard, email templates and reminder cron.
""",
    "author": "Cerevantix Technologies",
    "maintainer": "Cerevantix Technologies",
    "website": "https://cerevantix.com",
    "support": "support@cerevantix.com",
    "license": "OPL-1",
    "price": 149.0,
    "currency": "USD",
    "depends": [
        "mail",
        "portal",
        "website",
        "account",
        "stock",
    ],
    "data": [
        "security/venue_security.xml",
        "security/ir.access.csv",
        "data/ir_sequence_data.xml",
        "report/venue_reports.xml",
        "data/mail_template_data.xml",
        "data/ir_cron_data.xml",
        "data/portal_entry_data.xml",
        "data/venue_data.xml",
        "views/amenity_views.xml",
        "views/service_views.xml",
        "views/venue_views.xml",
        "views/space_views.xml",
        "views/booking_views.xml",
        "views/review_views.xml",
        "views/reschedule_wizard_views.xml",
        "views/res_config_settings_views.xml",
        "views/menus.xml",
        "views/website_templates.xml",
        "views/portal_templates.xml",
        "views/website_menu.xml",
    ],
    "demo": [
        "demo/venue_demo.xml",
    ],
    "images": ["static/description/main_screen.gif"],
    "assets": {
        "web.assets_frontend": [
            "cerevantix_venue_booking_management/static/src/scss/venue.scss",
            "cerevantix_venue_booking_management/static/src/js/booking_form.js",
        ],
    },
    "application": True,
    "installable": True,
}
