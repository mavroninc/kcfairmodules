/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

publicWidget.registry.VenueQuoteForm = publicWidget.Widget.extend({
    selector: ".o_venue_quote_form",
    events: {
        "change select[name='space_id']": "_onSpaceChange",
    },

    /**
     * Light enhancement only: the server is the source of truth. We simply
     * surface a hint when the chosen space changes. No correctness depends on JS.
     */
    _onSpaceChange: function (ev) {
        const form = this.el;
        const guests = form.querySelector("input[name='guest_count']");
        if (guests && !guests.value) {
            guests.value = 1;
        }
    },
});

export default publicWidget.registry.VenueQuoteForm;
