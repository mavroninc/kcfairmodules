from datetime import datetime, timedelta

from odoo import fields
from odoo.exceptions import ValidationError, UserError, AccessError
from odoo.tests import tagged
from odoo.addons.account.tests.common import AccountTestInvoicingCommon


@tagged('post_install', '-at_install')
class TestVenueBooking(AccountTestInvoicingCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        # AccountTestInvoicingCommon runs as a restricted independent user, not
        # the admin; grant it the venue manager group so it can manage records.
        cls.env.user.group_ids = [
            (4, cls.env.ref(
                'cerevantix_venue_booking_management.group_venue_manager').id)]
        cls.company = cls.env.company
        cls.currency = cls.company.currency_id

        cls.partner = cls.env['res.partner'].create({'name': 'Acme Events'})

        # A known sale tax (provided by the invoicing common's chart template)
        cls.tax = cls.tax_sale_a

        cls.venue = cls.env['venue.venue'].create({
            'name': 'Grand Hall',
            'company_id': cls.company.id,
            'website_published': True,
        })
        cls.venue_unpub = cls.env['venue.venue'].create({
            'name': 'Hidden Hall',
            'company_id': cls.company.id,
            'website_published': False,
        })

        # One space per pricing mode
        cls.space_hour = cls._make_space('Hour Room', 'hour', price_hour=100.0)
        cls.space_day = cls._make_space('Day Room', 'day', price_day=500.0)
        cls.space_person = cls._make_space('Person Room', 'person',
                                           price_person=20.0)
        cls.space_event = cls._make_space('Event Room', 'event',
                                          price_event=1000.0)

        # Services
        cls.service_plain = cls.env['venue.service'].create({
            'name': 'AV Technician',
            'price': 150.0,
            'company_id': cls.company.id,
        })

        # Storable product + service for stock tests
        cls.product_storable = cls.env['product.product'].create({
            'name': 'Bottled Water Pack',
            'is_storable': True,
            'type': 'consu',
        })
        cls.service_stock = cls.env['venue.service'].create({
            'name': 'Refreshments',
            'price': 50.0,
            'company_id': cls.company.id,
            'product_id': cls.product_storable.id,
        })

    @classmethod
    def _make_space(cls, name, mode, **prices):
        vals = {
            'name': name,
            'venue_id': cls.venue.id,
            'pricing_mode': mode,
            'capacity': 100,
        }
        vals.update(prices)
        return cls.env['venue.space'].create(vals)

    def _dt(self, *args):
        return fields.Datetime.to_string(datetime(*args))

    def _make_booking(self, space, start, stop, **kw):
        vals = {
            'partner_id': self.partner.id,
            'space_id': space.id,
            'start_datetime': start,
            'stop_datetime': stop,
            'guest_count': 10,
        }
        vals.update(kw)
        return self.env['venue.booking'].create(vals)

    # ------------------------------------------------------------------
    # 1. Pricing compute
    # ------------------------------------------------------------------
    def test_pricing_hour(self):
        b = self._make_booking(
            self.space_hour, self._dt(2030, 1, 1, 9, 0),
            self._dt(2030, 1, 1, 12, 0))
        # 3 hours * 100
        self.assertAlmostEqual(b.duration_hours, 3.0)
        self.assertAlmostEqual(b.amount_space, 300.0)

    def test_pricing_day(self):
        b = self._make_booking(
            self.space_day, self._dt(2030, 1, 1, 9, 0),
            self._dt(2030, 1, 2, 9, 0))
        self.assertEqual(b.duration_days, 1)
        self.assertAlmostEqual(b.amount_space, 500.0)

    def test_pricing_person(self):
        b = self._make_booking(
            self.space_person, self._dt(2030, 1, 1, 9, 0),
            self._dt(2030, 1, 1, 12, 0), guest_count=25)
        self.assertAlmostEqual(b.amount_space, 500.0)  # 20 * 25

    def test_pricing_event(self):
        b = self._make_booking(
            self.space_event, self._dt(2030, 1, 1, 9, 0),
            self._dt(2030, 1, 1, 12, 0))
        self.assertAlmostEqual(b.amount_space, 1000.0)

    def test_pricing_services_and_tax(self):
        b = self._make_booking(
            self.space_hour, self._dt(2030, 1, 1, 9, 0),
            self._dt(2030, 1, 1, 11, 0))  # 2h * 100 = 200
        b.write({'tax_ids': [(6, 0, self.tax.ids)]})
        b.line_ids = [(0, 0, {
            'service_id': self.service_plain.id,
            'name': 'AV Technician',
            'quantity': 2.0,
            'price_unit': 150.0,
        })]
        self.assertAlmostEqual(b.amount_services, 300.0)
        self.assertAlmostEqual(b.amount_untaxed, 500.0)
        # compute_all cross-check
        expected = self.tax.compute_all(
            500.0, self.currency, 1.0, partner=self.partner)
        exp_tax = expected['total_included'] - expected['total_excluded']
        self.assertAlmostEqual(b.amount_tax, exp_tax)
        self.assertAlmostEqual(b.amount_total, expected['total_included'])

    # ------------------------------------------------------------------
    # 2. Sequence
    # ------------------------------------------------------------------
    def test_sequence_name(self):
        b = self._make_booking(
            self.space_hour, self._dt(2030, 2, 1, 9, 0),
            self._dt(2030, 2, 1, 10, 0))
        self.assertTrue(b.name)
        self.assertNotEqual(b.name, 'New')

    # ------------------------------------------------------------------
    # 3. Double-booking engine
    # ------------------------------------------------------------------
    def test_conflict_two_confirmed(self):
        b1 = self._make_booking(
            self.space_hour, self._dt(2030, 3, 1, 9, 0),
            self._dt(2030, 3, 1, 12, 0))
        b1.action_confirm()
        b2 = self._make_booking(
            self.space_hour, self._dt(2030, 3, 1, 11, 0),
            self._dt(2030, 3, 1, 13, 0))
        with self.assertRaises(ValidationError):
            b2.action_confirm()

    def test_conflict_draft_allowed(self):
        b1 = self._make_booking(
            self.space_hour, self._dt(2030, 3, 2, 9, 0),
            self._dt(2030, 3, 2, 12, 0))
        b1.action_confirm()
        # overlapping draft/quotation is permitted
        b2 = self._make_booking(
            self.space_hour, self._dt(2030, 3, 2, 10, 0),
            self._dt(2030, 3, 2, 13, 0))
        b2.action_send_quotation()
        self.assertEqual(b2.state, 'quotation')
        conflicts = b2._get_conflicting_bookings(
            b2.space_id, b2.start_datetime, b2.stop_datetime,
            exclude_ids=b2.ids)
        self.assertIn(b1, conflicts)

    def test_conflict_parent_child(self):
        hall = self._make_space('Big Hall', 'hour', price_hour=100.0)
        room = self.env['venue.space'].create({
            'name': 'Sub Room',
            'venue_id': self.venue.id,
            'parent_id': hall.id,
            'pricing_mode': 'hour',
            'price_hour': 50.0,
            'capacity': 20,
        })
        # parent_path must be populated by _parent_store
        self.assertTrue(room.parent_path)
        b_hall = self._make_booking(
            hall, self._dt(2030, 4, 1, 9, 0), self._dt(2030, 4, 1, 12, 0))
        b_hall.action_confirm()
        b_room = self._make_booking(
            room, self._dt(2030, 4, 1, 10, 0), self._dt(2030, 4, 1, 13, 0))
        with self.assertRaises(ValidationError):
            b_room.action_confirm()

    def test_conflict_buffer(self):
        space = self._make_space('Buffered Room', 'hour', price_hour=100.0)
        space.buffer_minutes = 60
        b1 = self._make_booking(
            space, self._dt(2030, 5, 1, 9, 0), self._dt(2030, 5, 1, 12, 0))
        b1.action_confirm()
        # starts 30 min after stop -> within 60-min buffer -> conflict
        b2 = self._make_booking(
            space, self._dt(2030, 5, 1, 12, 30), self._dt(2030, 5, 1, 14, 0))
        with self.assertRaises(ValidationError):
            b2.action_confirm()
        # starts 90 min after stop -> outside buffer -> allowed
        b3 = self._make_booking(
            space, self._dt(2030, 5, 1, 13, 30), self._dt(2030, 5, 1, 15, 0))
        b3.action_confirm()
        self.assertEqual(b3.state, 'confirmed')

    def test_conflict_cancel_frees_slot(self):
        b1 = self._make_booking(
            self.space_hour, self._dt(2030, 6, 1, 9, 0),
            self._dt(2030, 6, 1, 12, 0))
        b1.action_confirm()
        b2 = self._make_booking(
            self.space_hour, self._dt(2030, 6, 1, 10, 0),
            self._dt(2030, 6, 1, 13, 0))
        with self.assertRaises(ValidationError):
            b2.action_confirm()
        b1.action_cancel()
        b2.action_confirm()
        self.assertEqual(b2.state, 'confirmed')

    # ------------------------------------------------------------------
    # 4. State transitions + reschedule wizard
    # ------------------------------------------------------------------
    def test_state_transitions(self):
        b = self._make_booking(
            self.space_hour, self._dt(2030, 7, 1, 9, 0),
            self._dt(2030, 7, 1, 12, 0))
        self.assertEqual(b.state, 'draft')
        b.action_send_quotation()
        self.assertEqual(b.state, 'quotation')
        b.action_confirm()
        self.assertEqual(b.state, 'confirmed')
        b.action_set_done()
        self.assertEqual(b.state, 'done')
        # cannot cancel a done booking
        with self.assertRaises(UserError):
            b.action_cancel()

    def test_cancel_and_reset(self):
        b = self._make_booking(
            self.space_hour, self._dt(2030, 7, 2, 9, 0),
            self._dt(2030, 7, 2, 12, 0))
        b.action_confirm()
        b.action_cancel()
        self.assertEqual(b.state, 'cancelled')
        # cannot confirm a cancelled booking
        with self.assertRaises(UserError):
            b.action_confirm()
        b.action_reset_to_draft()
        self.assertEqual(b.state, 'draft')

    def test_reschedule_wizard(self):
        b = self._make_booking(
            self.space_hour, self._dt(2030, 8, 1, 9, 0),
            self._dt(2030, 8, 1, 12, 0))
        b.action_confirm()
        wiz = self.env['venue.booking.reschedule.wizard'].with_context(
            active_id=b.id).create({
                'booking_id': b.id,
                'new_start': self._dt(2030, 8, 2, 9, 0),
                'new_stop': self._dt(2030, 8, 2, 12, 0),
                'new_space_id': b.space_id.id,
            })
        wiz.action_apply()
        self.assertEqual(
            fields.Datetime.to_string(b.start_datetime),
            self._dt(2030, 8, 2, 9, 0))

    def test_reschedule_onto_conflict_raises(self):
        other = self._make_booking(
            self.space_hour, self._dt(2030, 9, 1, 9, 0),
            self._dt(2030, 9, 1, 12, 0))
        other.action_confirm()
        b = self._make_booking(
            self.space_hour, self._dt(2030, 9, 2, 9, 0),
            self._dt(2030, 9, 2, 12, 0))
        b.action_confirm()
        wiz = self.env['venue.booking.reschedule.wizard'].with_context(
            active_id=b.id).create({
                'booking_id': b.id,
                'new_start': self._dt(2030, 9, 1, 10, 0),
                'new_stop': self._dt(2030, 9, 1, 13, 0),
                'new_space_id': b.space_id.id,
            })
        with self.assertRaises(ValidationError):
            wiz.action_apply()

    def test_check_dates_constraint(self):
        with self.assertRaises(ValidationError):
            self._make_booking(
                self.space_hour, self._dt(2030, 10, 1, 12, 0),
                self._dt(2030, 10, 1, 9, 0))

    def test_onchange_space_capacity_warning(self):
        b = self.env['venue.booking'].new({
            'partner_id': self.partner.id,
            'space_id': self.space_hour.id,
            'guest_count': 5000,
        })
        res = b._onchange_space()
        self.assertTrue(res and res.get('warning'))

    # ------------------------------------------------------------------
    # 5. Deposit
    # ------------------------------------------------------------------
    def test_deposit_percent(self):
        b = self._make_booking(
            self.space_event, self._dt(2030, 11, 1, 9, 0),
            self._dt(2030, 11, 1, 12, 0))
        b.tax_ids = [(5, 0, 0)]  # clear default sale tax so total == space charge
        b.deposit_type = 'percent'
        b.deposit_percent = 25.0
        # amount_total == amount_space (no tax) == 1000
        self.assertAlmostEqual(b.deposit_amount, 250.0)

    def test_deposit_fixed(self):
        b = self._make_booking(
            self.space_event, self._dt(2030, 11, 2, 9, 0),
            self._dt(2030, 11, 2, 12, 0))
        b.deposit_type = 'fixed'
        b.deposit_amount = 333.0
        self.assertAlmostEqual(b.deposit_amount, 333.0)

    def test_deposit_invoice(self):
        b = self._make_booking(
            self.space_event, self._dt(2030, 11, 3, 9, 0),
            self._dt(2030, 11, 3, 12, 0))
        b.action_confirm()
        b.deposit_type = 'fixed'
        b.deposit_amount = 300.0
        self.assertEqual(b.deposit_state, 'none')
        b.action_create_deposit_invoice()
        self.assertTrue(b.deposit_invoice_id)
        inv = b.deposit_invoice_id
        self.assertEqual(inv.move_type, 'out_invoice')
        self.assertEqual(inv.state, 'draft')
        self.assertAlmostEqual(inv.amount_untaxed, 300.0)
        # cannot create a second deposit invoice
        with self.assertRaises(UserError):
            b.action_create_deposit_invoice()
        # posting the deposit invoice flips deposit_state to invoiced
        inv.action_post()
        b.invalidate_recordset(['deposit_state'])
        self.assertEqual(b.deposit_state, 'invoiced')

    # ------------------------------------------------------------------
    # 6. Invoice
    # ------------------------------------------------------------------
    def test_create_invoice(self):
        b = self._make_booking(
            self.space_hour, self._dt(2030, 12, 1, 9, 0),
            self._dt(2030, 12, 1, 11, 0))  # 200
        b.line_ids = [(0, 0, {
            'service_id': self.service_plain.id,
            'name': 'AV Technician',
            'quantity': 1.0,
            'price_unit': 150.0,
        })]
        b.action_confirm()
        b.action_create_invoice()
        self.assertEqual(b.invoice_count, 1)
        inv = b.invoice_ids
        self.assertEqual(inv.move_type, 'out_invoice')
        # one space line + one service line
        self.assertEqual(len(inv.invoice_line_ids), 2)
        self.assertAlmostEqual(inv.amount_untaxed, 350.0)

    def test_create_invoice_with_deposit_offset(self):
        b = self._make_booking(
            self.space_event, self._dt(2030, 12, 5, 9, 0),
            self._dt(2030, 12, 5, 12, 0))  # 1000
        b.action_confirm()
        b.deposit_type = 'fixed'
        b.deposit_amount = 200.0
        b.action_create_deposit_invoice()
        b.deposit_invoice_id.action_post()
        b.action_create_invoice()
        final = b.invoice_ids - b.deposit_invoice_id
        # space line + deposit offset line
        self.assertEqual(len(final.invoice_line_ids), 2)
        offset = final.invoice_line_ids.filtered(
            lambda l: l.price_unit < 0)
        self.assertTrue(offset)
        self.assertAlmostEqual(offset.price_unit, -200.0)

    def test_invoice_guard_draft(self):
        b = self._make_booking(
            self.space_hour, self._dt(2031, 1, 1, 9, 0),
            self._dt(2031, 1, 1, 11, 0))
        with self.assertRaises(UserError):
            b.action_create_invoice()

    # ------------------------------------------------------------------
    # 7. Stock
    # ------------------------------------------------------------------
    def _warehouse(self):
        return self.env['stock.warehouse'].search(
            [('company_id', '=', self.company.id)], limit=1)

    def test_stock_move_on_confirm(self):
        wh = self._warehouse()
        self.assertTrue(wh, "A warehouse is required for this test")
        self.env['stock.quant']._update_available_quantity(
            self.product_storable, wh.lot_stock_id, 100.0)
        b = self._make_booking(
            self.space_hour, self._dt(2031, 2, 1, 9, 0),
            self._dt(2031, 2, 1, 11, 0))
        b.line_ids = [(0, 0, {
            'service_id': self.service_stock.id,
            'name': 'Refreshments',
            'quantity': 5.0,
            'price_unit': 50.0,
        })]
        b.action_confirm()
        self.assertTrue(b.stock_move_ids)
        done = b.stock_move_ids.filtered(lambda m: m.state == 'done')
        self.assertTrue(done)
        self.assertAlmostEqual(sum(done.mapped('product_uom_qty')), 5.0)
        # cancel reverses/cancels the move; confirm no raise
        b.action_cancel()
        self.assertEqual(b.state, 'cancelled')

    def test_stock_non_storable_creates_none(self):
        b = self._make_booking(
            self.space_hour, self._dt(2031, 2, 2, 9, 0),
            self._dt(2031, 2, 2, 11, 0))
        b.line_ids = [(0, 0, {
            'service_id': self.service_plain.id,
            'name': 'AV Technician',
            'quantity': 1.0,
            'price_unit': 150.0,
        })]
        b.action_confirm()
        self.assertFalse(b.stock_move_ids)

    # ------------------------------------------------------------------
    # 8. Reviews
    # ------------------------------------------------------------------
    def test_reviews_aggregate_published_only(self):
        r1 = self.env['venue.review'].create({
            'venue_id': self.venue.id,
            'partner_id': self.partner.id,
            'rating': '4',
        })
        r2 = self.env['venue.review'].create({
            'venue_id': self.venue.id,
            'partner_id': self.partner.id,
            'rating': '5',
        })
        self.assertEqual(r1.rating_int, 4)
        # draft reviews do not count
        self.assertEqual(self.venue.rating_count, 0)
        self.assertAlmostEqual(self.venue.rating_avg, 0.0)
        r1.action_publish()
        r2.action_publish()
        self.assertEqual(r1.state, 'published')
        self.assertEqual(self.venue.rating_count, 2)
        self.assertAlmostEqual(self.venue.rating_avg, 4.5)
        r2.action_unpublish()
        self.assertEqual(self.venue.rating_count, 1)
        self.assertAlmostEqual(self.venue.rating_avg, 4.0)

    # ------------------------------------------------------------------
    # 9. Access
    # ------------------------------------------------------------------
    def test_access_venue_user_crud(self):
        user = self.env['res.users'].create({
            'name': 'Venue Staff',
            'login': 'venue_staff',
            'email': 'staff@example.com',
            'group_ids': [(4, self.env.ref(
                'cerevantix_venue_booking_management.group_venue_user').id)],
        })
        booking = self.env['venue.booking'].with_user(user).create({
            'partner_id': self.partner.id,
            'space_id': self.space_hour.id,
            'start_datetime': self._dt(2031, 3, 1, 9, 0),
            'stop_datetime': self._dt(2031, 3, 1, 11, 0),
        })
        booking.with_user(user).write({'guest_count': 3})
        self.assertEqual(booking.guest_count, 3)
        booking.with_user(user).unlink()

    def test_access_portal_own_bookings_only(self):
        portal_group = self.env.ref('base.group_portal')
        portal_user = self.env['res.users'].create({
            'name': 'Portal Customer',
            'login': 'portal_cust',
            'email': 'pcust@example.com',
            'group_ids': [(6, 0, [portal_group.id])],
        })
        mine = self._make_booking(
            self.space_hour, self._dt(2031, 3, 2, 9, 0),
            self._dt(2031, 3, 2, 11, 0),
            partner_id=portal_user.partner_id.id)
        other = self._make_booking(
            self.space_hour, self._dt(2031, 3, 3, 9, 0),
            self._dt(2031, 3, 3, 11, 0))
        visible = self.env['venue.booking'].with_user(
            portal_user).search([])
        self.assertIn(mine, visible)
        self.assertNotIn(other, visible)

    def test_access_public_cannot_read_booking(self):
        # The public group has no ACL on venue.booking, so a public user
        # cannot read bookings at the ORM level (the website only exposes
        # published catalog data, never bookings).
        public_user = self.env.ref('base.public_user')
        booking = self._make_booking(
            self.space_hour, self._dt(2031, 4, 1, 9, 0),
            self._dt(2031, 4, 1, 11, 0))
        with self.assertRaises(AccessError):
            booking.with_user(public_user).check_access('read')

    # ------------------------------------------------------------------
    # Cron smoke
    # ------------------------------------------------------------------
    def test_cron_send_reminders(self):
        start = fields.Datetime.now() + timedelta(days=1)
        stop = start + timedelta(hours=2)
        b = self._make_booking(self.space_hour, start, stop)
        b.action_confirm()
        self.env['venue.booking']._cron_send_reminders()
        self.assertTrue(b.reminder_sent)
