import re
from datetime import datetime

from odoo import fields
from odoo.tests import HttpCase, tagged


@tagged('post_install', '-at_install')
class TestVenueWebsite(HttpCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company = cls.env.company

        cls.venue_pub = cls.env['venue.venue'].create({
            'name': 'Public Grand Hall',
            'company_id': cls.company.id,
            'website_published': True,
            'city': 'Metropolis',
        })
        cls.venue_unpub = cls.env['venue.venue'].create({
            'name': 'Secret Hall',
            'company_id': cls.company.id,
            'website_published': False,
        })
        cls.service = cls.env['venue.service'].create({
            'name': 'Catering',
            'price': 25.0,
            'company_id': cls.company.id,
        })
        cls.space = cls.env['venue.space'].create({
            'name': 'Ballroom',
            'venue_id': cls.venue_pub.id,
            'pricing_mode': 'hour',
            'price_hour': 100.0,
            'capacity': 200,
            'service_ids': [(6, 0, cls.service.ids)],
        })

        # A portal user with an own booking for /my tests
        portal_group = cls.env.ref('base.group_portal')
        cls.portal_user = cls.env['res.users'].create({
            'name': 'Portal Customer',
            'login': 'web_portal_cust',
            'password': 'web_portal_cust',
            'email': 'webportal@example.com',
            'group_ids': [(6, 0, [portal_group.id])],
        })
        cls.portal_booking = cls.env['venue.booking'].create({
            'partner_id': cls.portal_user.partner_id.id,
            'space_id': cls.space.id,
            'start_datetime': fields.Datetime.to_string(
                datetime(2031, 6, 1, 9, 0)),
            'stop_datetime': fields.Datetime.to_string(
                datetime(2031, 6, 1, 12, 0)),
            'guest_count': 20,
            'state': 'quotation',
        })

    def test_venue_list_public(self):
        resp = self.url_open('/venues')
        self.assertEqual(resp.status_code, 200)
        self.assertIn('Public Grand Hall', resp.text)

    def test_venue_detail_published(self):
        resp = self.url_open('/venue/%s' % self.venue_pub.id)
        self.assertEqual(resp.status_code, 200)
        self.assertIn('Ballroom', resp.text)

    def test_venue_detail_unpublished_404(self):
        resp = self.url_open('/venue/%s' % self.venue_unpub.id)
        self.assertEqual(resp.status_code, 404)

    def test_venue_quote_creates_booking(self):
        # fetch detail page to obtain csrf token
        page = self.url_open('/venue/%s' % self.venue_pub.id)
        self.assertEqual(page.status_code, 200)
        match = re.search(
            r'name="csrf_token"[^>]*value="([^"]+)"', page.text)
        self.assertTrue(match, "csrf_token not found on detail page")
        csrf = match.group(1)

        before = self.env['venue.booking'].search_count([])
        resp = self.url_open('/venue/quote', data={
            'csrf_token': csrf,
            'space_id': self.space.id,
            'start_datetime': '2031-07-01 09:00:00',
            'stop_datetime': '2031-07-01 12:00:00',
            'guest_count': '15',
            'name': 'Web Lead',
            'email': 'weblead@example.com',
            'phone': '555-1000',
            'note': 'Birthday party',
            'service_ids': str(self.service.id),
        })
        self.assertEqual(resp.status_code, 200)
        self.assertIn('Thank You', resp.text)

        booking = self.env['venue.booking'].search(
            [('contact_email', '=', 'weblead@example.com')], limit=1)
        self.assertTrue(booking)
        self.assertEqual(booking.booking_source, 'website')
        self.assertEqual(booking.state, 'quotation')
        self.assertTrue(booking.line_ids)
        # a partner was created from the email
        partner = self.env['res.partner'].search(
            [('email', '=', 'weblead@example.com')], limit=1)
        self.assertTrue(partner)
        self.assertEqual(booking.partner_id, partner)
        self.assertGreater(
            self.env['venue.booking'].search_count([]), before)

    def test_portal_my_bookings(self):
        self.authenticate('web_portal_cust', 'web_portal_cust')
        resp = self.url_open('/my/bookings')
        self.assertEqual(resp.status_code, 200)
        self.assertIn(self.portal_booking.name, resp.text)

    def test_portal_booking_detail(self):
        self.authenticate('web_portal_cust', 'web_portal_cust')
        resp = self.url_open('/my/bookings/%s' % self.portal_booking.id)
        self.assertEqual(resp.status_code, 200)
        self.assertIn(self.portal_booking.name, resp.text)
