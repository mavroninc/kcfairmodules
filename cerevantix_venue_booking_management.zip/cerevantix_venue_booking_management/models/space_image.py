from odoo import fields, models


class VenueSpaceImage(models.Model):
    _name = 'venue.space.image'
    _description = 'Space Photo'
    _order = 'sequence, id'

    name = fields.Char(string="Caption")
    sequence = fields.Integer(default=10)
    space_id = fields.Many2one('venue.space', required=True, ondelete='cascade')
    image_1920 = fields.Image(required=True, max_width=1920, max_height=1920)
    image_512 = fields.Image(related='image_1920', max_width=512, max_height=512, store=True)
