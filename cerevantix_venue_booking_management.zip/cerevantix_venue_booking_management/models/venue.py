from odoo import api, fields, models


class VenueVenue(models.Model):
    _name = 'venue.venue'
    _description = 'Venue'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name'

    name = fields.Char(required=True, translate=True, tracking=True)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one(
        'res.company', default=lambda self: self.env.company)
    address_id = fields.Many2one('res.partner', string="Address")
    city = fields.Char()
    country_id = fields.Many2one('res.country')
    description = fields.Html(translate=True, sanitize=True)
    image_1920 = fields.Image(max_width=1920, max_height=1920)
    image_128 = fields.Image(related='image_1920', max_width=128, max_height=128, store=True)
    venue_type = fields.Selection(
        [('banquet', 'Banquet / Event Hall'), ('conference', 'Conference Center'),
         ('community', 'Community Room'), ('sports', 'Sports Facility'),
         ('coworking', 'Coworking / Meeting'), ('other', 'Other')],
        default='banquet', required=True)
    space_ids = fields.One2many('venue.space', 'venue_id', string="Spaces")
    space_count = fields.Integer(compute='_compute_space_count')
    amenity_ids = fields.Many2many(
        'venue.amenity', 'venue_venue_amenity_rel', 'venue_id', 'amenity_id',
        string="Amenities")
    review_ids = fields.One2many('venue.review', 'venue_id', string="Reviews")
    rating_avg = fields.Float(compute='_compute_rating', store=True, digits=(2, 1))
    rating_count = fields.Integer(compute='_compute_rating', store=True)
    website_published = fields.Boolean(default=False, string="Published on Website")
    booking_count = fields.Integer(compute='_compute_booking_count')

    @api.depends('space_ids')
    def _compute_space_count(self):
        for venue in self:
            venue.space_count = len(venue.space_ids)

    @api.depends('review_ids.state', 'review_ids.rating_int')
    def _compute_rating(self):
        for venue in self:
            published = venue.review_ids.filtered(lambda r: r.state == 'published')
            venue.rating_count = len(published)
            venue.rating_avg = (
                sum(published.mapped('rating_int')) / len(published) if published else 0.0)

    def _compute_booking_count(self):
        Booking = self.env['venue.booking']
        for venue in self:
            venue.booking_count = Booking.search_count([('venue_id', '=', venue.id)])

    def action_view_spaces(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Spaces',
            'res_model': 'venue.space',
            'view_mode': 'list,form',
            'domain': [('venue_id', '=', self.id)],
            'context': {'default_venue_id': self.id},
        }

    def action_view_bookings(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Bookings',
            'res_model': 'venue.booking',
            'view_mode': 'calendar,list,form',
            'domain': [('venue_id', '=', self.id)],
        }

    def action_open_website(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_url',
            'url': '/venue/%s' % self.id,
            'target': 'new',
        }
