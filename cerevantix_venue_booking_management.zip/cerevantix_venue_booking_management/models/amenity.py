from odoo import api, fields, models


class VenueAmenity(models.Model):
    _name = 'venue.amenity'
    _description = 'Venue Amenity'
    _order = 'sequence, name'

    name = fields.Char(required=True, translate=True)
    sequence = fields.Integer(default=10)
    icon = fields.Char(help="Material Symbol name (e.g. wifi) shown on the website.")
    active = fields.Boolean(default=True)
