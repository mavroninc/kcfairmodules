from odoo import api, fields, models


class VenueReview(models.Model):
    _name = 'venue.review'
    _description = 'Venue Review'
    _inherit = ['mail.thread']
    _order = 'create_date desc'

    name = fields.Char(string="Title")
    venue_id = fields.Many2one('venue.venue', required=True, ondelete='cascade')
    space_id = fields.Many2one(
        'venue.space', domain="[('venue_id', '=', venue_id)]")
    partner_id = fields.Many2one(
        'res.partner', required=True, string="Reviewer",
        default=lambda self: self.env.user.partner_id)
    booking_id = fields.Many2one('venue.booking')
    rating = fields.Selection(
        [('1', '1'), ('2', '2'), ('3', '3'), ('4', '4'), ('5', '5')],
        required=True, default='5')
    rating_int = fields.Integer(compute='_compute_rating_int', store=True)
    comment = fields.Text()
    state = fields.Selection(
        [('draft', 'Pending'), ('published', 'Published')],
        default='draft', required=True)

    @api.depends('rating')
    def _compute_rating_int(self):
        for review in self:
            review.rating_int = int(review.rating) if review.rating else 0

    def action_publish(self):
        self.write({'state': 'published'})

    def action_unpublish(self):
        self.write({'state': 'draft'})
