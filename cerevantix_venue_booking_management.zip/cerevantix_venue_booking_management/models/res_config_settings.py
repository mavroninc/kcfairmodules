from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    venue_default_deposit_percent = fields.Float(
        string="Default Deposit (%)",
        config_parameter='cerevantix_venue_booking_management.default_deposit_percent',
        default=30.0)
    venue_quote_validity_days = fields.Integer(
        string="Quote Validity (days)",
        config_parameter='cerevantix_venue_booking_management.quote_validity_days',
        default=14)
    venue_response_time_hours = fields.Integer(
        string="Response Time (hours)",
        config_parameter='cerevantix_venue_booking_management.response_time_hours',
        default=24)
    venue_reminder_days = fields.Integer(
        string="Reminder Lead Time (days)",
        config_parameter='cerevantix_venue_booking_management.reminder_days',
        default=2)
