from odoo import api, fields, models


class VenueService(models.Model):
    _name = 'venue.service'
    _description = 'Venue Add-on Service'
    _order = 'sequence, name'

    name = fields.Char(required=True, translate=True)
    sequence = fields.Integer(default=10)
    description = fields.Text(translate=True)
    price = fields.Monetary(required=True, default=0.0, string="Unit Price")
    currency_id = fields.Many2one(
        'res.currency', related='company_id.currency_id', store=True, readonly=True)
    company_id = fields.Many2one(
        'res.company', default=lambda self: self.env.company)
    product_id = fields.Many2one(
        'product.product', string="Linked Product", domain=[],
        help="Link a storable/consumable product to deduct stock when a "
             "booking using this service is confirmed.")
    is_consumable = fields.Boolean(
        compute='_compute_is_consumable', store=True, string="Deducts Stock")
    active = fields.Boolean(default=True)

    @api.depends('product_id', 'product_id.is_storable')
    def _compute_is_consumable(self):
        for service in self:
            service.is_consumable = bool(service.product_id and service.product_id.is_storable)
