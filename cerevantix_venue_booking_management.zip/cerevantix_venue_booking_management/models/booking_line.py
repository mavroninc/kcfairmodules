from odoo import api, fields, models


class VenueBookingLine(models.Model):
    _name = 'venue.booking.line'
    _description = 'Booking Service Line'
    _order = 'booking_id, sequence, id'

    booking_id = fields.Many2one('venue.booking', required=True, ondelete='cascade')
    sequence = fields.Integer(default=10)
    service_id = fields.Many2one('venue.service', required=True)
    name = fields.Char(string="Description")
    quantity = fields.Float(default=1.0, required=True)
    price_unit = fields.Monetary(string="Unit Price")
    price_subtotal = fields.Monetary(compute='_compute_subtotal', store=True)
    currency_id = fields.Many2one(
        'res.currency', related='booking_id.currency_id', store=True)
    product_id = fields.Many2one(
        'product.product', related='service_id.product_id', store=True, readonly=True)

    @api.depends('quantity', 'price_unit')
    def _compute_subtotal(self):
        for line in self:
            line.price_subtotal = line.quantity * line.price_unit

    @api.onchange('service_id')
    def _onchange_service(self):
        for line in self:
            if line.service_id:
                line.name = line.service_id.name
                line.price_unit = line.service_id.price
