import logging
import math

from odoo import api, fields, models
from odoo.exceptions import ValidationError, UserError

_logger = logging.getLogger(__name__)


class VenueBooking(models.Model):
    _name = 'venue.booking'
    _description = 'Venue Booking'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'portal.mixin']
    _order = 'start_datetime desc, id desc'

    # Identity
    name = fields.Char(
        required=True, default='New', copy=False, readonly=True, index=True)
    company_id = fields.Many2one(
        'res.company', default=lambda self: self.env.company, required=True)
    currency_id = fields.Many2one(
        'res.currency', related='company_id.currency_id', store=True, readonly=True)

    # Customer
    partner_id = fields.Many2one('res.partner', required=True, tracking=True, string="Customer")
    guest_count = fields.Integer(default=1, string="Guests")
    contact_email = fields.Char()
    contact_phone = fields.Char()

    # What / when
    venue_id = fields.Many2one(
        'venue.venue', compute='_compute_venue', store=True, readonly=True)
    space_id = fields.Many2one(
        'venue.space', required=True, tracking=True,
        domain="[('company_id', 'in', [company_id, False])]")
    pricing_mode = fields.Selection(
        related='space_id.pricing_mode', store=True, readonly=True)
    start_datetime = fields.Datetime(required=True, tracking=True)
    stop_datetime = fields.Datetime(required=True, tracking=True)
    duration_hours = fields.Float(compute='_compute_duration', store=True)
    duration_days = fields.Integer(compute='_compute_duration', store=True)

    # State
    state = fields.Selection(
        [('draft', 'Draft'), ('quotation', 'Quotation Sent'),
         ('confirmed', 'Confirmed'), ('done', 'Completed'),
         ('cancelled', 'Cancelled')],
        default='draft', required=True, tracking=True, copy=False, index=True)
    booking_source = fields.Selection(
        [('backend', 'Backend'), ('website', 'Website')],
        default='backend', readonly=True)

    # Lines
    line_ids = fields.One2many('venue.booking.line', 'booking_id', copy=True, string="Services")

    # Pricing & totals
    amount_space = fields.Monetary(compute='_compute_amounts', store=True, string="Space Charge")
    amount_services = fields.Monetary(compute='_compute_amounts', store=True, string="Services")
    amount_untaxed = fields.Monetary(compute='_compute_amounts', store=True, string="Untaxed")
    tax_ids = fields.Many2many(
        'account.tax', 'venue_booking_tax_rel', 'booking_id', 'tax_id',
        string="Taxes", default=lambda self: self._default_tax_ids(),
        domain="[('type_tax_use', '=', 'sale'), ('company_id', '=', company_id)]")
    amount_tax = fields.Monetary(compute='_compute_amounts', store=True, string="Taxes")
    amount_total = fields.Monetary(compute='_compute_amounts', store=True, string="Total")

    # Deposit
    deposit_type = fields.Selection(
        [('percent', 'Percentage'), ('fixed', 'Fixed Amount')],
        default='percent')
    deposit_percent = fields.Float(
        default=lambda self: self.env['ir.config_parameter'].sudo().get_float(
            'cerevantix_venue_booking_management.default_deposit_percent', 30.0))
    deposit_amount = fields.Monetary(
        compute='_compute_deposit', store=True, readonly=False)
    deposit_state = fields.Selection(
        [('none', 'Not Invoiced'), ('invoiced', 'Invoiced'), ('paid', 'Paid')],
        default='none', compute='_compute_deposit_state', store=True)

    # Accounting
    invoice_ids = fields.Many2many(
        'account.move', 'venue_booking_invoice_rel', 'booking_id', 'move_id',
        copy=False, readonly=True, string="Invoices")
    invoice_count = fields.Integer(compute='_compute_invoice_count')
    deposit_invoice_id = fields.Many2one(
        'account.move', copy=False, readonly=True, string="Deposit Invoice")
    invoice_status = fields.Selection(
        [('none', 'Nothing to Invoice'), ('to_invoice', 'To Invoice'),
         ('invoiced', 'Fully Invoiced')],
        compute='_compute_invoice_status', store=True)

    # Stock
    stock_move_ids = fields.Many2many(
        'stock.move', 'venue_booking_stock_move_rel', 'booking_id', 'move_id',
        copy=False, readonly=True, string="Stock Moves")

    # Portal / website
    note = fields.Html(string="Special Requests")
    reminder_sent = fields.Boolean(default=False, copy=False)
    color = fields.Integer(compute='_compute_color', store=True)

    # ------------------------------------------------------------------
    # Defaults
    # ------------------------------------------------------------------
    @api.model
    def _default_tax_ids(self):
        company = self.env.company
        return company.account_sale_tax_id if company.account_sale_tax_id else False

    # ------------------------------------------------------------------
    # Computes
    # ------------------------------------------------------------------
    @api.depends('space_id', 'space_id.venue_id')
    def _compute_venue(self):
        for booking in self:
            booking.venue_id = booking.space_id.venue_id

    @api.depends('start_datetime', 'stop_datetime')
    def _compute_duration(self):
        for booking in self:
            if booking.start_datetime and booking.stop_datetime and booking.stop_datetime > booking.start_datetime:
                delta = booking.stop_datetime - booking.start_datetime
                hours = delta.total_seconds() / 3600.0
                booking.duration_hours = hours
                booking.duration_days = max(1, math.ceil(hours / 24.0))
            else:
                booking.duration_hours = 0.0
                booking.duration_days = 0

    @api.depends('space_id', 'pricing_mode', 'duration_hours', 'duration_days',
                 'guest_count', 'line_ids.price_subtotal',
                 'space_id.price_hour', 'space_id.price_day',
                 'space_id.price_person', 'space_id.price_event',
                 'tax_ids', 'partner_id')
    def _compute_amounts(self):
        for booking in self:
            space = booking.space_id
            mode = booking.pricing_mode
            if mode == 'hour':
                amount_space = space.price_hour * booking.duration_hours
            elif mode == 'day':
                amount_space = space.price_day * booking.duration_days
            elif mode == 'person':
                amount_space = space.price_person * booking.guest_count
            elif mode == 'event':
                amount_space = space.price_event
            else:
                amount_space = 0.0
            booking.amount_space = amount_space
            booking.amount_services = sum(booking.line_ids.mapped('price_subtotal'))
            booking.amount_untaxed = booking.amount_space + booking.amount_services
            if booking.tax_ids and booking.amount_untaxed:
                taxes = booking.tax_ids.compute_all(
                    booking.amount_untaxed, booking.currency_id, 1.0,
                    partner=booking.partner_id)
                booking.amount_tax = taxes['total_included'] - taxes['total_excluded']
                booking.amount_total = taxes['total_included']
            else:
                booking.amount_tax = 0.0
                booking.amount_total = booking.amount_untaxed

    @api.depends('deposit_type', 'deposit_percent', 'amount_total')
    def _compute_deposit(self):
        for booking in self:
            if booking.deposit_type == 'percent':
                booking.deposit_amount = booking.amount_total * (booking.deposit_percent / 100.0)
            else:
                # fixed: keep user-entered value (don't clobber on recompute)
                booking.deposit_amount = booking.deposit_amount

    @api.depends('deposit_invoice_id.state', 'deposit_invoice_id.payment_state')
    def _compute_deposit_state(self):
        for booking in self:
            inv = booking.deposit_invoice_id
            if not inv or inv.state != 'posted':
                booking.deposit_state = 'none'
            elif inv.payment_state in ('paid', 'in_payment'):
                booking.deposit_state = 'paid'
            else:
                booking.deposit_state = 'invoiced'

    def _compute_invoice_count(self):
        for booking in self:
            booking.invoice_count = len(booking.invoice_ids)

    @api.depends('state', 'invoice_ids.state', 'invoice_ids.move_type', 'deposit_invoice_id')
    def _compute_invoice_status(self):
        for booking in self:
            final_invoices = booking.invoice_ids.filtered(
                lambda m: m.move_type == 'out_invoice' and m != booking.deposit_invoice_id)
            posted = final_invoices.filtered(lambda m: m.state == 'posted')
            if posted:
                booking.invoice_status = 'invoiced'
            elif booking.state in ('confirmed', 'done'):
                booking.invoice_status = 'to_invoice'
            else:
                booking.invoice_status = 'none'

    @api.depends('state')
    def _compute_color(self):
        color_map = {
            'draft': 0, 'quotation': 4, 'confirmed': 10,
            'done': 5, 'cancelled': 1,
        }
        for booking in self:
            booking.color = color_map.get(booking.state, 0)

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') in (False, 'New'):
                vals['name'] = self.env['ir.sequence'].sudo().next_by_code('venue.booking') or 'New'
        return super().create(vals_list)

    # ------------------------------------------------------------------
    # Constraints
    # ------------------------------------------------------------------
    @api.constrains('start_datetime', 'stop_datetime')
    def _check_dates(self):
        for booking in self:
            if booking.start_datetime and booking.stop_datetime:
                if booking.stop_datetime <= booking.start_datetime:
                    raise ValidationError("The end time must be after the start time.")

    @api.constrains('space_id', 'start_datetime', 'stop_datetime', 'state')
    def _check_conflict(self):
        for booking in self:
            if booking.state not in ('confirmed', 'done'):
                continue
            conflicts = booking._get_conflicting_bookings(
                booking.space_id, booking.start_datetime, booking.stop_datetime,
                exclude_ids=booking.ids)
            if conflicts:
                raise ValidationError(booking._conflict_message(conflicts))

    # ------------------------------------------------------------------
    # Double-booking engine
    # ------------------------------------------------------------------
    def _blocking_space_ids(self, space):
        """space + its ancestors + its descendants (parent_path based)."""
        Space = self.env['venue.space']
        if not space:
            return Space
        spaces = space
        # descendants
        if space.parent_path:
            spaces |= Space.search([('parent_path', '=like', space.parent_path + '%')])
        # ancestors
        if space.parent_path:
            ancestor_ids = [int(x) for x in space.parent_path.split('/') if x]
            spaces |= Space.browse(ancestor_ids)
        return spaces

    def _get_conflicting_bookings(self, space, start, stop, exclude_ids=None):
        """Return confirmed/done bookings overlapping [start, stop] on the
        blocking set of `space` (ancestors+descendants), honouring per-space
        buffer_minutes. Works for an unsaved candidate too."""
        if not (space and start and stop):
            return self.env['venue.booking']
        exclude_ids = exclude_ids or []
        blocking = self._blocking_space_ids(space)
        candidates = self.env['venue.booking'].search([
            ('space_id', 'in', blocking.ids),
            ('state', 'in', ('confirmed', 'done')),
            ('id', 'not in', list(exclude_ids)),
        ])
        from datetime import timedelta
        conflicts = self.env['venue.booking']
        for other in candidates:
            buffer_other = timedelta(minutes=other.space_id.buffer_minutes or 0)
            other_stop_eff = other.stop_datetime + buffer_other
            # also apply this candidate's own buffer
            buffer_self = timedelta(minutes=space.buffer_minutes or 0)
            self_stop_eff = stop + buffer_self
            if start < other_stop_eff and other.start_datetime < self_stop_eff:
                conflicts |= other
        return conflicts

    def _conflict_message(self, conflicts):
        lines = []
        for c in conflicts:
            lines.append("- %s (%s) on %s from %s to %s" % (
                c.name, c.space_id.display_name, c.space_id.venue_id.name,
                c.start_datetime, c.stop_datetime))
        return "This space is no longer available for the selected time.\n" \
               "Conflicting booking(s):\n" + "\n".join(lines)

    # ------------------------------------------------------------------
    # Onchange
    # ------------------------------------------------------------------
    @api.onchange('space_id')
    def _onchange_space(self):
        if self.space_id and self.space_id.capacity and self.guest_count > self.space_id.capacity:
            return {
                'warning': {
                    'title': "Capacity exceeded",
                    'message': "This space seats %s guests; you entered %s." % (
                        self.space_id.capacity, self.guest_count),
                }
            }

    # ------------------------------------------------------------------
    # Portal
    # ------------------------------------------------------------------
    def _compute_access_url(self):
        super()._compute_access_url()
        for booking in self:
            booking.access_url = '/my/bookings/%s' % booking.id

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def action_send_quotation(self):
        self.ensure_one()
        if self.state not in ('draft', 'quotation'):
            raise UserError("Only draft bookings can be sent as quotations.")
        self._portal_ensure_token()
        template = self.env.ref(
            'cerevantix_venue_booking_management.mail_template_venue_quotation',
            raise_if_not_found=False)
        if template:
            template.send_mail(self.id, force_send=False)
        self.state = 'quotation'

    def action_confirm(self):
        for booking in self:
            if booking.state == 'cancelled':
                raise UserError("Cancelled bookings cannot be confirmed.")
            conflicts = booking._get_conflicting_bookings(
                booking.space_id, booking.start_datetime, booking.stop_datetime,
                exclude_ids=booking.ids)
            if conflicts:
                raise ValidationError(booking._conflict_message(conflicts))
            booking.state = 'confirmed'
            booking._action_deduct_stock()
            template = self.env.ref(
                'cerevantix_venue_booking_management.mail_template_venue_confirmed',
                raise_if_not_found=False)
            if template:
                template.send_mail(booking.id, force_send=False)

    def action_set_done(self):
        for booking in self:
            if booking.state == 'confirmed':
                booking.state = 'done'

    def action_cancel(self):
        for booking in self:
            if booking.state == 'done':
                raise UserError("Completed bookings cannot be cancelled.")
            booking._action_reverse_stock()
            booking.state = 'cancelled'

    def action_reset_to_draft(self):
        self.write({'state': 'draft'})

    def action_open_reschedule(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Reschedule Booking',
            'res_model': 'venue.booking.reschedule.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'active_id': self.id},
        }

    # ------------------------------------------------------------------
    # Stock
    # ------------------------------------------------------------------
    def _action_deduct_stock(self):
        self.ensure_one()
        StockMove = self.env['stock.move'].sudo()
        warehouse = self.env['stock.warehouse'].sudo().search(
            [('company_id', '=', self.company_id.id)], limit=1)
        if not warehouse:
            return
        customer_loc = self.env.ref('stock.stock_location_customers', raise_if_not_found=False)
        if not customer_loc:
            return
        for line in self.line_ids:
            product = line.product_id
            if not (product and product.is_storable):
                continue
            try:
                move = StockMove.create({
                    'origin': self.name,
                    'description_picking': line.name or product.display_name,
                    'product_id': product.id,
                    'product_uom_qty': line.quantity,
                    'uom_id': product.uom_id.id,
                    'location_id': warehouse.lot_stock_id.id,
                    'location_dest_id': customer_loc.id,
                    'company_id': self.company_id.id,
                })
                move._action_confirm()
                move._action_assign()
                move.quantity = line.quantity
                move.picked = True
                move._action_done()
                self.stock_move_ids = [(4, move.id)]
            except Exception as e:  # noqa: BLE001 - best effort, never block confirm
                _logger.warning("Venue stock deduction failed for %s: %s", self.name, e)
                self.message_post(
                    body="Stock deduction failed for %s: %s" % (
                        product.display_name, e))

    def _action_reverse_stock(self):
        self.ensure_one()
        for move in self.stock_move_ids.sudo():
            try:
                if move.state == 'done':
                    reverse = move.copy({
                        'location_id': move.location_dest_id.id,
                        'location_dest_id': move.location_id.id,
                        'product_uom_qty': move.product_uom_qty,
                        'move_orig_ids': False,
                    })
                    reverse._action_confirm()
                    reverse._action_assign()
                    reverse.quantity = move.product_uom_qty
                    reverse.picked = True
                    reverse._action_done()
                    self.stock_move_ids = [(4, reverse.id)]
                elif move.state not in ('cancel',):
                    move._action_cancel()
            except Exception as e:  # noqa: BLE001
                _logger.warning("Venue stock reversal failed for %s: %s", self.name, e)

    # ------------------------------------------------------------------
    # Accounting
    # ------------------------------------------------------------------
    def _prepare_invoice_vals(self):
        self.ensure_one()
        tax_cmd = [(6, 0, self.tax_ids.ids)]
        lines = [(0, 0, {
            'name': "Venue booking: %s (%s - %s)" % (
                self.space_id.display_name, self.start_datetime, self.stop_datetime),
            'quantity': 1.0,
            'price_unit': self.amount_space,
            'tax_ids': tax_cmd,
        })]
        for line in self.line_ids:
            lines.append((0, 0, {
                'name': line.name or line.service_id.name,
                'quantity': line.quantity,
                'price_unit': line.price_unit,
                'product_id': line.product_id.id or False,
                'tax_ids': tax_cmd,
            }))
        if self.deposit_invoice_id and self.deposit_invoice_id.state == 'posted':
            lines.append((0, 0, {
                'name': "Deposit already invoiced (%s)" % self.deposit_invoice_id.name,
                'quantity': 1.0,
                'price_unit': -self.deposit_amount,
                'tax_ids': tax_cmd,
            }))
        return {
            'move_type': 'out_invoice',
            'partner_id': self.partner_id.id,
            'invoice_origin': self.name,
            'currency_id': self.currency_id.id,
            'company_id': self.company_id.id,
            'invoice_line_ids': lines,
        }

    def action_create_invoice(self):
        self.ensure_one()
        if self.state not in ('confirmed', 'done'):
            raise UserError("Only confirmed bookings can be invoiced.")
        if not self.partner_id:
            raise UserError("A customer is required to create an invoice.")
        move = self.env['account.move'].create(self._prepare_invoice_vals())
        self.invoice_ids = [(4, move.id)]
        return self._open_move_action(move)

    def action_create_deposit_invoice(self):
        self.ensure_one()
        if self.deposit_amount <= 0:
            raise UserError("The deposit amount must be greater than zero.")
        if self.deposit_invoice_id:
            raise UserError("A deposit invoice already exists for this booking.")
        tax_cmd = [(6, 0, self.tax_ids.ids)]
        move = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.partner_id.id,
            'invoice_origin': self.name,
            'currency_id': self.currency_id.id,
            'company_id': self.company_id.id,
            'invoice_line_ids': [(0, 0, {
                'name': "Deposit - %s" % self.name,
                'quantity': 1.0,
                'price_unit': self.deposit_amount,
                'tax_ids': tax_cmd,
            })],
        })
        self.deposit_invoice_id = move.id
        self.invoice_ids = [(4, move.id)]
        return self._open_move_action(move)

    def _open_move_action(self, move):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Invoice',
            'res_model': 'account.move',
            'res_id': move.id,
            'view_mode': 'form',
            'target': 'current',
        }

    def action_view_invoices(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Invoices',
            'res_model': 'account.move',
            'view_mode': 'list,form',
            'domain': [('id', 'in', self.invoice_ids.ids)],
        }

    # ------------------------------------------------------------------
    # Cron
    # ------------------------------------------------------------------
    @api.model
    def _cron_send_reminders(self):
        from datetime import timedelta
        ICP = self.env['ir.config_parameter'].sudo()
        days = ICP.get_int('cerevantix_venue_booking_management.reminder_days', 2)
        now = fields.Datetime.now()
        horizon = now + timedelta(days=days)
        bookings = self.search([
            ('state', '=', 'confirmed'),
            ('reminder_sent', '=', False),
            ('start_datetime', '>=', now),
            ('start_datetime', '<=', horizon),
        ])
        template = self.env.ref(
            'cerevantix_venue_booking_management.mail_template_venue_reminder',
            raise_if_not_found=False)
        for booking in bookings:
            if template:
                template.send_mail(booking.id, force_send=False)
            booking.reminder_sent = True
