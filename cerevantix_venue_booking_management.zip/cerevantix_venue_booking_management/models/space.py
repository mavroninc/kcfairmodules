from odoo import api, fields, models
from odoo.exceptions import ValidationError


class VenueSpace(models.Model):
    _name = 'venue.space'
    _description = 'Bookable Space'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _parent_name = 'parent_id'
    _parent_store = True
    _order = 'venue_id, name'

    name = fields.Char(required=True, translate=True)
    venue_id = fields.Many2one(
        'venue.venue', required=True, ondelete='cascade', tracking=True)
    company_id = fields.Many2one(
        'res.company', related='venue_id.company_id', store=True, readonly=True)
    parent_id = fields.Many2one('venue.space', ondelete='cascade', string="Parent Space")
    parent_path = fields.Char(index=True, unaccent=False)
    child_ids = fields.One2many('venue.space', 'parent_id', string="Child Spaces")
    active = fields.Boolean(default=True)
    capacity = fields.Integer(string="Max Guests")
    area_sqm = fields.Float(string="Area (sqm)")
    description = fields.Html(translate=True, sanitize=True)
    image_1920 = fields.Image(max_width=1920, max_height=1920)
    image_512 = fields.Image(related='image_1920', max_width=512, max_height=512, store=True)
    gallery_ids = fields.One2many('venue.space.image', 'space_id', string="Gallery")
    amenity_ids = fields.Many2many(
        'venue.amenity', 'venue_space_amenity_rel', 'space_id', 'amenity_id',
        string="Amenities")
    service_ids = fields.Many2many(
        'venue.service', 'venue_space_service_rel', 'space_id', 'service_id',
        string="Add-on Services")

    pricing_mode = fields.Selection(
        [('hour', 'Per Hour'), ('day', 'Per Day'), ('person', 'Per Person'),
         ('event', 'Per Event (flat)')],
        required=True, default='hour')
    price_hour = fields.Monetary(default=0.0)
    price_day = fields.Monetary(default=0.0)
    price_person = fields.Monetary(default=0.0)
    price_event = fields.Monetary(default=0.0)
    currency_id = fields.Many2one(
        'res.currency', related='company_id.currency_id', store=True, readonly=True)

    buffer_minutes = fields.Integer(
        default=0, string="Buffer (minutes)",
        help="Turnover/cleanup buffer applied after each booking.")

    booking_ids = fields.One2many('venue.booking', 'space_id', string="Bookings")
    booking_count = fields.Integer(compute='_compute_booking_count')
    review_ids = fields.One2many('venue.review', 'space_id', string="Reviews")
    rating_avg = fields.Float(compute='_compute_rating', store=True, digits=(2, 1))

    @api.depends('name', 'venue_id.name')
    def _compute_display_name(self):
        for space in self:
            if space.venue_id:
                space.display_name = "%s / %s" % (space.venue_id.name, space.name)
            else:
                space.display_name = space.name or ''

    def _compute_booking_count(self):
        Booking = self.env['venue.booking']
        for space in self:
            space.booking_count = Booking.search_count([('space_id', '=', space.id)])

    @api.depends('review_ids.state', 'review_ids.rating_int')
    def _compute_rating(self):
        for space in self:
            published = space.review_ids.filtered(lambda r: r.state == 'published')
            space.rating_avg = (
                sum(published.mapped('rating_int')) / len(published) if published else 0.0)

    @api.constrains('parent_id', 'venue_id')
    def _check_parent_same_venue(self):
        for space in self:
            if space._has_cycle():
                raise ValidationError("A space cannot be its own ancestor.")
            if space.parent_id and space.parent_id.venue_id != space.venue_id:
                raise ValidationError(
                    "The parent space must belong to the same venue.")

    def action_view_bookings(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Bookings',
            'res_model': 'venue.booking',
            'view_mode': 'calendar,list,form',
            'domain': [('space_id', '=', self.id)],
            'context': {'default_space_id': self.id},
        }
