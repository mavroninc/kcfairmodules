from odoo import api, fields, models


class VenueBookingRescheduleWizard(models.TransientModel):
    _name = 'venue.booking.reschedule.wizard'
    _description = 'Reschedule Booking'

    booking_id = fields.Many2one(
        'venue.booking', required=True,
        default=lambda self: self.env.context.get('active_id'))
    new_start = fields.Datetime(
        required=True, string="New Start",
        default=lambda self: self._default_from_booking('start_datetime'))
    new_stop = fields.Datetime(
        required=True, string="New Stop",
        default=lambda self: self._default_from_booking('stop_datetime'))
    new_space_id = fields.Many2one(
        'venue.space', string="New Space",
        default=lambda self: self._default_from_booking('space_id'))

    def _default_from_booking(self, field):
        booking_id = self.env.context.get('active_id')
        if booking_id:
            return self.env['venue.booking'].browse(booking_id)[field]
        return False

    def action_apply(self):
        self.ensure_one()
        booking = self.booking_id
        old_start = booking.start_datetime
        old_stop = booking.stop_datetime
        booking.write({
            'start_datetime': self.new_start,
            'stop_datetime': self.new_stop,
            'space_id': self.new_space_id.id or booking.space_id.id,
        })
        booking.message_post(
            body="Rescheduled from %s - %s to %s - %s" % (
                old_start, old_stop, self.new_start, self.new_stop))
        return {'type': 'ir.actions.act_window_close'}
